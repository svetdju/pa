import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Guard koji proverava da li korisnik ima jednu od dozvoljenih uloga.
 * Dozvoljene uloge se definišu u route data: { roles: ['ADMIN', 'EMPLOYEE'] }
 *
 * Ako korisnik nema pravu ulogu, preusmerava se na home.
 */
export const roleGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  // Prvo proveri da li je ulogovan
  if (!auth.isLoggedIn()) {
    router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }

  const allowedRoles = route.data?.['roles'] as string[] | undefined;
  if (!allowedRoles || allowedRoles.length === 0) {
    return true;
  }

  const userRole = auth.role();
  if (userRole && allowedRoles.includes(userRole)) {
    return true;
  }

  // Korisnik nema dozvolu — preusmeri na home
  router.navigate(['/home']);
  return false;
};
