import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Guard koji proverava da li je korisnik ulogovan.
 * Ako nije, preusmerava ga na login stranicu.
 */
export const authGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn()) {
    return true;
  }

  // Čuvamo URL na koji je korisnik pokušao da ode, da ga vratimo nakon login-a
  router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
  return false;
};
