import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

/**
 * JWT interceptor — automatski dodaje Authorization: Bearer <token> header
 * na svaki HTTP zahtev, osim na rute koje počinju sa /api/auth/ (login, register,
 * forgot-password, verify-reset-token, reset-password).
 */
export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const token = auth.getToken();

  // Ne dodajemo token na auth rute (one su javne)
  const isAuthRoute = req.url.startsWith('/api/auth/');
  // Ne dodajemo token na rute koje već idu na drugi domen (npr. https://picsum.photos)
  const isRelativeUrl = req.url.startsWith('/');

  if (token && !isAuthRoute && isRelativeUrl) {
    req = req.clone({
      setHeaders: { Authorization: `Bearer ${token}` },
    });
  }

  return next(req);
};
