/**
 * TypeScript modeli koji odgovaraju backend DTO-ima i entitetima.
 * Sva polja su snake_case jer backend DTO-i koriste snake_case
 * (radi kompatibilnosti sa postojećim Angular frontend-om).
 */

// ===== Auth =====
export interface AuthResponse {
  token: string;
  username: string;
  role: 'ATHLETE' | 'EMPLOYEE' | 'ADMIN';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  email: string;
  first_name: string;
  last_name: string;
  phone: string;
  role: 'ATHLETE' | 'EMPLOYEE';
  favorite_sports?: string;
  profile_image?: File;
  // samo za EMPLOYEE
  facility_name?: string;
  company_address?: string;
  company_id_number?: string;
  pib?: string;
}

// ===== User =====
export interface AdminUserResponse {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  phone: string;
  role: 'ATHLETE' | 'EMPLOYEE' | 'ADMIN';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  profile_picture_path: string | null;
  favorite_sports: string | null;
}

export interface EmployeeProfileResponse {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  role: string;
  status: string;
  profilePicturePath: string;
  myFacilities: EmployeeFacilityDTO[];
}

export interface EmployeeFacilityDTO {
  id: number;
  name: string;
  city: string;
  address: string;
  description: string;
  pricePerHour: number;
  type: string;
  status: string;
  companyName: string;
  companyAddress: string;
  companyIdNumber: string;
  pib: string;
}

// ===== Facility =====
export interface Facility {
  id: number;
  name: string;
  city: string;
  address: string;
  description: string;
  pricePerHour: number;
  type: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdBy: number | null;
  companyName: string;
  companyAddress: string;
  companyIdNumber: string;
  pib: string;
  workStartTime: string;
  workEndTime: string;
  maxNoShows: number;
}

export interface FacilityRequest {
  name: string;
  city: string;
  address: string;
  description: string;
  price_per_hour: number;
  type: string;
  status?: string;
  work_start_time: string;
  work_end_time: string;
  max_no_shows?: number;
  company_name?: string;
  company_address?: string;
  company_id_number?: string;
  pib?: string;
  courts: CourtRequest[];
}

export interface CourtRequest {
  court_name: string;
  sport_type: string;
  type: 'OPENED' | 'CLOSED';
  capacity: number;
  equipment_description?: string;
}

export interface FacilityDetailsResponse {
  facility: Facility;
  courts: Court[];
  likes: number;
  dislikes: number;
  galleryImages: string[];
}

export interface HomepageResponse {
  totalFacilities: number;
  topFacilities: any[];
  promotions: PromotionSummaryResponse[];
}

export interface PromotionSummaryResponse {
  promotionName: string;
  sportType: string;
  startDate: string;
  endDate: string;
  discountPercent: number;
}

// ===== Court =====
export interface Court {
  id: number;
  facilityId: number;
  courtName: string;
  sportType: string;
  capacity: number;
  equipmentDescription: string | null;
  type: 'OPENED' | 'CLOSED';
}

// ===== Coach =====
export interface Coach {
  id: number;
  facilityId: number;
  name: string;
  specialization: string;
  sport: string;
  pricePerHour: number;
  averageRating: number;
  isActive: boolean;
}

// ===== Reservation =====
export interface Reservation {
  id: number;
  userId: number;
  courtId: number;
  reservationDate: string;
  startTime: string;
  endTime: string;
  status: 'PENDING' | 'CONFIRMED' | 'COMPLETED' | 'ABSENT' | 'CANCELLED';
}

export interface ReservationRequest {
  facility_id: number;
  court_id: number;
  reservation_date: string;
  start_time: string;
  end_time: string;
}

export interface ReservationResponse {
  id: number;
  user_id: number;
  facility_name: string;
  city: string;
  court_name_number: string;
  sport: string;
  reservation_date: string;
  start_time: string;
  end_time: string;
  status: string;
}

export interface ReservationViewResponse {
  id: number;
  type: 'RESERVATION' | 'TRAINING';
  userName: string;
  courtId: number;
  courtName: string;
  coachName: string | null;
  date: string;
  startTime: string;
  endTime: string;
  status: string;
  actionAllowed: boolean;
}

// ===== Training =====
export interface Training {
  id: number;
  userId: number;
  coachId: number;
  courtId: number;
  trainingDate: string;
  startTime: string;
  endTime: string;
  status: 'SCHEDULED' | 'COMPLETED' | 'CANCELLED';
}

export interface TrainingRequest {
  coach_id: number;
  court_id: number;
  training_date: string;
  start_time: string;
  end_time: string;
}

export interface TrainingResponse {
  id: number;
  coach_name: string;
  facility_name: string;
  court_id: number;
  court_name: string;
  sport: string;
  training_date: string;
  start_time: string;
  end_time: string;
  status: string;
}

// ===== Equipment / Shop =====
export interface Equipment {
  id: number;
  name: string;
  imagePath: string | null;
  sportType: string;
  price: number;
  stockQuantity: number;
  description: string | null;
  sportId: number | null;
}

export interface CartItemRequest {
  equipment_id: number;
  quantity: number;
}

export interface OrderRequest {
  items: CartItemRequest[];
}

export interface OrderResponse {
  id: number;
  order_date: string;
  total_price: number;
  status: 'ORDERED' | 'ACCEPTED' | 'DELIVERED' | 'CANCELLED';
  items_summary: string;
  total_original_price: number;
}

// ===== Promotion =====
export interface Promotion {
  id: number;
  name: string;
  discountPercent: number;
  sportType: string | null;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

// ===== Rating =====
export interface RatingRequest {
  is_like: boolean;
  comment?: string;
}

export interface RatingResponse {
  id: number;
  username: string;
  is_like: boolean;
  comment: string | null;
  created_at: string;
}

export interface RatingSummaryResponse {
  likes: number;
  dislikes: number;
  lastComments: RatingResponse[];
}

export interface RatingEligibilityResponse {
  confirmedReservations: number;
  usedRatings: number;
  canRate: boolean;
}

// ===== Teammate Ads =====
export interface AdRequest {
  sport: string;
  city: string;
  event_date: string;
  event_time: string;
  players_needed: number;
}

export interface AdResponse {
  id: number;
  creator_username: string;
  sport: string;
  city: string;
  event_date: string;
  event_time: string;
  players_needed: number;
  status: 'OPEN' | 'CLOSED';
}

export interface AdResponseDetails {
  id: number;
  sport: string;
  city: string;
  event_date: string;
  event_time: string;
  players_needed: number;
  status: 'OPEN' | 'CLOSED';
  responses: TeammateResponseDTO[];
}

export interface TeammateResponseDTO {
  response_id: number;
  user_id: number;
  username: string;
  first_name: string;
  last_name: string;
  phone: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

// ===== Statistics =====
export interface StatisticsResponse {
  reservationsBySport: { sport: string; count: number }[];
  monthlyActivity: { month_label: string; count: number }[];
  totalSpendingOnEquipment: number;
}

// ===== Sport =====
export interface Sport {
  id: number;
  name: string;
  description: string;
}
