import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TrainingRequest, TrainingResponse } from '../models/models';

/**
 * Servis za individualne treninge — zakazivanje i arhiva.
 */
@Injectable({ providedIn: 'root' })
export class TrainingService {
  private http = inject(HttpClient);

  scheduleTraining(req: TrainingRequest): Observable<string> {
    return this.http.post('/api/trainings', req, { responseType: 'text' });
  }

  getMyTrainings(): Observable<TrainingResponse[]> {
    return this.http.get<TrainingResponse[]>('/api/trainings/my');
  }
}
