import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdminUserResponse, Coach, Facility, Court, Sport } from '../models/models';

/**
 * Servis za administratorske funkcije — upravljanje korisnicima, objektima,
 * trenerima i sportovima.
 */
@Injectable({ providedIn: 'root' })
export class AdminService {
  private http = inject(HttpClient);

  // ===== Users =====
  getAllUsers(): Observable<AdminUserResponse[]> {
    return this.http.get<AdminUserResponse[]>('/api/admin/users');
  }

  updateUserStatus(userId: number, status: 'APPROVED' | 'REJECTED'): Observable<string> {
    return this.http.put(
      `/api/admin/users/${userId}/status?status=${status}`,
      {},
      { responseType: 'text' }
    );
  }

  deleteUser(userId: number): Observable<string> {
    return this.http.delete(`/api/admin/users/${userId}`, { responseType: 'text' });
  }

  // ===== Facilities =====
  getPendingFacilities(): Observable<Facility[]> {
    return this.http.get<Facility[]>('/api/admin/facilities/pending');
  }

  getFacilityCourts(facilityId: number): Observable<Court[]> {
    return this.http.get<Court[]>(`/api/admin/facilities/${facilityId}/courts`);
  }

  updateFacilityStatus(facilityId: number, status: 'APPROVED' | 'REJECTED'): Observable<string> {
    return this.http.put(
      `/api/admin/facilities/${facilityId}/status?status=${status}`,
      {},
      { responseType: 'text' }
    );
  }

  // ===== Coaches =====
  getAllCoaches(): Observable<Coach[]> {
    return this.http.get<Coach[]>('/api/admin/coaches');
  }

  updateCoachActiveStatus(coachId: number, isActive: boolean): Observable<string> {
    return this.http.put(
      `/api/admin/coaches/${coachId}/active?isActive=${isActive}`,
      {},
      { responseType: 'text' }
    );
  }

  // ===== Sports =====
  addSport(sport: Sport): Observable<string> {
    return this.http.post('/api/admin/sports', sport, { responseType: 'text' });
  }
}
