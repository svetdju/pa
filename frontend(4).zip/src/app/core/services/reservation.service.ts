import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ReservationRequest, ReservationResponse, Reservation } from '../models/models';

/**
 * Servis za rezervacije terena — kreiranje, otkazivanje i pregled.
 */
@Injectable({ providedIn: 'root' })
export class ReservationService {
  private http = inject(HttpClient);

  createReservation(req: ReservationRequest): Observable<string> {
    return this.http.post('/api/reservations', req, { responseType: 'text' });
  }

  getMyReservations(): Observable<ReservationResponse[]> {
    return this.http.get<ReservationResponse[]>('/api/reservations/my');
  }

  cancelReservation(id: number): Observable<string> {
    return this.http.put(`/api/reservations/${id}/cancel`, {}, { responseType: 'text' });
  }
}
