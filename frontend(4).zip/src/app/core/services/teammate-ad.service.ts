import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdRequest, AdResponse, AdResponseDetails } from '../models/models';

/**
 * Servis za oglase "tražim saigrače".
 */
@Injectable({ providedIn: 'root' })
export class TeammateAdService {
  private http = inject(HttpClient);

  createAd(req: AdRequest): Observable<string> {
    return this.http.post('/api/ads', req, { responseType: 'text' });
  }

  getActiveAds(): Observable<AdResponse[]> {
    return this.http.get<AdResponse[]>('/api/ads/active');
  }

  respondToAd(adId: number): Observable<string> {
    return this.http.post(`/api/ads/${adId}/respond`, {}, { responseType: 'text' });
  }

  getMyAds(): Observable<AdResponseDetails[]> {
    return this.http.get<AdResponseDetails[]>('/api/ads/my');
  }

  handleResponse(responseId: number, status: 'APPROVED' | 'REJECTED'): Observable<string> {
    return this.http.put(
      `/api/ads/responses/${responseId}/status?status=${status}`,
      {},
      { responseType: 'text' }
    );
  }

  closeAd(adId: number): Observable<string> {
    return this.http.put(`/api/ads/${adId}/close`, {}, { responseType: 'text' });
  }

  getMyResponses(): Observable<any[]> {
    return this.http.get<any[]>('/api/ads/my-responses');
  }
}
