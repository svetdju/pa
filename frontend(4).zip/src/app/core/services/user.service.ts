import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdminUserResponse, EmployeeProfileResponse } from '../models/models';

/**
 * Servis za korisnički profil — pregled i ažuriranje ličnih podataka,
 * omiljenih sportova i profilne slike.
 */
@Injectable({ providedIn: 'root' })
export class UserService {
  private http = inject(HttpClient);

  getMyProfile(): Observable<AdminUserResponse> {
    return this.http.get<AdminUserResponse>('/api/users/profile');
  }

  updateProfile(data: {
    first_name?: string;
    last_name?: string;
    phone?: string;
    email?: string;
  }): Observable<string> {
    return this.http.put('/api/users/profile', data, { responseType: 'text' });
  }

  updateFavoriteSports(favoriteSports: string): Observable<string> {
    return this.http.put('/api/users/profile/sports', JSON.stringify(favoriteSports), {
      headers: { 'Content-Type': 'application/json' },
      responseType: 'text',
    });
  }

  updateProfileImage(file: File): Observable<{ profile_picture_path: string }> {
    const fd = new FormData();
    fd.append('image', file);
    return this.http.put<{ profile_picture_path: string }>('/api/users/profile/image', fd);
  }

  getEmployeeProfile(): Observable<EmployeeProfileResponse> {
    return this.http.get<EmployeeProfileResponse>('/api/users/profile/employee');
  }
}
