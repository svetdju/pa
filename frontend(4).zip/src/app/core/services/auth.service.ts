import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { AuthResponse, LoginRequest, RegisterRequest, AdminUserResponse } from '../models/models';

/**
 * Centralni autentifikacijski servis.
 *
 * Koristi Angular 20 Signals za reaktivno čuvanje stanja korisnika.
 * Token se čuva u localStorage (persistencija kroz reload).
 *
 * Poštuje backend biznis pravila:
 * - Samo APPROVED korisnici mogu da se uloguju
 * - Admin login je na istom endpoint-u ali se koristi sa skrivene rute
 * - Logout briše token i preusmerava na home
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);

  private readonly TOKEN_KEY = 'sportsphere_token';
  private readonly USER_KEY = 'sportsphere_user';

  /** Trenutni korisnik (signal — reaktivan) */
  private currentUser = signal<AdminUserResponse | null>(this.loadUserFromStorage());

  /** Da li je korisnik ulogovan */
  readonly isLoggedIn = computed(() => this.currentUser() !== null);

  /** Uloga trenutnog korisnika */
  readonly role = computed(() => this.currentUser()?.role ?? null);

  /** Da li je admin */
  readonly isAdmin = computed(() => this.role() === 'ADMIN');

  /** Da li je zaposleni */
  readonly isEmployee = computed(() => this.role() === 'EMPLOYEE');

  /** Da li je sportista */
  readonly isAthlete = computed(() => this.role() === 'ATHLETE');

  /** Trenutni korisnik (readonly signal za eksternu potrošnju) */
  readonly user = this.currentUser.asReadonly();

  /**
   * Login — šalje kreditencijale backendu, čuva token i korisničke podatke.
   */
  login(credentials: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/auth/login', credentials).pipe(
      tap(res => this.handleAuthSuccess(res))
    );
  }

  /**
   * Registracija — šalje multipart form data (sa profilnom slikom).
   * Backend vraća AuthResponse sa tokenom i statusom.
   * Ako je status PENDING, korisnik ne može odmah da se uloguje.
   */
  register(data: RegisterRequest): Observable<AuthResponse> {
    const formData = this.buildRegisterFormData(data);
    return this.http.post<AuthResponse>('/api/auth/register', formData).pipe(
      tap(res => this.handleAuthSuccess(res))
    );
  }

  /** Logout — briše sve i preusmerava na home. */
  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.currentUser.set(null);
    this.router.navigate(['/home']);
  }

  /** JWT token iz localStorage */
  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  /**
   * Zatraži reset lozinke — backend vraća token (koji bi se inače slao email-om).
   */
  requestPasswordReset(identifier: string): Observable<any> {
    return this.http.post('/api/auth/forgot-password', { identifier });
  }

  /** Proveri da li je reset token validan. */
  verifyResetToken(token: string): Observable<any> {
    return this.http.get(`/api/auth/verify-reset-token?token=${token}`);
  }

  /** Postavi novu lozinku koristeći reset token. */
  resetPassword(token: string, newPassword: string): Observable<any> {
    return this.http.post('/api/auth/reset-password', { token, newPassword });
  }

  // ========================================================================
  // Privatni helper-i
  // ========================================================================

  private handleAuthSuccess(res: AuthResponse): void {
    localStorage.setItem(this.TOKEN_KEY, res.token);
    // Čuvamo osnovne podatke o korisniku (dovoljno za navbar/guards)
    const user: AdminUserResponse = {
      id: 0, // backend ne vraća id u AuthResponse; profile ruta ga vraća
      username: res.username,
      email: '',
      first_name: '',
      last_name: '',
      phone: '',
      role: res.role,
      status: res.status,
      profile_picture_path: null,
      favorite_sports: null,
    };
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    this.currentUser.set(user);
  }

  private loadUserFromStorage(): AdminUserResponse | null {
    const raw = localStorage.getItem(this.USER_KEY);
    return raw ? JSON.parse(raw) : null;
  }

  private buildRegisterFormData(data: RegisterRequest): FormData {
    const fd = new FormData();
    fd.append('username', data.username);
    fd.append('password', data.password);
    fd.append('email', data.email);
    fd.append('first_name', data.first_name);
    fd.append('last_name', data.last_name);
    fd.append('phone', data.phone);
    fd.append('role', data.role);

    if (data.favorite_sports) {
      fd.append('favorite_sports', data.favorite_sports);
    }
    if (data.profile_image) {
      fd.append('profile_image', data.profile_image);
    }
    if (data.role === 'EMPLOYEE') {
      if (data.facility_name) fd.append('facility_name', data.facility_name);
      if (data.company_address) fd.append('company_address', data.company_address);
      if (data.company_id_number) fd.append('company_id_number', data.company_id_number);
      if (data.pib) fd.append('pib', data.pib);
    }
    return fd;
  }
}
