import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FacilityRequest, CourtRequest, RatingRequest, RatingEligibilityResponse } from '../models/models';

/**
 * Servis za kreiranje objekata, dodavanje terena i ocenjivanje.
 */
@Injectable({ providedIn: 'root' })
export class FacilityService {
  private http = inject(HttpClient);

  createFacilityFromFile(file: File): Observable<string> {
    const fd = new FormData();
    fd.append('file', file);
    return this.http.post('/api/facilities/create', fd, { responseType: 'text' });
  }

  createFacilityFromForm(req: FacilityRequest): Observable<string> {
    return this.http.post('/api/facilities/create-form', req, { responseType: 'text' });
  }

  addCourt(facilityId: number, req: CourtRequest): Observable<string> {
    return this.http.post(`/api/facilities/${facilityId}/courts`, req, { responseType: 'text' });
  }

  getRatingEligibility(facilityId: number): Observable<RatingEligibilityResponse> {
    return this.http.get<RatingEligibilityResponse>(`/api/facilities/${facilityId}/ratings/eligibility`);
  }

  addRating(facilityId: number, req: RatingRequest): Observable<string> {
    return this.http.post(`/api/facilities/${facilityId}/ratings`, req, { responseType: 'text' });
  }
}
