import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Equipment, Promotion, OrderResponse } from '../models/models';

/**
 * Servis za zaposlene — upravljanje opremom, promocijama i porudžbinama.
 */
@Injectable({ providedIn: 'root' })
export class EmployeeService {
  private http = inject(HttpClient);

  // ===== Equipment =====
  addEquipment(name: string, price: number, stock: number, sportType: string,
               description: string, file: File): Observable<string> {
    const fd = new FormData();
    fd.append('name', name);
    fd.append('price', price.toString());
    fd.append('stock', stock.toString());
    fd.append('sportType', sportType);
    fd.append('description', description);
    fd.append('file', file);
    return this.http.post('/api/employee/equipment', fd, { responseType: 'text' });
  }

  updateEquipmentPrice(id: number, newPrice: number): Observable<string> {
    return this.http.put(`/api/employee/equipment/${id}/price`, newPrice, { responseType: 'text' });
  }

  updateEquipmentStock(id: number, newStock: number): Observable<string> {
    return this.http.put(`/api/employee/equipment/${id}/stock`, newStock, { responseType: 'text' });
  }

  deleteEquipment(id: number): Observable<string> {
    return this.http.delete(`/api/employee/equipment/${id}`, { responseType: 'text' });
  }

  // ===== Promotions =====
  getPromotions(): Observable<Promotion[]> {
    return this.http.get<Promotion[]>('/api/employee/promotions');
  }

  createPromotion(p: Promotion): Observable<string> {
    return this.http.post('/api/employee/promotions', p, { responseType: 'text' });
  }

  updatePromotion(id: number, p: Promotion): Observable<string> {
    return this.http.put(`/api/employee/promotions/${id}`, p, { responseType: 'text' });
  }

  deletePromotion(id: number): Observable<string> {
    return this.http.delete(`/api/employee/promotions/${id}`, { responseType: 'text' });
  }

  // ===== Orders =====
  getAllOrders(): Observable<OrderResponse[]> {
    return this.http.get<OrderResponse[]>('/api/employee/dashboard/orders');
  }

  acceptOrder(orderId: number): Observable<string> {
    return this.http.put(`/api/employee/dashboard/orders/${orderId}/accept`, {}, { responseType: 'text' });
  }

  deliverOrder(orderId: number): Observable<string> {
    return this.http.put(`/api/employee/dashboard/orders/${orderId}/deliver`, {}, { responseType: 'text' });
  }

  cancelOrderAsStaff(orderId: number): Observable<string> {
    return this.http.put(`/api/employee/dashboard/orders/${orderId}/cancel`, {}, { responseType: 'text' });
  }

  // ===== Dashboard =====
  getCheckInTable(): Observable<any[]> {
    return this.http.get<any[]>('/api/employee/dashboard/table');
  }

  getPendingRequests(): Observable<any[]> {
    return this.http.get<any[]>('/api/employee/dashboard/pending');
  }

  getCalendarData(courtId: number, startDate: string, endDate: string): Observable<any[]> {
    return this.http.get<any[]>(
      `/api/employee/dashboard/calendar?court_id=${courtId}&startDate=${startDate}&endDate=${endDate}`
    );
  }

  checkIn(type: string, id: number, action: 'CONFIRM' | 'REJECT'): Observable<string> {
    return this.http.post(
      `/api/employee/dashboard/check-in?type=${type}&id=${id}&action=${action}`,
      {},
      { responseType: 'text' }
    );
  }

  decidePending(id: number, approve: boolean): Observable<string> {
    return this.http.post(
      `/api/employee/dashboard/pending/decide?id=${id}&approve=${approve}`,
      {},
      { responseType: 'text' }
    );
  }

  moveReservation(reservationId: number, newDate: string, newStartTime: string, newEndTime: string): Observable<string> {
    return this.http.put(
      `/api/employee/dashboard/move?reservationId=${reservationId}&newDate=${newDate}&newStartTime=${newStartTime}&newEndTime=${newEndTime}`,
      {},
      { responseType: 'text' }
    );
  }

  // ===== Reports =====
  getCourtUsageReport(month: string): Observable<Blob> {
    return this.http.get(`/api/employee/reports/court-usage?month=${month}`, { responseType: 'blob' });
  }

  getEquipmentSalesReport(month: string): Observable<Blob> {
    return this.http.get(`/api/employee/reports/equipment-sales?month=${month}`, { responseType: 'blob' });
  }
}
