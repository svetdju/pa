import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Equipment, OrderRequest, OrderResponse } from '../models/models';

/**
 * Servis za prodavnicu — katalog, kreiranje porudžbine i otkazivanje.
 */
@Injectable({ providedIn: 'root' })
export class ShopService {
  private http = inject(HttpClient);

  getCatalog(sportType: string): Observable<Equipment[]> {
    return this.http.get<Equipment[]>(`/api/shop/catalog?sport_type=${sportType}`);
  }

  placeOrder(req: OrderRequest): Observable<string> {
    return this.http.post('/api/shop/orders', req, { responseType: 'text' });
  }

  getMyOrders(): Observable<OrderResponse[]> {
    return this.http.get<OrderResponse[]>('/api/shop/orders/my');
  }

  cancelOrder(orderId: number): Observable<string> {
    return this.http.put(`/api/shop/orders/${orderId}/cancel`, {}, { responseType: 'text' });
  }
}
