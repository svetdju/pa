import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HomepageResponse, FacilityDetailsResponse, RatingSummaryResponse } from '../models/models';

/**
 * Servis za javne rute (dostupne i neregistrovanim korisnicima).
 * Homepage, pretraga objekata, detalji objekta, gradovi, ocene.
 */
@Injectable({ providedIn: 'root' })
export class PublicService {
  private http = inject(HttpClient);

  getHomepage(): Observable<HomepageResponse> {
    return this.http.get<HomepageResponse>('/api/public/homepage');
  }

  searchFacilities(filters: {
    name?: string;
    city?: string;
    type?: string;
    sport?: string;
  }): Observable<any[]> {
    let params = new HttpParams();
    if (filters.name) params = params.set('name', filters.name);
    if (filters.city) params = params.set('city', filters.city);
    if (filters.type) params = params.set('type', filters.type);
    if (filters.sport) params = params.set('sport', filters.sport);
    return this.http.get<any[]>('/api/public/facilities', { params });
  }

  getFacilityDetails(id: number): Observable<FacilityDetailsResponse> {
    return this.http.get<FacilityDetailsResponse>(`/api/public/facilities/${id}`);
  }

  getFacilityRatings(id: number): Observable<RatingSummaryResponse> {
    return this.http.get<RatingSummaryResponse>(`/api/public/facilities/${id}/ratings`);
  }

  getCities(): Observable<string[]> {
    return this.http.get<string[]>('/api/public/cities');
  }

  getSports(): Observable<string[]> {
    return this.http.get<string[]>('/api/sports/names');
  }

  getCourtReservations(courtId: number, date: string): Observable<any[]> {
    return this.http.get<any[]>(`/api/reservations/court/${courtId}?date=${date}`);
  }

  getCoaches(facilityId: number, sport: string): Observable<any[]> {
    return this.http.get<any[]>(`/api/trainings/coaches?facility_id=${facilityId}&sport=${sport}`);
  }

  getAllCoachesByFacility(facilityId: number): Observable<any[]> {
    return this.http.get<any[]>(`/api/trainings/facility/${facilityId}/coaches`);
  }
}
