import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StatisticsResponse } from '../models/models';

/**
 * Servis za statistiku sportiste — bar chart po sportu, line chart po mesecima,
 * ukupna potrošnja na opremu.
 */
@Injectable({ providedIn: 'root' })
export class StatisticsService {
  private http = inject(HttpClient);

  getMyStatistics(): Observable<StatisticsResponse> {
    return this.http.get<StatisticsResponse>('/api/statistics/my');
  }
}
