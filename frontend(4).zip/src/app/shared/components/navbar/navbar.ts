import { Component, inject, computed } from '@angular/core';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

/**
 * Navigacioni bar — prikazuje se na svim stranicama.
 * Meni se menja u zavisnosti od uloge korisnika (javno / sportista / zaposleni / admin).
 */
@Component({
  selector: 'app-navbar',
  imports: [RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './navbar.html',
})
export class Navbar {
  private auth = inject(AuthService);
  private router = inject(Router);

  readonly isLoggedIn = this.auth.isLoggedIn;
  readonly user = this.auth.user;
  readonly role = this.auth.role;
  readonly isAdmin = this.auth.isAdmin;
  readonly isEmployee = this.auth.isEmployee;
  readonly isAthlete = this.auth.isAthlete;

  /** Bootstrap dropdown kontrola (jednostavna toggle bez NgbDropdown-a) */
  menuOpen = false;

  toggleMenu(): void {
    this.menuOpen = !this.menuOpen;
  }

  closeMenu(): void {
    this.menuOpen = false;
  }

  logout(): void {
    this.closeMenu();
    this.auth.logout();
  }
}
