import { Component } from '@angular/core';

/**
 * Footer — prikazuje se na svim stranicama.
 */
@Component({
  selector: 'app-footer',
  template: `
    <footer class="bg-dark text-light py-4 mt-auto">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6">
            <h5 class="mb-1">SportSphere Hub</h5>
            <p class="mb-0 text-muted small">Vaša platforma za rezervaciju terena, treninge i opremu.</p>
          </div>
          <div class="col-md-6 text-md-end">
            <p class="mb-0 text-muted small">
              &copy; 2026 SportSphere Hub — ETF Beograd, IR3PIA
            </p>
          </div>
        </div>
      </div>
    </footer>
  `,
})
export class Footer {}
