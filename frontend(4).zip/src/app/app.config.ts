import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';

import { routes } from './app.routes';
import { jwtInterceptor } from './core/interceptors/jwt-interceptor';

/**
 * Glavna konfiguracija Angular aplikacije.
 *
 * - provideRouter sa withComponentInputBinding() omogućava da se parametri rute
 *   automatski mapiraju na @Input() polja komponenti.
 * - provideHttpClient sa jwtInterceptor-om automatski dodaje Authorization
 *   header na svaki zahtev ako korisnik ima token.
 * - provideAnimations je potreban za ng-bootstrap komponente (Modal, Tooltip).
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(withInterceptors([jwtInterceptor])),
    provideAnimations(),
  ],
};
