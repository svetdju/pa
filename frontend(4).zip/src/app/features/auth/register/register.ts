import { Component, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { PublicService } from '../../../core/services/public.service';

/**
 * Registracija — sportista ili zaposleni.
 *
 * Sportista: osnovni podaci + omiljeni sportovi (do 5) + profilna slika.
 * Zaposleni: osnovni podaci + podaci o firmi (facility_name, company_id_number, pib, company_address).
 *
 * Lozinka mora zadovoljiti regex: 8-12 karaktera, počinje slovom, veliko slovo,
 * broj i specijalni karakter.
 *
 * Nakon uspešne registracije:
 * - Ako je status APPROVED → preusmeri na profil
 * - Ako je status PENDING → preusmeri na pending-approval stranicu
 */
@Component({
  selector: 'app-register',
  imports: [FormsModule],
  templateUrl: './register.html',
})
export class Register {
  private auth = inject(AuthService);
  private publicSvc = inject(PublicService);
  private router = inject(Router);

  // Osnovni podaci
  username = '';
  password = '';
  email = '';
  firstName = '';
  lastName = '';
  phone = '';
  role: 'ATHLETE' | 'EMPLOYEE' = 'ATHLETE';

  // Sportista
  availableSports: string[] = [];
  selectedSports: string[] = [];

  // Zaposleni
  facilityName = '';
  companyIdNumber = '';
  pib = '';
  companyAddress = '';

  // Slika
  profileImage: File | null = null;
  imagePreview = signal<string | null>(null);

  error = signal<string | null>(null);
  loading = signal(false);

  readonly isAthlete = computed(() => this.role === 'ATHLETE');

  constructor() {
    this.publicSvc.getSports().subscribe(sports => this.availableSports = sports);
  }

  onImageSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.profileImage = input.files[0];
      const reader = new FileReader();
      reader.onload = () => this.imagePreview.set(reader.result as string);
      reader.readAsDataURL(this.profileImage);
    }
  }

  toggleSport(sport: string): void {
    const idx = this.selectedSports.indexOf(sport);
    if (idx >= 0) {
      this.selectedSports.splice(idx, 1);
    } else if (this.selectedSports.length < 5) {
      this.selectedSports.push(sport);
    }
  }

  isSportSelected(sport: string): boolean {
    return this.selectedSports.includes(sport);
  }

  submit(): void {
    this.error.set(null);

    // Validacija lozinke (regex iz postavke)
    const pwdRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9])[a-zA-Z].{7,11}$/;
    if (!pwdRegex.test(this.password)) {
      this.error.set('Lozinka mora imati 8-12 karaktera, počinjati slovom, i sadržati bar jedno veliko slovo, broj i specijalni karakter.');
      return;
    }

    if (this.role === 'EMPLOYEE') {
      // Validacija PIB-a (9 cifara, ne počinje nulom) i matičnog broja (8 cifara)
      if (!/^\d{8}$/.test(this.companyIdNumber)) {
        this.error.set('Matični broj firme mora imati tačno 8 cifara.');
        return;
      }
      if (!/^[1-9]\d{8}$/.test(this.pib)) {
        this.error.set('PIB mora imati tačno 9 cifara i ne sme počinjati nulom.');
        return;
      }
      if (!this.facilityName || !this.companyAddress) {
        this.error.set('Naziv objekta i adresa firme su obavezni za zaposlene.');
        return;
      }
    }

    this.loading.set(true);

    const data = {
      username: this.username,
      password: this.password,
      email: this.email,
      first_name: this.firstName,
      last_name: this.lastName,
      phone: this.phone,
      role: this.role,
      favorite_sports: this.role === 'ATHLETE' ? this.selectedSports.join(',') : undefined,
      profile_image: this.profileImage ?? undefined,
      facility_name: this.role === 'EMPLOYEE' ? this.facilityName : undefined,
      company_address: this.role === 'EMPLOYEE' ? this.companyAddress : undefined,
      company_id_number: this.role === 'EMPLOYEE' ? this.companyIdNumber : undefined,
      pib: this.role === 'EMPLOYEE' ? this.pib : undefined,
    };

    this.auth.register(data).subscribe({
      next: (res) => {
        this.loading.set(false);
        if (res.status === 'PENDING') {
          this.router.navigate(['/pending-approval']);
        } else {
          this.router.navigate(['/profile']);
        }
      },
      error: (err) => {
        this.loading.set(false);
        this.error.set(this.parseError(err));
      },
    });
  }

  /**
   * Parsira HTTP grešku iz backend-a. Backend vraća plain text poruku
   * (npr. "Korisničko ime 'X' je već zauzeto.") u error.body.
   */
  private parseError(err: any): string {
    if (err.status === 0) {
      return 'Nije moguće povezati se sa serverom. Proverite da li je backend pokrenut.';
    }
    if (err.status === 404) {
      return 'Ruta nije pronađena. Proverite da li backend radi.';
    }
    const body = err.error;
    if (typeof body === 'string') {
      // Ako je HTML (Cannot POST), izvuci tekst
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        const match = body.match(/<pre>(.*?)<\/pre>/);
        return match ? `Server greška: ${match[1]}` : 'Server greška.';
      }
      return body;
    }
    if (body?.message) return body.message;
    return 'Greška pri registraciji. Pokušajte ponovo.';
  }
}
