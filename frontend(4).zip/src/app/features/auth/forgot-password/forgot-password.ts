import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

/**
 * Zaboravljena lozinka — korisnik unosi korisničko ime ili email,
 * backend generiše reset token (koji se u ovoj demo verziji vraća direktno
 * umesto da se šalje email-om).
 */
@Component({
  selector: 'app-forgot-password',
  imports: [FormsModule],
  templateUrl: './forgot-password.html',
})
export class ForgotPassword {
  private auth = inject(AuthService);
  private router = inject(Router);

  identifier = '';
  message = signal<string | null>(null);
  error = signal<string | null>(null);
  loading = signal(false);
  resetToken = signal<string | null>(null);

  submit(): void {
    if (!this.identifier.trim()) {
      this.error.set('Unesite korisničko ime ili email.');
      return;
    }

    this.loading.set(true);
    this.error.set(null);
    this.message.set(null);

    this.auth.requestPasswordReset(this.identifier).subscribe({
      next: (res: any) => {
        this.loading.set(false);
        this.message.set(res.message || 'Ako nalog postoji, reset link je generisan.');
        // U demo verziji backend vraća token direktno
        if (res.token) {
          this.resetToken.set(res.token);
        }
      },
      error: () => {
        this.loading.set(false);
        this.error.set('Greška pri slanju zahteva.');
      },
    });
  }

  goToReset(): void {
    if (this.resetToken()) {
      this.router.navigate(['/reset-password', this.resetToken()]);
    }
  }
}
