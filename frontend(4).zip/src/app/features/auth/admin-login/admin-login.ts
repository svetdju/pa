import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

/**
 * Admin login — skrivena ruta za administratorsku prijavu.
 * Ista logika kao običan login, ali sa napomenom da je za administratore.
 */
@Component({
  selector: 'app-admin-login',
  imports: [FormsModule],
  templateUrl: './admin-login.html',
})
export class AdminLogin {
  private auth = inject(AuthService);
  private router = inject(Router);

  username = '';
  password = '';
  error = signal<string | null>(null);
  loading = signal(false);

  submit(): void {
    if (!this.username || !this.password) {
      this.error.set('Unesite korisničko ime i lozinku.');
      return;
    }

    this.loading.set(true);
    this.error.set(null);

    this.auth.login({ username: this.username, password: this.password }).subscribe({
      next: (res) => {
        this.loading.set(false);
        if (res.role === 'ADMIN') {
          this.router.navigate(['/admin']);
        } else {
          this.error.set('Ova ruta je samo za administratore.');
          this.auth.logout();
        }
      },
      error: () => {
        this.loading.set(false);
        this.error.set('Neispravni administratorski kreditencijali.');
      },
    });
  }
}
