import { Component, inject, signal, input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

/**
 * Reset lozinke — korisnik unosi novu lozinku koristeći token iz URL-a.
 * Token se proverava kod backend-a; ako je nevalidan/istekao, prikazuje se greška.
 */
@Component({
  selector: 'app-reset-password',
  imports: [FormsModule],
  templateUrl: './reset-password.html',
})
export class ResetPassword {
  private auth = inject(AuthService);
  private router = inject(Router);

  /** Token iz URL rute /reset-password/:token */
  token = input<string>('');

  newPassword = '';
  confirmPassword = '';
  error = signal<string | null>(null);
  loading = signal(false);

  submit(): void {
    this.error.set(null);

    if (this.newPassword !== this.confirmPassword) {
      this.error.set('Lozinke se ne poklapaju.');
      return;
    }

    const pwdRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9])[a-zA-Z].{7,11}$/;
    if (!pwdRegex.test(this.newPassword)) {
      this.error.set('Lozinka mora imati 8-12 karaktera, počinjati slovom, i sadržati bar jedno veliko slovo, broj i specijalni karakter.');
      return;
    }

    this.loading.set(true);
    this.auth.resetPassword(this.token(), this.newPassword).subscribe({
      next: (res: any) => {
        this.loading.set(false);
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.loading.set(false);
        const msg = err.error?.error || err.error;
        this.error.set(typeof msg === 'string' ? msg : 'Token je nevažeći ili je istekao.');
      },
    });
  }
}
