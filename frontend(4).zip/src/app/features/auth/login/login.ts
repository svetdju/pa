import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

/**
 * Login stranica — prijava za sportiste i zaposlene.
 * Admin se prijavljuje preko posebne skrivene rute (/admin-login).
 */
@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
})
export class Login {
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  username = '';
  password = '';
  error = signal<string | null>(null);
  loading = signal(false);

  submit(): void {
    this.error.set(null);

    if (!this.username.trim() || !this.password) {
      this.error.set('Unesite korisničko ime i lozinku.');
      return;
    }

    this.loading.set(true);

    this.auth.login({ username: this.username.trim(), password: this.password }).subscribe({
      next: (res) => {
        this.loading.set(false);

        // Ako korisnik nije APPROVED, ne može da se uloguje
        if (res.status !== 'APPROVED') {
          this.error.set('Vaš nalog nije odobren. Sačekajte administratorsko odobrenje.');
          this.auth.logout();
          return;
        }

        // Preusmeri na returnUrl ili na odgovarajući dashboard po ulozi
        const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
        if (returnUrl) {
          this.router.navigateByUrl(returnUrl);
        } else if (res.role === 'ADMIN') {
          this.router.navigate(['/admin']);
        } else if (res.role === 'EMPLOYEE') {
          this.router.navigate(['/employee/dashboard']);
        } else {
          this.router.navigate(['/profile']);
        }
      },
      error: (err) => {
        this.loading.set(false);
        this.error.set(this.parseError(err));
      },
    });
  }

  /**
   * Parsira HTTP grešku i vraća korisničku poruku.
   * Backend vraća tekstualnu poruku (npr. "Neispravno korisničko ime ili lozinka.")
   * ili JSON sa message poljem. Ako je proxy pao, err.error je HTML.
   */
  private parseError(err: any): string {
    // Ako je mrežna greška (proxy ne radi, backend ugašen)
    if (err.status === 0) {
      return 'Nije moguće povezati se sa serverom. Proverite da li je backend pokrenut na http://localhost:8080';
    }
    // 404 - rute ne postoje na backendu (Cannot POST /api/auth/login)
    if (err.status === 404) {
      return 'Ruta nije pronađena. Proverite da li je backend pokrenut i da li proxy radi.';
    }
    // 401/403 - neispravni kreditencijali ili nalog nije odobren
    if (err.status === 401 || err.status === 403) {
      const body = err.error;
      if (typeof body === 'string') return body;
      if (body?.message) return body.message;
      return 'Neispravno korisničko ime ili lozinka.';
    }
    // Ostale greške — pokušavamo da izvučemo poruku
    const body = err.error;
    if (typeof body === 'string') {
      // Ako je HTML (Cannot POST), izvuci tekst iz <pre> taga
      if (body.startsWith('<!DOCTYPE') || body.startsWith('<html')) {
        const match = body.match(/<pre>(.*?)<\/pre>/);
        return match ? `Server greška: ${match[1]}` : 'Server greška.';
      }
      return body;
    }
    if (body?.message) return body.message;
    return 'Greška pri prijavi. Pokušajte ponovo.';
  }

  goToRegister(): void {
    this.router.navigate(['/register']);
  }

  goToForgotPassword(): void {
    this.router.navigate(['/forgot-password']);
  }
}
