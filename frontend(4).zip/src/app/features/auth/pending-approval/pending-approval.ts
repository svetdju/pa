import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

/**
 * Stranica koja se prikazuje nakon registracije ako je korisnikov status PENDING.
 * Obaveštava korisnika da čeka odobrenje administratora.
 */
@Component({
  selector: 'app-pending-approval',
  imports: [RouterLink],
  template: `
    <div class="container-app" style="max-width: 500px;">
      <div class="card shadow-sm mt-5 text-center">
        <div class="card-body p-5">
          <div class="display-1 text-warning mb-3">
            <i class="bi bi-clock-history"></i>
          </div>
          <h2>Nalog čeka odobrenje</h2>
          <p class="text-muted mb-4">
            Vaš nalog je uspešno kreiran, ali administrator mora da ga odobri
            pre nego što se budete mogli prijaviti.
          </p>
          <p class="text-muted small mb-4">
            Prijavite se kasnije da proverite status vašeg naloga.
          </p>
          <a routerLink="/login" class="btn btn-primary">Nazad na prijavu</a>
        </div>
      </div>
    </div>
  `,
})
export class PendingApproval {}
