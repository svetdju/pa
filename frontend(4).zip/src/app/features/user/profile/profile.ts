import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../../core/services/user.service';
import { ReservationService } from '../../../core/services/reservation.service';
import { TrainingService } from '../../../core/services/training.service';
import { ShopService } from '../../../core/services/shop.service';
import { AuthService } from '../../../core/services/auth.service';
import { AdminUserResponse, ReservationResponse, TrainingResponse, OrderResponse } from '../../../core/models/models';

/**
 * Profil sportiste — prikazuje lične podatke, omiljene sportove, profilnu sliku,
 * i tabele sa rezervacijama, treninzima i porudžbinama.
 *
 * Dozvoljeno ažuriranje: ime, prezime, telefon, email, omiljeni sportovi, slika.
 * Ne može se menjati korisničko ime.
 */
@Component({
  selector: 'app-profile',
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.html',
})
export class Profile implements OnInit {
  private userSvc = inject(UserService);
  private reservationSvc = inject(ReservationService);
  private trainingSvc = inject(TrainingService);
  private shopSvc = inject(ShopService);
  private auth = inject(AuthService);

  profile = signal<AdminUserResponse | null>(null);
  reservations = signal<ReservationResponse[]>([]);
  trainings = signal<TrainingResponse[]>([]);
  orders = signal<OrderResponse[]>([]);

  loading = signal(true);

  // Edit mode
  editing = signal(false);
  editFirstName = '';
  editLastName = '';
  editPhone = '';
  editEmail = '';
  editSports = '';

  // Slika
  imageFile: File | null = null;
  imagePreview = signal<string | null>(null);

  // Tab
  activeTab = signal<'reservations' | 'trainings' | 'orders'>('reservations');

  // Sortiranje rezervacija
  sortColumn = 'reservation_date';
  sortAsc = false;

  readonly isLoggedIn = this.auth.isLoggedIn;
  readonly isAthlete = this.auth.isAthlete;

  ngOnInit(): void {
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    this.userSvc.getMyProfile().subscribe({
      next: (p) => {
        this.profile.set(p);
        this.editFirstName = p.first_name;
        this.editLastName = p.last_name;
        this.editPhone = p.phone;
        this.editEmail = p.email;
        this.editSports = p.favorite_sports || '';
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
      },
    });

    if (this.isAthlete()) {
      this.reservationSvc.getMyReservations().subscribe(r => this.reservations.set(r));
      this.trainingSvc.getMyTrainings().subscribe(t => this.trainings.set(t));
      this.shopSvc.getMyOrders().subscribe(o => this.orders.set(o));
    }
  }

  startEdit(): void {
    this.editing.set(true);
  }

  cancelEdit(): void {
    this.editing.set(false);
    const p = this.profile();
    if (p) {
      this.editFirstName = p.first_name;
      this.editLastName = p.last_name;
      this.editPhone = p.phone;
      this.editEmail = p.email;
      this.editSports = p.favorite_sports || '';
    }
  }

  saveEdit(): void {
    this.userSvc.updateProfile({
      first_name: this.editFirstName,
      last_name: this.editLastName,
      phone: this.editPhone,
      email: this.editEmail,
    }).subscribe({
      next: () => {
        // Ažuriramo i omiljene sportove
        this.userSvc.updateFavoriteSports(this.editSports).subscribe(() => {
          this.loadAll();
          this.editing.set(false);
        });
      },
    });
  }

  onImageSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.imageFile = input.files[0];
      const reader = new FileReader();
      reader.onload = () => this.imagePreview.set(reader.result as string);
      reader.readAsDataURL(this.imageFile);
    }
  }

  uploadImage(): void {
    if (!this.imageFile) return;
    this.userSvc.updateProfileImage(this.imageFile).subscribe({
      next: () => {
        this.loadAll();
        this.imageFile = null;
        this.imagePreview.set(null);
      },
    });
  }

  cancelReservation(id: number): void {
    if (!confirm('Otkazati rezervaciju?')) return;
    this.reservationSvc.cancelReservation(id).subscribe({
      next: () => this.reservationSvc.getMyReservations().subscribe(r => this.reservations.set(r)),
      error: (err) => alert(err.error || 'Greška pri otkazivanju.'),
    });
  }

  cancelOrder(id: number): void {
    if (!confirm('Otkazati porudžbinu?')) return;
    this.shopSvc.cancelOrder(id).subscribe({
      next: () => this.shopSvc.getMyOrders().subscribe(o => this.orders.set(o)),
      error: (err) => alert(err.error || 'Greška pri otkazivanju.'),
    });
  }

  sortBy(col: string): void {
    if (this.sortColumn === col) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortColumn = col;
      this.sortAsc = true;
    }
  }

  sortIcon(col: string): string {
    if (this.sortColumn !== col) return '↕';
    return this.sortAsc ? '↑' : '↓';
  }

  get sortedReservations(): ReservationResponse[] {
    const sorted = [...this.reservations()];
    sorted.sort((a, b) => {
      let va = (a as any)[this.sortColumn];
      let vb = (b as any)[this.sortColumn];
      if (typeof va === 'string') va = va.toLowerCase();
      if (typeof vb === 'string') vb = vb.toLowerCase();
      if (va < vb) return this.sortAsc ? -1 : 1;
      if (va > vb) return this.sortAsc ? 1 : -1;
      return 0;
    });
    return sorted;
  }

  statusBadgeClass(status: string): string {
    const map: Record<string, string> = {
      'PENDING': 'badge-pending',
      'CONFIRMED': 'badge-confirmed',
      'COMPLETED': 'badge-completed',
      'CANCELLED': 'badge-cancelled',
      'ABSENT': 'badge-absent',
      'SCHEDULED': 'badge-scheduled',
      'ORDERED': 'badge-ordered',
      'ACCEPTED': 'badge-accepted',
      'DELIVERED': 'badge-delivered',
      'APPROVED': 'badge-approved',
      'REJECTED': 'badge-rejected',
    };
    return map[status] || 'bg-secondary';
  }
}
