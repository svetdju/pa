import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ShopService } from '../../../core/services/shop.service';
import { PublicService } from '../../../core/services/public.service';
import { Equipment, CartItemRequest } from '../../../core/models/models';

/**
 * Prodavnica — katalog opreme po sportu, korpa i naručivanje.
 */
@Component({
  selector: 'app-shop',
  imports: [CommonModule, FormsModule],
  templateUrl: './shop.html',
})
export class Shop implements OnInit {
  private shopSvc = inject(ShopService);
  private publicSvc = inject(PublicService);

  sports: string[] = [];
  selectedSport = signal<string>('');
  catalog = signal<Equipment[]>([]);
  cart = signal<CartItemRequest[]>([]);
  loading = signal(false);
  message = signal<string | null>(null);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.publicSvc.getSports().subscribe(s => {
      this.sports = s;
      if (s.length > 0) {
        this.selectedSport.set(s[0]);
        this.loadCatalog();
      }
    });
  }

  loadCatalog(): void {
    this.loading.set(true);
    this.shopSvc.getCatalog(this.selectedSport()).subscribe({
      next: (res) => {
        this.catalog.set(res);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Greška pri učitavanju kataloga.');
        this.loading.set(false);
      },
    });
  }

  selectSport(sport: string): void {
    this.selectedSport.set(sport);
    this.loadCatalog();
  }

  addToCart(eq: Equipment): void {
    const existing = this.cart().find(i => i.equipment_id === eq.id);
    if (existing) {
      existing.quantity++;
      this.cart.set([...this.cart()]);
    } else {
      this.cart.update(c => [...c, { equipment_id: eq.id, quantity: 1 }]);
    }
  }

  removeFromCart(idx: number): void {
    this.cart.update(c => c.filter((_, i) => i !== idx));
  }

  updateQty(idx: number, delta: number): void {
    const cart = this.cart();
    cart[idx].quantity += delta;
    if (cart[idx].quantity <= 0) {
      this.removeFromCart(idx);
    } else {
      this.cart.set([...cart]);
    }
  }

  cartItemCount = signal(0);

  get cartTotal(): number {
    return this.cart().reduce((sum, item) => {
      const eq = this.catalog().find(e => e.id === item.equipment_id);
      return sum + (eq ? eq.price * item.quantity : 0);
    }, 0);
  }

  get cartItems() {
    return this.cart().map(item => {
      const eq = this.catalog().find(e => e.id === item.equipment_id);
      return { ...item, equipment: eq };
    });
  }

  checkout(): void {
    if (this.cart().length === 0) return;
    this.message.set(null);
    this.error.set(null);

    this.shopSvc.placeOrder({ items: this.cart() }).subscribe({
      next: (res) => {
        this.message.set(res);
        this.cart.set([]);
      },
      error: (err) => {
        this.error.set(err.error || 'Greška pri naručivanju.');
      },
    });
  }
}
