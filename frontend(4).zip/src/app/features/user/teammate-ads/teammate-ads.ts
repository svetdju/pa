import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TeammateAdService } from '../../../core/services/teammate-ad.service';
import { PublicService } from '../../../core/services/public.service';
import { AdResponse, AdResponseDetails, AdRequest } from '../../../core/models/models';

/**
 * Oglasi "tražim saigrače" — oglasna tabla, kreiranje oglasa i upravljanje prijavama.
 */
@Component({
  selector: 'app-teammate-ads',
  imports: [CommonModule, FormsModule],
  templateUrl: './teammate-ads.html',
})
export class TeammateAds implements OnInit {
  private adSvc = inject(TeammateAdService);
  private publicSvc = inject(PublicService);

  activeAds = signal<AdResponse[]>([]);
  myAds = signal<AdResponseDetails[]>([]);
  myResponses = signal<any[]>([]);

  sports: string[] = [];
  loading = signal(true);

  // Forma za novi oglas
  showForm = signal(false);
  newAd: AdRequest = { sport: '', city: '', event_date: '', event_time: '', players_needed: 1 };

  // Toast
  message = signal<string | null>(null);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.publicSvc.getSports().subscribe(s => this.sports = s);
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    this.adSvc.getActiveAds().subscribe({
      next: (ads) => {
        this.activeAds.set(ads);
        this.loading.set(false);
      },
    });
    this.adSvc.getMyAds().subscribe(d => this.myAds.set(d));
    this.adSvc.getMyResponses().subscribe(r => this.myResponses.set(r));
  }

  toggleForm(): void {
    this.showForm.update(v => !v);
    if (!this.showForm()) {
      this.newAd = { sport: '', city: '', event_date: '', event_time: '', players_needed: 1 };
    }
  }

  createAd(): void {
    if (!this.newAd.sport || !this.newAd.city || !this.newAd.event_date || !this.newAd.event_time) {
      this.error.set('Sva polja su obavezna.');
      return;
    }
    this.adSvc.createAd(this.newAd).subscribe({
      next: () => {
        this.message.set('Oglas uspešno postavljen!');
        this.toggleForm();
        this.loadAll();
      },
      error: (err) => this.error.set(err.error || 'Greška pri kreiranju oglasa.'),
    });
  }

  respondToAd(adId: number): void {
    this.adSvc.respondToAd(adId).subscribe({
      next: () => {
        this.message.set('Zahtev poslat!');
        this.loadAll();
      },
      error: (err) => this.error.set(err.error || 'Greška pri prijavi na oglas.'),
    });
  }

  hasResponded(adId: number): boolean {
    return this.myResponses().some(r => r.ad_id === adId);
  }

  responseStatus(adId: number): string {
    const r = this.myResponses().find(r => r.ad_id === adId);
    return r?.status || '';
  }

  approveResponse(adId: number, responseId: number): void {
    this.adSvc.handleResponse(responseId, 'APPROVED').subscribe({
      next: () => this.loadAll(),
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }

  rejectResponse(adId: number, responseId: number): void {
    this.adSvc.handleResponse(responseId, 'REJECTED').subscribe({
      next: () => this.loadAll(),
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }

  closeAd(adId: number): void {
    if (!confirm('Zatvoriti oglas?')) return;
    this.adSvc.closeAd(adId).subscribe({
      next: () => this.loadAll(),
    });
  }

  dismissMessage(): void {
    this.message.set(null);
    this.error.set(null);
  }
}
