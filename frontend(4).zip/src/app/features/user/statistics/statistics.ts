import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration } from 'chart.js';
import { StatisticsService } from '../../../core/services/statistics.service';

/**
 * Statistika sportiste — tri dijagrama:
 * 1. Bar chart: broj rezervacija po sportu
 * 2. Line chart: mesečna aktivnost (rezervacije + treninzi)
 * 3. Ukupna potrošnja na opremu
 *
 * ng2-charts v7 zahteva eksplicitnu registraciju chart kontrolera,
 * jer se inače javlja greška "bar is not a registered controller".
 */
@Component({
  selector: 'app-statistics',
  imports: [CommonModule, BaseChartDirective],
  templateUrl: './statistics.html',
})
export class Statistics implements OnInit {
  private statsSvc = inject(StatisticsService);

  data = signal<any>(null);
  loading = signal(true);
  error = signal<string | null>(null);
  totalSpending = signal(0);

  // Bar chart: rezervacije po sportu
  barChartData = signal<ChartConfiguration<'bar'>['data']>({
    labels: [],
    datasets: [{ label: 'Rezervacije', data: [], backgroundColor: '#2563eb' }],
  });
  barChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true,
    plugins: { legend: { display: true } },
  };

  // Line chart: mesečna aktivnost
  lineChartData = signal<ChartConfiguration<'line'>['data']>({
    labels: [],
    datasets: [{ label: 'Aktivnost', data: [], borderColor: '#2563eb', fill: true }],
  });
  lineChartOptions: ChartConfiguration<'line'>['options'] = {
    responsive: true,
    plugins: { legend: { display: true } },
  };

  ngOnInit(): void {
    this.statsSvc.getMyStatistics().subscribe({
      next: (res) => {
        this.data.set(res);
        this.totalSpending.set(res.totalSpendingOnEquipment);

        this.barChartData.set({
          labels: res.reservationsBySport.map((r: any) => r.sport),
          datasets: [{
            label: 'Broj rezervacija',
            data: res.reservationsBySport.map((r: any) => Number(r.count)),
            backgroundColor: '#2563eb',
          }],
        });

        this.lineChartData.set({
          labels: res.monthlyActivity.map((m: any) => m.month_label),
          datasets: [{
            label: 'Aktivnost po mesecu',
            data: res.monthlyActivity.map((m: any) => Number(m.count)),
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            fill: true,
          }],
        });

        this.loading.set(false);
      },
      error: (err) => {
        console.error('[Statistics] Greška:', err);
        this.error.set('Greška pri učitavanju statistike.');
        this.loading.set(false);
      },
    });
  }
}
