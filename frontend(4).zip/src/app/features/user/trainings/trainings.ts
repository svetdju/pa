import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TrainingService } from '../../../core/services/training.service';
import { PublicService } from '../../../core/services/public.service';
import { TrainingResponse, TrainingRequest } from '../../../core/models/models';

/**
 * Individualni treninzi — pregled trenera po objektu, zakazivanje i arhiva.
 */
@Component({
  selector: 'app-trainings',
  imports: [CommonModule, FormsModule],
  templateUrl: './trainings.html',
})
export class Trainings implements OnInit {
  private trainingSvc = inject(TrainingService);
  private publicSvc = inject(PublicService);

  myTrainings = signal<TrainingResponse[]>([]);
  sports: string[] = [];

  // Pregled trenera
  facilities = signal<any[]>([]);
  selectedFacilityId: number | null = null;
  selectedSport = '';
  coaches = signal<any[]>([]);
  allFacilityCoaches = signal<any[]>([]);

  // Forma za zakazivanje
  selectedCoachId: number | null = null;
  selectedCourtId: number | null = null;
  trainingDate = '';
  startTime = '';
  endTime = '';

  message = signal<string | null>(null);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.publicSvc.searchFacilities({}).subscribe(f => this.facilities.set(f));
    this.publicSvc.getSports().subscribe(s => this.sports = s);
    this.loadMyTrainings();
  }

  private loadMyTrainings(): void {
    this.trainingSvc.getMyTrainings().subscribe(t => this.myTrainings.set(t));
  }

  onFacilityChange(): void {
    if (this.selectedFacilityId) {
      this.publicSvc.getAllCoachesByFacility(this.selectedFacilityId).subscribe(c => this.allFacilityCoaches.set(c));
      this.loadCoaches();
    }
  }

  onSportChange(): void {
    this.loadCoaches();
  }

  private loadCoaches(): void {
    if (this.selectedFacilityId && this.selectedSport) {
      this.publicSvc.getCoaches(this.selectedFacilityId, this.selectedSport).subscribe(c => this.coaches.set(c));
    } else {
      this.coaches.set([]);
    }
  }

  scheduleTraining(coach: any): void {
    if (!this.trainingDate || !this.startTime || !this.endTime) {
      this.error.set('Popunite datum i vreme.');
      return;
    }
    // Nađi teren u istom objektu sa istim sportom
    this.publicSvc.getFacilityDetails(this.selectedFacilityId!).subscribe({
      next: (details) => {
        const court = details.courts.find(c => c.sportType === coach.sport);
        if (!court) {
          this.error.set('Nema odgovarajućeg terena za taj sport.');
          return;
        }
        const req: TrainingRequest = {
          coach_id: coach.id,
          court_id: court.id,
          training_date: this.trainingDate,
          start_time: this.startTime.length === 5 ? this.startTime + ':00' : this.startTime,
          end_time: this.endTime.length === 5 ? this.endTime + ':00' : this.endTime,
        };
        this.trainingSvc.scheduleTraining(req).subscribe({
          next: () => {
            this.message.set('Trening uspešno zakazan!');
            this.error.set(null);
            this.loadMyTrainings();
          },
          error: (err) => this.error.set(err.error || 'Greška pri zakazivanju.'),
        });
      },
    });
  }
}
