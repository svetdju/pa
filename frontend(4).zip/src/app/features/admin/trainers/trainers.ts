import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../core/services/admin.service';
import { Coach } from '../../../core/models/models';

/**
 * Admin — pregled i deaktiviranje trenera.
 */
@Component({
  selector: 'app-trainers',
  imports: [CommonModule],
  template: `
    <div class="container-app">
      <h2 class="mb-3">Treneri</h2>

      @if (message()) { <div class="alert alert-success py-2">{{ message() }}</div> }

      <div class="table-responsive">
        <table class="table table-sm table-hover">
          <thead><tr><th>ID</th><th>Ime</th><th>Specijalizacija</th><th>Sport</th><th>Cena/sat</th><th>Ocena</th><th>Aktivan</th><th></th></tr></thead>
          <tbody>
            @for (c of coaches(); track c.id) {
              <tr>
                <td>{{ c.id }}</td>
                <td>{{ c.name }}</td>
                <td class="small">{{ c.specialization }}</td>
                <td>{{ c.sport }}</td>
                <td>{{ c.pricePerHour | number:'1.0-0' }} RSD</td>
                <td>⭐ {{ c.averageRating }}</td>
                <td>
                  <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" [checked]="c.isActive" (change)="toggle(c)">
                  </div>
                </td>
                <td>—</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
})
export class Trainers implements OnInit {
  private adminSvc = inject(AdminService);

  coaches = signal<Coach[]>([]);
  message = signal<string | null>(null);

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.adminSvc.getAllCoaches().subscribe(c => this.coaches.set(c));
  }

  toggle(c: Coach): void {
    this.adminSvc.updateCoachActiveStatus(c.id, !c.isActive).subscribe({
      next: () => { this.message.set('Status trenera ažuriran.'); this.load(); },
    });
  }
}
