import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../core/services/admin.service';
import { PublicService } from '../../../core/services/public.service';
import { Sport } from '../../../core/models/models';

/**
 * Admin — dodavanje novih sportova u katalog.
 */
@Component({
  selector: 'app-sports',
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container-app" style="max-width: 600px;">
      <h2 class="mb-3">Sportovi</h2>

      @if (message()) { <div class="alert alert-success py-2">{{ message() }}</div> }
      @if (error()) { <div class="alert alert-danger py-2">{{ error() }}</div> }

      <div class="card mb-3">
        <div class="card-header">Dodaj sport</div>
        <div class="card-body">
          <div class="mb-2">
            <label class="form-label small">Naziv</label>
            <input class="form-control form-control-sm" [(ngModel)]="newSport.name">
          </div>
          <div class="mb-2">
            <label class="form-label small">Opis</label>
            <textarea class="form-control form-control-sm" rows="2" [(ngModel)]="newSport.description"></textarea>
          </div>
          <button class="btn btn-primary btn-sm" (click)="addSport()">Dodaj</button>
        </div>
      </div>

      <h6>Postojeći sportovi</h6>
      <div class="d-flex flex-wrap gap-2">
        @for (s of sports(); track s) {
          <span class="badge bg-primary fs-6">{{ s }}</span>
        }
      </div>
    </div>
  `,
})
export class Sports implements OnInit {
  private adminSvc = inject(AdminService);
  private publicSvc = inject(PublicService);

  sports = signal<string[]>([]);
  newSport: Sport = { id: 0, name: '', description: '' };
  message = signal<string | null>(null);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.loadSports();
  }

  private loadSports(): void {
    this.publicSvc.getSports().subscribe(s => this.sports.set(s));
  }

  addSport(): void {
    if (!this.newSport.name.trim()) {
      this.error.set('Naziv je obavezan.');
      return;
    }
    this.adminSvc.addSport(this.newSport).subscribe({
      next: () => {
        this.message.set('Sport dodat!');
        this.error.set(null);
        this.newSport = { id: 0, name: '', description: '' };
        this.loadSports();
      },
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }
}
