import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../core/services/admin.service';
import { AdminUserResponse } from '../../../core/models/models';

/**
 * Admin — pregled i odobravanje/odbijanje PENDING registracija korisnika.
 */
@Component({
  selector: 'app-reg-request',
  imports: [CommonModule],
  template: `
    <div class="container-app">
      <h2 class="mb-3">Registracije na čekanju</h2>

      @if (message()) { <div class="alert alert-success py-2">{{ message() }}</div> }

      <div class="table-responsive">
        <table class="table table-sm table-hover">
          <thead><tr><th>Korisnik</th><th>Ime</th><th>Email</th><th>Telefon</th><th>Uloga</th><th>Status</th><th>Akcije</th></tr></thead>
          <tbody>
            @for (u of pendingUsers(); track u.id) {
              <tr>
                <td>{{ u.username }}</td>
                <td>{{ u.first_name }} {{ u.last_name }}</td>
                <td>{{ u.email }}</td>
                <td>{{ u.phone }}</td>
                <td><span class="badge bg-primary">{{ u.role }}</span></td>
                <td><span class="badge badge-pending">{{ u.status }}</span></td>
                <td>
                  <button class="btn btn-sm btn-success me-1" (click)="approve(u.id)">Odobri</button>
                  <button class="btn btn-sm btn-outline-danger" (click)="reject(u.id)">Odbij</button>
                </td>
              </tr>
            } @empty {
              <tr><td colspan="7" class="text-center text-muted">Nema registracija na čekanju</td></tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
})
export class RegRequest implements OnInit {
  private adminSvc = inject(AdminService);

  pendingUsers = signal<AdminUserResponse[]>([]);
  message = signal<string | null>(null);

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.adminSvc.getAllUsers().subscribe(users => {
      this.pendingUsers.set(users.filter(u => u.status === 'PENDING'));
    });
  }

  approve(id: number): void {
    this.adminSvc.updateUserStatus(id, 'APPROVED').subscribe({
      next: () => { this.message.set('Korisnik odobren!'); this.load(); },
    });
  }

  reject(id: number): void {
    this.adminSvc.updateUserStatus(id, 'REJECTED').subscribe({
      next: () => { this.message.set('Korisnik odbijen.'); this.load(); },
    });
  }
}
