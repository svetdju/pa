import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../core/services/admin.service';
import { AdminUserResponse } from '../../../core/models/models';

/**
 * Admin — pregled i brisanje svih korisnika sistema.
 */
@Component({
  selector: 'app-users',
  imports: [CommonModule],
  template: `
    <div class="container-app">
      <h2 class="mb-3">Korisnici sistema</h2>

      @if (message()) { <div class="alert alert-success py-2">{{ message() }}</div> }

      <div class="table-responsive">
        <table class="table table-sm table-hover">
          <thead><tr><th>ID</th><th>Korisnik</th><th>Ime</th><th>Email</th><th>Uloga</th><th>Status</th><th></th></tr></thead>
          <tbody>
            @for (u of users(); track u.id) {
              <tr>
                <td>{{ u.id }}</td>
                <td>{{ u.username }}</td>
                <td>{{ u.first_name }} {{ u.last_name }}</td>
                <td>{{ u.email }}</td>
                <td><span class="badge bg-primary">{{ u.role }}</span></td>
                <td><span class="badge" [class.badge-approved]="u.status === 'APPROVED'" [class.badge-pending]="u.status === 'PENDING'" [class.badge-rejected]="u.status === 'REJECTED'">{{ u.status }}</span></td>
                <td>
                  @if (u.role !== 'ADMIN') {
                    <button class="btn btn-sm btn-outline-danger" (click)="deleteUser(u.id)">Obriši</button>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
})
export class Users implements OnInit {
  private adminSvc = inject(AdminService);

  users = signal<AdminUserResponse[]>([]);
  message = signal<string | null>(null);

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.adminSvc.getAllUsers().subscribe(u => this.users.set(u));
  }

  deleteUser(id: number): void {
    if (!confirm('Obrisati korisnika?')) return;
    this.adminSvc.deleteUser(id).subscribe({
      next: () => { this.message.set('Korisnik obrisan.'); this.load(); },
    });
  }
}
