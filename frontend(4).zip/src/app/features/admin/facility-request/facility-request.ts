import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../core/services/admin.service';
import { Facility, Court } from '../../../core/models/models';

/**
 * Admin — pregled i odobravanje/odbijanje PENDING sportskih objekata.
 * Prikazuje i terene unutar svakog objekta.
 */
@Component({
  selector: 'app-facility-request',
  imports: [CommonModule],
  template: `
    <div class="container-app">
      <h2 class="mb-3">Zahtevi za nove objekte</h2>

      @if (message()) { <div class="alert alert-success py-2">{{ message() }}</div> }
      @if (error()) { <div class="alert alert-danger py-2">{{ error() }}</div> }

      @if (loading()) {
        <div class="text-center py-4"><div class="spinner-border text-primary"></div></div>
      } @else if (facilities().length === 0) {
        <div class="alert alert-info">Nema zahteva na čekanju.</div>
      } @else {
        @for (f of facilities(); track f.id) {
          <div class="card mb-3">
            <div class="card-header d-flex justify-content-between align-items-center">
              <span>{{ f.name }} — {{ f.city }}</span>
              <span class="badge badge-pending">{{ f.status }}</span>
            </div>
            <div class="card-body">
              <dl class="row mb-2 small">
                <dt class="col-sm-3 text-muted">Adresa</dt><dd class="col-sm-9">{{ f.address }}</dd>
                <dt class="col-sm-3 text-muted">Firma</dt><dd class="col-sm-9">{{ f.companyName }} ({{ f.companyIdNumber }})</dd>
                <dt class="col-sm-3 text-muted">PIB</dt><dd class="col-sm-9">{{ f.pib }}</dd>
                <dt class="col-sm-3 text-muted">Cena/sat</dt><dd class="col-sm-9">{{ f.pricePerHour | number:'1.0-0' }} RSD</dd>
                <dt class="col-sm-3 text-muted">Radno vreme</dt><dd class="col-sm-9">{{ f.workStartTime }} — {{ f.workEndTime }}</dd>
                <dt class="col-sm-3 text-muted">Max no-show</dt><dd class="col-sm-9">{{ f.maxNoShows }}</dd>
              </dl>

              @if (courtsMap()[f.id]; as courts) {
                <h6 class="small">Tereni ({{ courts.length }})</h6>
                <div class="row g-1 mb-2">
                  @for (c of courts; track c.id) {
                    <div class="col-md-4">
                      <div class="card bg-light">
                        <div class="card-body py-1 px-2">
                          <small><strong>{{ c.courtName }}</strong> ({{ c.sportType }})</small><br>
                          <small class="text-muted">{{ c.type }}, N={{ c.capacity }}</small>
                        </div>
                      </div>
                    </div>
                  }
                </div>
              }

              <div class="d-flex gap-2">
                <button class="btn btn-success btn-sm" (click)="approve(f.id)">Odobri</button>
                <button class="btn btn-outline-danger btn-sm" (click)="reject(f.id)">Odbij</button>
              </div>
            </div>
          </div>
        }
      }
    </div>
  `,
})
export class FacilityRequest implements OnInit {
  private adminSvc = inject(AdminService);

  facilities = signal<Facility[]>([]);
  courtsMap = signal<Record<number, Court[]>>({});
  loading = signal(true);
  message = signal<string | null>(null);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.loading.set(true);
    this.adminSvc.getPendingFacilities().subscribe({
      next: (f) => {
        this.facilities.set(f);
        // Učitavamo terene za svaki objekat
        f.forEach(fac => {
          this.adminSvc.getFacilityCourts(fac.id).subscribe(courts => {
            this.courtsMap.update(m => ({ ...m, [fac.id]: courts }));
          });
        });
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  approve(id: number): void {
    this.adminSvc.updateFacilityStatus(id, 'APPROVED').subscribe({
      next: () => { this.message.set('Objekat odobren!'); this.load(); },
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }

  reject(id: number): void {
    this.adminSvc.updateFacilityStatus(id, 'REJECTED').subscribe({
      next: () => { this.message.set('Objekat odbijen.'); this.load(); },
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }
}
