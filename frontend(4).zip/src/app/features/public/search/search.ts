import { Component, inject, signal, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PublicService } from '../../../core/services/public.service';

/**
 * Pretraga sportskih objekata — filteri po nazivu, gradu, tipu i sportu.
 * Rezultati se prikazuju u tabeli sa dugmetom "Detalji".
 */
@Component({
  selector: 'app-search',
  imports: [FormsModule, RouterLink, CommonModule],
  templateUrl: './search.html',
})
export class Search implements OnInit {
  private publicSvc = inject(PublicService);

  // Filteri
  nameFilter = '';
  cityFilter = '';
  typeFilter = '';
  sportFilter = '';
  onlyAvailableToday = false;

  // Dostupne opcije
  cities: string[] = [];
  sports: string[] = [];
  types = ['OPEN', 'CLOSED', 'SPORTS_CENTER', 'SPORT_CENTER', 'TRAINING_CENTER'];

  // Rezultati
  results = signal<any[]>([]);
  loading = signal(false);
  error = signal<string | null>(null);

  // Sortiranje
  sortColumn = 'name';
  sortAsc = true;

  ngOnInit(): void {
    this.publicSvc.getCities().subscribe(c => this.cities = c);
    this.publicSvc.getSports().subscribe(s => this.sports = s);
    this.search();
  }

  search(): void {
    this.loading.set(true);
    this.error.set(null);

    this.publicSvc.searchFacilities({
      name: this.nameFilter || undefined,
      city: this.cityFilter || undefined,
      type: this.typeFilter || undefined,
      sport: this.sportFilter || undefined,
    }).subscribe({
      next: (res) => {
        console.log('[Search] Rezultati:', res);
        this.results.set(res);
        this.loading.set(false);
      },
      error: (err) => {
        console.error('[Search] Greška pri pretrazi:', err);
        let msg = 'Greška pri pretrazi.';
        if (err.status === 0) {
          msg = 'Nije moguće povezati se sa serverom. Proverite da li je backend pokrenut.';
        } else if (err.status === 404) {
          msg = 'Backend ruta /api/public/facilities nije pronađena.';
        }
        this.error.set(msg);
        this.loading.set(false);
      },
    });
  }

  sortBy(col: string): void {
    if (this.sortColumn === col) {
      this.sortAsc = !this.sortAsc;
    } else {
      this.sortColumn = col;
      this.sortAsc = true;
    }
    const sorted = [...this.results()];
    sorted.sort((a, b) => {
      let va = a[col];
      let vb = b[col];
      // sports je GROUP_CONCAT — sortiramo kao string
      if (typeof va === 'string') va = va.toLowerCase();
      if (typeof vb === 'string') vb = vb.toLowerCase();
      if (va < vb) return this.sortAsc ? -1 : 1;
      if (va > vb) return this.sortAsc ? 1 : -1;
      return 0;
    });
    this.results.set(sorted);
  }

  sortIcon(col: string): string {
    if (this.sortColumn !== col) return '↕';
    return this.sortAsc ? '↑' : '↓';
  }

  clearFilters(): void {
    this.nameFilter = '';
    this.cityFilter = '';
    this.typeFilter = '';
    this.sportFilter = '';
    this.onlyAvailableToday = false;
    this.search();
  }
}
