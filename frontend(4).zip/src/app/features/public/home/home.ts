import { Component, inject, signal, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PublicService } from '../../../core/services/public.service';
import { HomepageResponse } from '../../../core/models/models';

/**
 * Početna stranica — prikazuje ukupan broj objekata, top 3 najbolje ocenjena
 * i do 3 aktuelne promocije. Dostupno i neregistrovanim korisnicima.
 */
@Component({
  selector: 'app-home',
  imports: [RouterLink, CommonModule],
  templateUrl: './home.html',
})
export class Home implements OnInit {
  private publicSvc = inject(PublicService);

  data = signal<HomepageResponse | null>(null);
  loading = signal(true);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.publicSvc.getHomepage().subscribe({
      next: (res) => {
        this.data.set(res);
        this.loading.set(false);
      },
      error: (err) => {
        console.error('[Home] Greška pri učitavanju homepage-a:', err);
        let msg = 'Greška pri učitavanju početne strane.';
        if (err.status === 0) {
          msg = 'Nije moguće povezati se sa serverom. Proverite da li je backend pokrenut na http://localhost:8080';
        } else if (err.status === 404) {
          msg = 'Backend ruta /api/public/homepage nije pronađena. Proverite da li backend radi.';
        }
        this.error.set(msg);
        this.loading.set(false);
      },
    });
  }
}
