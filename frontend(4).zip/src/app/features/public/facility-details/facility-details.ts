import { Component, inject, signal, OnInit, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { PublicService } from '../../../core/services/public.service';
import { FacilityService } from '../../../core/services/facility.service';
import { AuthService } from '../../../core/services/auth.service';
import { FacilityDetailsResponse, RatingSummaryResponse, RatingEligibilityResponse } from '../../../core/models/models';

/**
 * Detalji objekta — prikazuje naziv, adresu, broj lajkova, terene, cenovnik,
 * galeriju slika i ocene (lajkovi/komentari).
 *
 * Ulogovani sportista može ostaviti like/dislike + komentar ako ispunjava uslove.
 */
@Component({
  selector: 'app-facility-details',
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './facility-details.html',
})
export class FacilityDetails implements OnInit {
  private publicSvc = inject(PublicService);
  private facilitySvc = inject(FacilityService);
  private auth = inject(AuthService);

  /** ID objekta iz URL rute */
  id = input<number>(0);

  data = signal<FacilityDetailsResponse | null>(null);
  ratings = signal<RatingSummaryResponse | null>(null);
  eligibility = signal<RatingEligibilityResponse | null>(null);
  loading = signal(true);
  error = signal<string | null>(null);

  // Izbor terena za kalendar
  selectedCourtId = signal<number | null>(null);
  selectedDate = new Date().toISOString().split('T')[0];
  occupiedSlots = signal<any[]>([]);

  // Forma za ocenu
  ratingIsLike: boolean | null = null;
  ratingComment = '';
  ratingError = signal<string | null>(null);
  ratingSuccess = signal<string | null>(null);

  readonly isLoggedIn = this.auth.isLoggedIn;
  readonly isAthlete = this.auth.isAthlete;

  ngOnInit(): void {
    this.loadFacility();
  }

  private loadFacility(): void {
    this.loading.set(true);
    this.publicSvc.getFacilityDetails(this.id()).subscribe({
      next: (res) => {
        this.data.set(res);
        if (res.courts.length > 0) {
          this.selectedCourtId.set(res.courts[0].id);
          this.loadOccupiedSlots();
        }
        this.loadRatings();
        if (this.isAthlete()) {
          this.loadEligibility();
        }
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Objekat nije pronađen ili nije odobren.');
        this.loading.set(false);
      },
    });
  }

  loadRatings(): void {
    this.publicSvc.getFacilityRatings(this.id()).subscribe({
      next: (res) => this.ratings.set(res),
    });
  }

  loadEligibility(): void {
    this.facilitySvc.getRatingEligibility(this.id()).subscribe({
      next: (res) => this.eligibility.set(res),
    });
  }

  onCourtChange(): void {
    this.loadOccupiedSlots();
  }

  onDateChange(): void {
    this.loadOccupiedSlots();
  }

  loadOccupiedSlots(): void {
    const courtId = this.selectedCourtId();
    if (!courtId) return;
    this.publicSvc.getCourtReservations(courtId, this.selectedDate).subscribe({
      next: (res) => this.occupiedSlots.set(res),
    });
  }

  submitRating(): void {
    if (this.ratingIsLike === null) {
      this.ratingError.set('Izaberite "sviđa mi se" ili "ne sviđa mi se".');
      return;
    }
    this.ratingError.set(null);
    this.ratingSuccess.set(null);

    this.facilitySvc.addRating(this.id(), {
      is_like: this.ratingIsLike,
      comment: this.ratingComment || undefined,
    }).subscribe({
      next: () => {
        this.ratingSuccess.set('Hvala na oceni!');
        this.ratingComment = '';
        this.ratingIsLike = null;
        this.loadRatings();
        this.loadEligibility();
      },
      error: (err) => {
        const msg = err.error?.message || err.error;
        this.ratingError.set(typeof msg === 'string' ? msg : 'Greška pri slanju ocene.');
      },
    });
  }

  isSlotOccupied(hour: number): boolean {
    const slots = this.occupiedSlots();
    return slots.some(s => {
      const start = parseInt(s.startTime.split(':')[0], 10);
      return start === hour && s.status !== 'CANCELLED';
    });
  }

  getSlotStatus(hour: number): string {
    const slot = this.occupiedSlots().find(s => {
      const start = parseInt(s.startTime.split(':')[0], 10);
      return start === hour && s.status !== 'CANCELLED';
    });
    return slot?.status || '';
  }
}
