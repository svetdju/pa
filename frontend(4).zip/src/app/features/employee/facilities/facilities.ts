import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../../core/services/user.service';
import { FacilityService } from '../../../core/services/facility.service';
import { EmployeeProfileResponse, FacilityRequest, CourtRequest } from '../../../core/models/models';

/**
 * Zaposleni objekti — pregled svih objekata u kojima zaposleni radi,
 * kreiranje novih objekata (forma ili JSON fajl) i dodavanje terena.
 */
@Component({
  selector: 'app-facilities',
  imports: [CommonModule, FormsModule],
  templateUrl: './facilities.html',
})
export class Facilities implements OnInit {
  private userSvc = inject(UserService);
  private facilitySvc = inject(FacilityService);

  profile = signal<EmployeeProfileResponse | null>(null);
  loading = signal(true);
  message = signal<string | null>(null);
  error = signal<string | null>(null);

  // Forma za novi objekat
  showForm = signal(false);
  newFacility: FacilityRequest = {
    name: '', city: '', address: '', description: '', price_per_hour: 0,
    type: 'CLOSED', work_start_time: '08:00', work_end_time: '22:00', max_no_shows: 3,
    courts: [],
  };
  newCourt: CourtRequest = { court_name: '', sport_type: '', type: 'OPENED', capacity: 4, equipment_description: '' };

  // Forma za dodavanje terena
  showAddCourt = signal<number | null>(null);
  addCourtReq: CourtRequest = { court_name: '', sport_type: '', type: 'CLOSED', capacity: 1, equipment_description: '' };

  ngOnInit(): void {
    this.loadProfile();
  }

  private loadProfile(): void {
    this.userSvc.getEmployeeProfile().subscribe({
      next: (p) => { this.profile.set(p); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  toggleForm(): void {
    this.showForm.update(v => !v);
    if (!this.showForm()) {
      this.newFacility.courts = [];
      this.newCourt = { court_name: '', sport_type: '', type: 'OPENED', capacity: 4, equipment_description: '' };
    }
  }

  addCourtToForm(): void {
    this.newFacility.courts.push({ ...this.newCourt });
    this.newCourt = { court_name: '', sport_type: '', type: 'OPENED', capacity: 4, equipment_description: '' };
  }

  removeCourtFromForm(idx: number): void {
    this.newFacility.courts.splice(idx, 1);
  }

  createFacility(): void {
    this.facilitySvc.createFacilityFromForm(this.newFacility).subscribe({
      next: () => {
        this.message.set('Objekat kreiran i poslat na odobrenje!');
        this.toggleForm();
        this.loadProfile();
      },
      error: (err) => this.error.set(err.error || 'Greška pri kreiranju.'),
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.facilitySvc.createFacilityFromFile(input.files[0]).subscribe({
        next: () => { this.message.set('Objekat uvezen iz JSON-a!'); this.loadProfile(); },
        error: (err) => this.error.set(err.error || 'Greška pri uvozu.'),
      });
    }
  }

  toggleAddCourt(facilityId: number): void {
    this.showAddCourt.set(this.showAddCourt() === facilityId ? null : facilityId);
    this.addCourtReq = { court_name: '', sport_type: '', type: 'CLOSED', capacity: 1, equipment_description: '' };
  }

  addCourt(facilityId: number): void {
    this.facilitySvc.addCourt(facilityId, this.addCourtReq).subscribe({
      next: () => { this.message.set('Teren dodat!'); this.toggleAddCourt(facilityId); this.loadProfile(); },
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }
}
