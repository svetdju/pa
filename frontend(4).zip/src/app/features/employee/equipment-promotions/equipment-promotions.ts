import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../../core/services/employee.service';
import { PublicService } from '../../../core/services/public.service';
import { ShopService } from '../../../core/services/shop.service';
import { Equipment, Promotion } from '../../../core/models/models';

/**
 * Zaposleni upravljanje opremom i promocijama — dve tabele u tabovima.
 */
@Component({
  selector: 'app-equipment-promotions',
  imports: [CommonModule, FormsModule],
  templateUrl: './equipment-promotions.html',
})
export class EquipmentPromotions implements OnInit {
  private empSvc = inject(EmployeeService);
  private publicSvc = inject(PublicService);
  private shopSvc = inject(ShopService);

  activeTab = signal<'equipment' | 'promotions'>('equipment');
  sports: string[] = [];

  // Equipment
  equipment = signal<Equipment[]>([]);
  showAddEquip = signal(false);
  newEquip = { name: '', sportType: '', price: 0, stock: 0, description: '', file: null as File | null };

  // Promotions
  promotions = signal<Promotion[]>([]);
  showAddPromo = signal(false);
  newPromo: Promotion = { id: 0, name: '', discountPercent: 10, sportType: '', startDate: '', endDate: '', isActive: true };

  message = signal<string | null>(null);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.publicSvc.getSports().subscribe(s => this.sports = s);
    this.loadEquipment();
    this.loadPromotions();
  }

  loadEquipment(): void {
    this.loadAllEquipment();
  }

  private loadAllEquipment(): void {
    if (this.sports.length === 0) return;
    const all: Equipment[] = [];
    let loaded = 0;
    this.sports.forEach(sport => {
      this.shopSvc.getCatalog(sport).subscribe(eq => {
        all.push(...eq);
        loaded++;
        if (loaded === this.sports.length) {
          this.equipment.set(all);
        }
      });
    });
  }

  loadPromotions(): void {
    this.empSvc.getPromotions().subscribe(p => this.promotions.set(p));
  }

  // ===== Equipment CRUD =====
  toggleAddEquip(): void { this.showAddEquip.update(v => !v); }
  toggleAddPromo(): void { this.showAddPromo.update(v => !v); }

  onEquipFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files?.[0]) this.newEquip.file = input.files[0];
  }

  addEquipment(): void {
    if (!this.newEquip.file) { this.error.set('Slika je obavezna.'); return; }
    this.empSvc.addEquipment(
      this.newEquip.name, this.newEquip.price, this.newEquip.stock,
      this.newEquip.sportType, this.newEquip.description, this.newEquip.file!
    ).subscribe({
      next: () => { this.message.set('Oprema dodata!'); this.showAddEquip.set(false); this.loadAllEquipment(); },
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }

  updatePrice(eq: Equipment, newPrice: number): void {
    this.empSvc.updateEquipmentPrice(eq.id, newPrice).subscribe(() => this.loadAllEquipment());
  }

  updateStock(eq: Equipment, newStock: number): void {
    this.empSvc.updateEquipmentStock(eq.id, newStock).subscribe(() => this.loadAllEquipment());
  }

  deleteEquipment(id: number): void {
    if (!confirm('Obrisati opremu?')) return;
    this.empSvc.deleteEquipment(id).subscribe(() => this.loadAllEquipment());
  }

  // ===== Promotion CRUD =====
  addPromotion(): void {
    this.empSvc.createPromotion(this.newPromo).subscribe({
      next: () => { this.message.set('Promocija kreirana!'); this.showAddPromo.set(false); this.loadPromotions(); },
      error: (err) => this.error.set(err.error || 'Greška.'),
    });
  }

  togglePromoActive(p: Promotion): void {
    this.empSvc.updatePromotion(p.id, { ...p, isActive: !p.isActive }).subscribe(() => this.loadPromotions());
  }

  deletePromotion(id: number): void {
    if (!confirm('Obrisati promociju?')) return;
    this.empSvc.deletePromotion(id).subscribe(() => this.loadPromotions());
  }
}
