import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../../../core/services/employee.service';
import { OrderResponse } from '../../../core/models/models';

/**
 * Zaposleni pregled svih porudžbina — prihvatanje, isporuka i otkazivanje.
 */
@Component({
  selector: 'app-employee-orders',
  imports: [CommonModule],
  template: `
    <div class="container-app">
      <h2 class="mb-3">Sve porudžbine</h2>

      @if (message()) { <div class="alert alert-info py-2">{{ message() }}</div> }

      <div class="table-responsive">
        <table class="table table-sm table-hover">
          <thead><tr><th>#</th><th>Datum</th><th>Stavke</th><th>Ukupno</th><th>Status</th><th>Akcije</th></tr></thead>
          <tbody>
            @for (o of orders(); track o.id) {
              <tr>
                <td>#{{ o.id }}</td>
                <td>{{ o.order_date | date:'dd.MM.yyyy HH:mm' }}</td>
                <td class="small">{{ o.items_summary }}</td>
                <td>{{ o.total_price | number:'1.2-2' }} RSD</td>
                <td><span class="badge" [class]="statusBadge(o.status)">{{ o.status }}</span></td>
                <td>
                  <div class="btn-group btn-group-sm">
                    @if (o.status === 'ORDERED') {
                      <button class="btn btn-success" (click)="accept(o.id)">Prihvati</button>
                      <button class="btn btn-outline-danger" (click)="cancel(o.id)">Otkaži</button>
                    }
                    @if (o.status === 'ACCEPTED') {
                      <button class="btn btn-primary" (click)="deliver(o.id)">Isporuči</button>
                    }
                  </div>
                </td>
              </tr>
            } @empty {
              <tr><td colspan="6" class="text-center text-muted">Nema porudžbina</td></tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
})
export class EmployeeOrders implements OnInit {
  private empSvc = inject(EmployeeService);

  orders = signal<OrderResponse[]>([]);
  message = signal<string | null>(null);

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.empSvc.getAllOrders().subscribe(o => this.orders.set(o));
  }

  accept(id: number): void {
    this.empSvc.acceptOrder(id).subscribe({ next: () => { this.message.set('Porudžbina prihvaćena.'); this.load(); } });
  }

  deliver(id: number): void {
    this.empSvc.deliverOrder(id).subscribe({ next: () => { this.message.set('Porudžbina isporučena.'); this.load(); } });
  }

  cancel(id: number): void {
    if (!confirm('Otkazati porudžbinu? Zalihe će biti vraćene.')) return;
    this.empSvc.cancelOrderAsStaff(id).subscribe({ next: () => { this.message.set('Porudžbina otkazana.'); this.load(); } });
  }

  statusBadge(status: string): string {
    const map: Record<string, string> = {
      'ORDERED': 'badge-ordered', 'ACCEPTED': 'badge-accepted',
      'DELIVERED': 'badge-delivered', 'CANCELLED': 'badge-cancelled',
    };
    return map[status] || 'bg-secondary';
  }
}
