import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../../core/services/employee.service';

/**
 * Zaposleni izveštaji — generisanje PDF izveštaja o popunjenosti terena
 * i prometu opreme za izabrani mesec.
 */
@Component({
  selector: 'app-reports',
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container-app">
      <h2 class="mb-3">Izveštaji</h2>

      @if (error()) { <div class="alert alert-danger py-2">{{ error() }}</div> }

      <div class="row g-3">
        <div class="col-md-6">
          <div class="card h-100">
            <div class="card-header">Popunjenost terena</div>
            <div class="card-body">
              <p class="text-muted small">PDF izveštaj o broju rezervacija po terenu za izabrani mesec.</p>
              <div class="input-group input-group-sm mb-2">
                <input type="month" class="form-control" [(ngModel)]="courtMonth">
                <button class="btn btn-primary" (click)="generateCourtReport()" [disabled]="loadingCourt()">
                  @if (loadingCourt()) { Generisanje... } @else { Generiši PDF }
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card h-100">
            <div class="card-header">Promet opreme</div>
            <div class="card-body">
              <p class="text-muted small">PDF izveštaj o prodaji opreme i ukupnom prometu za izabrani mesec.</p>
              <div class="input-group input-group-sm mb-2">
                <input type="month" class="form-control" [(ngModel)]="equipMonth">
                <button class="btn btn-primary" (click)="generateEquipReport()" [disabled]="loadingEquip()">
                  @if (loadingEquip()) { Generisanje... } @else { Generiši PDF }
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class Reports {
  private empSvc = inject(EmployeeService);

  courtMonth = new Date().toISOString().slice(0, 7);
  equipMonth = new Date().toISOString().slice(0, 7);
  loadingCourt = signal(false);
  loadingEquip = signal(false);
  error = signal<string | null>(null);

  generateCourtReport(): void {
    this.loadingCourt.set(true);
    this.error.set(null);
    this.empSvc.getCourtUsageReport(this.courtMonth).subscribe({
      next: (blob) => {
        this.downloadPdf(blob, `court-usage-${this.courtMonth}.pdf`);
        this.loadingCourt.set(false);
      },
      error: () => { this.error.set('Greška pri generisanju izveštaja.'); this.loadingCourt.set(false); },
    });
  }

  generateEquipReport(): void {
    this.loadingEquip.set(true);
    this.error.set(null);
    this.empSvc.getEquipmentSalesReport(this.equipMonth).subscribe({
      next: (blob) => {
        this.downloadPdf(blob, `equipment-sales-${this.equipMonth}.pdf`);
        this.loadingEquip.set(false);
      },
      error: () => { this.error.set('Greška pri generisanju izveštaja.'); this.loadingEquip.set(false); },
    });
  }

  private downloadPdf(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
