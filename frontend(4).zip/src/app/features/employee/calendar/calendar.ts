import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../../core/services/employee.service';
import { UserService } from '../../../core/services/user.service';
import { PublicService } from '../../../core/services/public.service';

/**
 * Zaposleni kalendar — pregled svih rezervacija i treninga po terenu u periodu.
 */
@Component({
  selector: 'app-calendar',
  imports: [CommonModule, FormsModule],
  templateUrl: './calendar.html',
})
export class Calendar implements OnInit {
  private empSvc = inject(EmployeeService);
  private userSvc = inject(UserService);
  private publicSvc = inject(PublicService);

  facilities = signal<any[]>([]);
  selectedFacilityId: number | null = null;
  courts = signal<any[]>([]);
  selectedCourtId: number | null = null;

  today = new Date();
  startDate = this.today.toISOString().split('T')[0];
  endDate = new Date(this.today.getTime() + 7 * 86400000).toISOString().split('T')[0];

  events = signal<any[]>([]);
  loading = signal(false);

  ngOnInit(): void {
    this.userSvc.getEmployeeProfile().subscribe(p => {
      this.facilities.set(p.myFacilities);
      if (p.myFacilities.length > 0) {
        this.selectedFacilityId = p.myFacilities[0].id;
        this.loadCourts();
      }
    });
  }

  loadCourts(): void {
    if (!this.selectedFacilityId) return;
    this.publicSvc.getFacilityDetails(this.selectedFacilityId).subscribe({
      next: (d) => {
        this.courts.set(d.courts);
        if (d.courts.length > 0) {
          this.selectedCourtId = d.courts[0].id;
          this.loadCalendar();
        }
      },
    });
  }

  onFacilityChange(): void {
    this.loadCourts();
  }

  onCourtChange(): void {
    this.loadCalendar();
  }

  onDateChange(): void {
    if (this.selectedCourtId) this.loadCalendar();
  }

  loadCalendar(): void {
    if (!this.selectedCourtId) return;
    this.loading.set(true);
    this.empSvc.getCalendarData(this.selectedCourtId, this.startDate, this.endDate).subscribe({
      next: (d) => { this.events.set(d); this.loading.set(false); },
      error: () => this.loading.set(false),
    });
  }

  statusBadge(status: string): string {
    const map: Record<string, string> = {
      'PENDING': 'badge-pending', 'CONFIRMED': 'badge-confirmed', 'COMPLETED': 'badge-completed',
      'CANCELLED': 'badge-cancelled', 'SCHEDULED': 'badge-scheduled',
    };
    return map[status] || 'bg-secondary';
  }
}
