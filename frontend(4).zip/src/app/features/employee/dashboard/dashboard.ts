import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../../../core/services/employee.service';

/**
 * Zaposleni dashboard — check-in tabela (današnje rezervacije i treninzi),
 * pending zahtevi, i akcije potvrde/odbijanja.
 */
@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.html',
})
export class Dashboard implements OnInit {
  private empSvc = inject(EmployeeService);

  checkInTable = signal<any[]>([]);
  pendingRequests = signal<any[]>([]);
  loading = signal(true);
  message = signal<string | null>(null);

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.loading.set(true);
    this.empSvc.getCheckInTable().subscribe(d => this.checkInTable.set(d));
    this.empSvc.getPendingRequests().subscribe({
      next: (d) => {
        this.pendingRequests.set(d);
        this.loading.set(false);
      },
    });
  }

  confirmCheckIn(type: string, id: number): void {
    this.empSvc.checkIn(type, id, 'CONFIRM').subscribe({
      next: () => { this.message.set('Potvrđeno!'); this.loadData(); },
    });
  }

  rejectCheckIn(type: string, id: number): void {
    this.empSvc.checkIn(type, id, 'REJECT').subscribe({
      next: () => { this.message.set('Evidentirano nedolazak.'); this.loadData(); },
    });
  }

  approvePending(id: number): void {
    this.empSvc.decidePending(id, true).subscribe({
      next: () => { this.message.set('Rezervacija odobrena.'); this.loadData(); },
      error: (err) => this.message.set(err.error || 'Greška.'),
    });
  }

  rejectPending(id: number): void {
    this.empSvc.decidePending(id, false).subscribe({
      next: () => { this.message.set('Rezervacija odbijena.'); this.loadData(); },
    });
  }

  statusBadge(status: string): string {
    const map: Record<string, string> = {
      'PENDING': 'badge-pending', 'CONFIRMED': 'badge-confirmed', 'COMPLETED': 'badge-completed',
      'CANCELLED': 'badge-cancelled', 'ABSENT': 'badge-absent', 'SCHEDULED': 'badge-scheduled',
    };
    return map[status] || 'bg-secondary';
  }
}
