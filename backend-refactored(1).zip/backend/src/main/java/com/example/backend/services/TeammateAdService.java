package com.example.backend.services;

import com.example.backend.dtos.TeammateAdDTOs.AdRequest;
import com.example.backend.dtos.TeammateAdDTOs.AdResponse;
import com.example.backend.dtos.TeammateAdDTOs.AdResponseDetails;
import com.example.backend.dtos.TeammateAdDTOs.TeammateResponseDTO;
import com.example.backend.models.TeammateAdResponse;
import com.example.backend.models.User;
import com.example.backend.repos.TeammateAdRepository;
import com.example.backend.repos.TeammateAdResponseRepository;
import com.example.backend.repos.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Oglasi "tražim saigrače" i prijave sportista na njih.
 *
 * <p>Biznis pravila:</p>
 * <ul>
 *   <li>Sportista ne može odgovoriti na sopstveni oglas.</li>
 *   <li>Sportista ne može poslati dve prijave na isti oglas.</li>
 *   <li>Oglas mora biti OPEN da bi se odgovaralo na njega.</li>
 *   <li>Pri APPROVE prijave se {@code playersNeeded} smanjuje; kada dođe do 0,
 *       oglas automatski postaje CLOSED.</li>
 *   <li>Samo vlasnik oglasa može upravljati prijavama ili ručno zatvoriti oglas.</li>
 * </ul>
 */
@Service
public class TeammateAdService {

    private final TeammateAdRepository adRepository;
    private final TeammateAdResponseRepository adResponseRepository;
    private final UserRepository userRepository;

    public TeammateAdService(TeammateAdRepository adRepository,
                             TeammateAdResponseRepository adResponseRepository,
                             UserRepository userRepository) {
        this.adRepository = adRepository;
        this.adResponseRepository = adResponseRepository;
        this.userRepository = userRepository;
    }

    /** Kreira novi oglas "tražim saigrače" sa statusom OPEN. */
    public void createAd(AdRequest dto, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        adRepository.saveAd(user.getId(), dto.getSport(), dto.getCity(),
                dto.getEvent_date(), dto.getEvent_time(), dto.getPlayers_needed());
    }

    /** Aktivni (OPEN) oglasi koje korisnik nije sam kreirao. */
    public List<AdResponse> getActiveAds(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));
        return adRepository.findActiveAdsExcludingUser(user.getId());
    }

    /**
     * Šalje prijavu sportiste na oglas. Validira: oglas postoji, nije zatvoren,
     * korisnik nije kreator, i nije već poslao prijavu.
     */
    public void respondToAd(Long adId, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        Map<String, Object> ad = adRepository.findAdById(adId);
        if (ad == null) {
            throw new RuntimeException("Oglas ne postoji.");
        }

        Long creatorId = ((Number) ad.get("creator_id")).longValue();
        String status = (String) ad.get("status");

        if (!"OPEN".equals(status)) {
            throw new RuntimeException("Ovaj oglas je zatvoren.");
        }
        if (user.getId().equals(creatorId)) {
            throw new RuntimeException("Ne možete se prijaviti na sopstveni oglas.");
        }
        if (adRepository.hasUserAlreadyResponded(adId, user.getId())) {
            throw new RuntimeException("Već ste poslali zahtev za ovaj oglas.");
        }

        TeammateAdResponse response = new TeammateAdResponse();
        response.setAdId(adId);
        response.setUserId(user.getId());
        response.setStatus("PENDING");
        adResponseRepository.save(response);
    }

    /** Svi oglasi korisnika, sa pripadajućim prijavama — za stranicu "Moji oglasi". */
    public List<AdResponseDetails> getMyAdsWithResponses(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        List<AdResponse> myAds = adRepository.findAdsByCreatorId(user.getId());
        List<AdResponseDetails> detailedList = new ArrayList<>();

        for (AdResponse ad : myAds) {
            AdResponseDetails details = new AdResponseDetails();
            details.setId(ad.getId());
            details.setSport(ad.getSport());
            details.setCity(ad.getCity());
            details.setEvent_date(ad.getEvent_date());
            details.setEvent_time(ad.getEvent_time());
            details.setPlayers_needed(ad.getPlayers_needed());
            details.setStatus(ad.getStatus());
            details.setResponses(adRepository.findResponsesByAdId(ad.getId()));
            detailedList.add(details);
        }
        return detailedList;
    }

    /**
     * Odobrava ili odbija prijavu. Pri APPROVE se smanjuje {@code playersNeeded};
     * ako dođe do 0, oglas se automatski zatvara.
     */
    @Transactional
    public void handleResponseStatus(Long responseId, String newStatus, String username) {
        User currentUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        Map<String, Object> adInfo = adRepository.findAdInfoByResponseId(responseId);
        if (adInfo == null) {
            throw new RuntimeException("Prijava ili oglas nisu pronađeni.");
        }

        Long creatorId = ((Number) adInfo.get("creator_id")).longValue();
        Long adId = ((Number) adInfo.get("ad_id")).longValue();
        int playersNeeded = ((Number) adInfo.get("players_needed")).intValue();

        if (!currentUser.getId().equals(creatorId)) {
            throw new RuntimeException("Nemate dozvolu da upravljate prijavama za ovaj oglas.");
        }

        if (!"APPROVED".equals(newStatus) && !"REJECTED".equals(newStatus)) {
            throw new RuntimeException("Nevalidan status. Dozvoljeno je samo 'APPROVED' ili 'REJECTED'.");
        }

        adRepository.updateResponseStatus(responseId, newStatus);

        if ("APPROVED".equals(newStatus)) {
            if (playersNeeded <= 0) {
                throw new RuntimeException("Ekipa je već kompletirana.");
            }
            adRepository.decrementPlayersNeeded(adId);
            playersNeeded--; // lokalna kopija za proveru ispod
            if (playersNeeded == 0) {
                adRepository.updateAdStatus(adId, "CLOSED");
            }
        }
    }

    /** Ručno zatvaranje oglasa od strane vlasnika. */
    public void closeAdManually(Long adId, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        Map<String, Object> ad = adRepository.findAdById(adId);
        Long creatorId = ((Number) ad.get("creator_id")).longValue();

        if (!user.getId().equals(creatorId)) {
            throw new RuntimeException("Možete zatvoriti samo sopstvene oglase.");
        }
        adRepository.updateAdStatus(adId, "CLOSED");
    }

    /**
     * Lista {@code [ad_id, status]} za sve oglase na koje se korisnik prijavio.
     * Frontend koristi ovo da sakrije "Prijavi se" dugme na oglasima na koje je
     * korisnik već odgovorio.
     */
    public List<Map<String, Object>> getMyResponses(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));
        return adRepository.findResponsesByUserId(user.getId());
    }
}
