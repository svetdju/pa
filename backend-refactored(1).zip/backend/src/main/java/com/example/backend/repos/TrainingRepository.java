package com.example.backend.repos;

import com.example.backend.dtos.TrainingResponse;
import com.example.backend.models.Training;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TrainingRepository extends JpaRepository<Training, Long> {

    /**
     * Postoji li SCHEDULED trening kod istog trenera koji se preklapa sa datim terminom?
     *
     * <p>Koristimo CASE WHEN umesto COUNT() > 0 jer Hibernate 6 vraća Long (ne Boolean).</p>
     */
    @Query("SELECT CASE WHEN COUNT(t) > 0 THEN true ELSE false END FROM Training t " +
           "WHERE t.coachId = :coachId " +
           "AND t.trainingDate = :date " +
           "AND t.status = 'SCHEDULED' " +
           "AND (t.startTime < :endTime AND t.endTime > :startTime)")
    boolean existsOverlappingTraining(@Param("coachId") Long coachId,
                                      @Param("date") String date,
                                      @Param("startTime") String startTime,
                                      @Param("endTime") String endTime);

    /**
     * Istorija i zakazani treninzi korisnika sa podacima o treneru, objektu,
     * terenu i sportu. Native query jer vraća DTO projection.
     */
    @Query(value = "SELECT t.id, c.name AS coach_name, f.name AS facility_name, " +
                   "t.court_id, crt.court_name AS court_name, " +
                   "c.sport AS sport, t.training_date, t.start_time, t.end_time, t.status " +
                   "FROM trainings t " +
                   "JOIN coaches c ON t.coach_id = c.id " +
                   "JOIN facilities f ON c.facility_id = f.id " +
                   "JOIN courts crt ON t.court_id = crt.id " +
                   "WHERE t.user_id = :userId AND f.status = 'APPROVED' " +
                   "ORDER BY t.training_date DESC, t.start_time DESC",
           nativeQuery = true)
    List<Object[]> findAllTrainingsByUserIdRaw(@Param("userId") Long userId);

    default List<TrainingResponse> findAllTrainingsByUserId(Long userId) {
        List<Object[]> rows = findAllTrainingsByUserIdRaw(userId);
        java.util.List<TrainingResponse> result = new java.util.ArrayList<>(rows.size());
        for (Object[] r : rows) {
            TrainingResponse t = new TrainingResponse();
            t.setId(((Number) r[0]).longValue());
            t.setCoach_name((String) r[1]);
            t.setFacility_name((String) r[2]);
            t.setCourt_id(((Number) r[3]).longValue());
            t.setCourt_name((String) r[4]);
            t.setSport((String) r[5]);
            t.setTraining_date(r[6] != null ? r[6].toString() : null);
            t.setStart_time(r[7] != null ? r[7].toString() : null);
            t.setEnd_time(r[8] != null ? r[8].toString() : null);
            t.setStatus((String) r[9]);
            result.add(t);
        }
        return result;
    }
}
