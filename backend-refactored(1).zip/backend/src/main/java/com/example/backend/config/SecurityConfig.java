package com.example.backend.config;

import com.example.backend.security.JwtAuthFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Spring Security konfiguracija: stateless JWT autentifikacija, CORS poštuje
 * {@link WebConfig}, CSRF isključen (jer ne koristimo kolačiće).
 *
 * <p>Matrica pristupa po ulogama:</p>
 * <ul>
 *   <li><b>Javno</b> (permitAll): /uploads/**, /api/auth/**, javne GET rute za
 *       pretragu, katalog, sportove i zauzeća terena, /api/public/**</li>
 *   <li><b>ATHLETE</b>: kreiranje/otkazivanje rezervacija, zakazivanje treninga,
 *       naručivanje, oglasi, ocene</li>
 *   <li><b>EMPLOYEE</b>: dashboard, kreiranje objekata i terena, oprema,
 *       promocije, izveštaji</li>
 *   <li><b>ADMIN</b>: /api/admin/**</li>
 *   <li><b>Authenticated</b>: sve ostalo (uključujući profile rute)</li>
 * </ul>
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    public SecurityConfig(JwtAuthFilter jwtAuthFilter) {
        this.jwtAuthFilter = jwtAuthFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(Customizer.withDefaults())
            .authorizeHttpRequests(auth -> auth
                // 1) Javne rute — nema potrebe za JWT-om
                .requestMatchers("/uploads/**").permitAll()
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/trainings/coaches").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/shop/catalog").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/sports/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/reservations/court/**").permitAll()
                .requestMatchers("/api/public/**").permitAll()

                // 2) Sportista (ATHLETE) — rezervacije, treninzi, prodavnica, oglasi, ocene
                .requestMatchers(HttpMethod.POST, "/api/reservations").hasRole("ATHLETE")
                .requestMatchers(HttpMethod.PUT,  "/api/reservations/*/cancel").hasRole("ATHLETE")
                .requestMatchers("/api/reservations/my").hasRole("ATHLETE")
                .requestMatchers(HttpMethod.POST, "/api/trainings").hasRole("ATHLETE")
                .requestMatchers("/api/trainings/my").hasRole("ATHLETE")
                .requestMatchers(HttpMethod.POST, "/api/shop/orders").hasRole("ATHLETE")
                .requestMatchers("/api/shop/orders/my").hasRole("ATHLETE")
                .requestMatchers("/api/shop/orders/*/cancel").hasRole("ATHLETE")
                .requestMatchers("/api/ads/**").hasRole("ATHLETE")
                .requestMatchers(HttpMethod.GET,  "/api/facilities/*/ratings/eligibility").hasRole("ATHLETE")
                .requestMatchers(HttpMethod.POST, "/api/facilities/*/ratings").hasRole("ATHLETE")

                // 3) Zaposleni (EMPLOYEE) — dashboard, objekti, oprema, promocije, izveštaji
                .requestMatchers("/api/users/profile/employee").hasRole("EMPLOYEE")
                .requestMatchers(HttpMethod.POST, "/api/facilities/create").hasRole("EMPLOYEE")
                .requestMatchers(HttpMethod.POST, "/api/facilities/create-form").hasRole("EMPLOYEE")
                .requestMatchers(HttpMethod.POST, "/api/facilities/*/courts").hasRole("EMPLOYEE")
                .requestMatchers("/api/employee/dashboard/**").hasRole("EMPLOYEE")
                .requestMatchers("/api/employee/equipment/**").hasRole("EMPLOYEE")
                .requestMatchers("/api/employee/promotions/**").hasRole("EMPLOYEE")
                .requestMatchers("/api/employee/reports/**").hasRole("EMPLOYEE")

                // 4) Administrator (ADMIN)
                .requestMatchers("/api/admin/**").hasRole("ADMIN")

                // 5) Sve ostalo — bilo koji ulogovani korisnik
                .anyRequest().authenticated()
            )
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}
