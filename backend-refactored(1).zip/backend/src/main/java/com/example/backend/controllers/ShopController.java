package com.example.backend.controllers;

import com.example.backend.dtos.OrderRequest;
import com.example.backend.dtos.OrderResponse;
import com.example.backend.models.Equipment;
import com.example.backend.services.ShopService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

/**
 * Prodavnica opreme — katalog, kreiranje porudžbine i otkazivanje (sportista).
 */
@RestController
@RequestMapping("/api/shop")
@CrossOrigin(origins = "http://localhost:4200")
public class ShopController {

    private final ShopService shopService;

    public ShopController(ShopService shopService) {
        this.shopService = shopService;
    }

    /** Katalog opreme po sportu — javno dostupno. */
    @GetMapping("/catalog")
    public ResponseEntity<List<Equipment>> getCatalog(@RequestParam("sport_type") String sportType) {
        return ResponseEntity.ok(shopService.getCatalogBySport(sportType));
    }

    /** Kreiranje porudžbine iz korpe. */
    @PostMapping("/orders")
    public ResponseEntity<String> placeOrder(@RequestBody OrderRequest request, Principal principal) {
        shopService.placeOrder(request, principal.getName());
        return ResponseEntity.ok("Porudžbina je uspešno kreirana!");
    }

    /** Istorija i aktivne porudžbine korisnika. */
    @GetMapping("/orders/my")
    public ResponseEntity<List<OrderResponse>> getMyOrders(Principal principal) {
        return ResponseEntity.ok(shopService.getMyOrders(principal.getName()));
    }

    /** Otkazivanje porudžbine u statusu ORDERED (vraća zalihe). */
    @PutMapping("/orders/{orderId}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable Long orderId, Principal principal) {
        shopService.cancelOrder(orderId, principal.getName());
        return ResponseEntity.ok("Porudžbina je uspešno otkazana.");
    }
}
