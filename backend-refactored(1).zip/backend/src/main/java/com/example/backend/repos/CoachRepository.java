package com.example.backend.repos;

import com.example.backend.models.Coach;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CoachRepository extends JpaRepository<Coach, Long> {

    /**
     * Aktivni treneri za dati objekat i sport — samo ako je objekat APPROVED.
     */
    @Query("SELECT c FROM Coach c " +
           "WHERE c.facilityId = :facilityId " +
           "AND c.sport = :sport " +
           "AND c.isActive = true " +
           "AND EXISTS (SELECT 1 FROM Facility f WHERE f.id = c.facilityId AND f.status = 'APPROVED')")
    List<Coach> findCoachesByFacilityAndSport(@Param("facilityId") Long facilityId,
                                              @Param("sport") String sport);

    /**
     * Svi aktivni treneri u objektu (svi sportovi), sortirani po sportu pa imenu.
     */
    @Query("SELECT c FROM Coach c " +
           "WHERE c.facilityId = :facilityId " +
           "AND c.isActive = true " +
           "AND EXISTS (SELECT 1 FROM Facility f WHERE f.id = c.facilityId AND f.status = 'APPROVED') " +
           "ORDER BY c.sport, c.name")
    List<Coach> findAllActiveByFacility(@Param("facilityId") Long facilityId);

    /**
     * Da li trener pripada odobrenom objektu?
     *
     * <p>Koristimo CASE WHEN umesto COUNT() > 0 jer Hibernate 6 COUNT() > 0
     * vraća Long (ne Boolean), što izaziva ClassCastException: Long cannot be
     * cast to Boolean.</p>
     */
    @Query("SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END FROM Coach c " +
           "WHERE c.id = :coachId " +
           "AND EXISTS (SELECT 1 FROM Facility f WHERE f.id = c.facilityId AND f.status = 'APPROVED')")
    boolean isCoachInApprovedFacility(@Param("coachId") Long coachId);
}
