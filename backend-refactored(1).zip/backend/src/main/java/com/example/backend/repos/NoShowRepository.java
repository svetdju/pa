package com.example.backend.repos;

import com.example.backend.models.NoShow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Evidencija nedolazaka po korisniku i objektu. {@link #incrementNoShow(Long, Long, int)}
 * implementira upsert logiku — ako zapis ne postoji, kreira se sa count=1;
 * ako postoji, count se inkrementira, a ako premaši limit, korisnik se blokira.
 */
@Repository
public interface NoShowRepository extends JpaRepository<NoShow, Long> {

    @Query("SELECT COALESCE(n.count, 0) FROM NoShow n WHERE n.userId = :userId AND n.facilityId = :facilityId")
    Integer getNoShowCountRaw(@Param("userId") Long userId, @Param("facilityId") Long facilityId);

    default int getNoShowCount(Long userId, Long facilityId) {
        Integer v = getNoShowCountRaw(userId, facilityId);
        return v == null ? 0 : v;
    }

    /**
     * Da li je korisnik blokiran u ovom objektu?
     *
     * <p>Koristimo CASE WHEN umesto COALESCE jer MySQL tinyint(1) kolona isBlocked
     * se kroz JPQL COALESCE vraća kao Long (ne Boolean), što izaziva
     * ClassCastException: Long cannot be cast to Boolean.</p>
     */
    @Query("SELECT CASE WHEN n.isBlocked = true THEN true ELSE false END FROM NoShow n WHERE n.userId = :userId AND n.facilityId = :facilityId")
    Boolean isUserBlockedRaw(@Param("userId") Long userId, @Param("facilityId") Long facilityId);

    default boolean isUserBlocked(Long userId, Long facilityId) {
        Boolean v = isUserBlockedRaw(userId, facilityId);
        return Boolean.TRUE.equals(v);
    }

    /**
     * Inkrementira broj nedolazaka. Kreira zapis ako ne postoji; blokira korisnika
     * ako count premaši {@code maxNoShows}.
     */
    default void incrementNoShow(Long userId, Long facilityId, int maxNoShows) {
        Optional<NoShow> existing = findByUserIdAndFacilityId(userId, facilityId);
        NoShow ns;
        if (existing.isPresent()) {
            ns = existing.get();
            ns.setCount(ns.getCount() + 1);
        } else {
            ns = new NoShow();
            ns.setUserId(userId);
            ns.setFacilityId(facilityId);
            ns.setCount(1);
            ns.setIsBlocked(false);
        }
        if (ns.getCount() >= maxNoShows) {
            ns.setIsBlocked(true);
        }
        save(ns);
    }

    Optional<NoShow> findByUserIdAndFacilityId(Long userId, Long facilityId);

    /** Limit nedolazaka za objekat, sa default 3 ako objekat ne postoji. */
    @Query("SELECT COALESCE(f.maxNoShows, 3) FROM Facility f WHERE f.id = :facilityId")
    Integer getMaxNoShowsRaw(@Param("facilityId") Long facilityId);

    default int getMaxNoShows(Long facilityId) {
        Integer v = getMaxNoShowsRaw(facilityId);
        return v == null ? 3 : v;
    }
}
