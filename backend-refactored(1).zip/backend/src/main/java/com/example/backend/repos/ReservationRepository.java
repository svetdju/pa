package com.example.backend.repos;

import com.example.backend.dtos.ReservationResponse;
import com.example.backend.models.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Pristup rezervacijama terena. Sve metode koje {@link com.example.backend.services.ReservationService}
 * i {@link com.example.backend.services.EmployeeBookingService} pozivaju su ovde.
 */
@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    /** Menja status rezervacije; vraća broj pogođenih redova. */
    @Modifying
    @Query("UPDATE Reservation r SET r.status = :status WHERE r.id = :id")
    int updateStatus(@Param("id") Long id, @Param("status") String status);

    /** Pomera datum/vreme rezervacije (drag-and-drop u kalendaru). */
    @Modifying
    @Query("UPDATE Reservation r SET r.reservationDate = :date, r.startTime = :startTime, r.endTime = :endTime WHERE r.id = :id")
    int updateDateTime(@Param("id") Long id,
                       @Param("date") String date,
                       @Param("startTime") String startTime,
                       @Param("endTime") String endTime);

    /**
     * Postoji li CONFIRMED rezervacija koja se preklapa sa zadatim terminom?
     * Preklapanje je definisano standardnim interval-testom
     * {@code start_time < end AND end_time > start}.
     */
    @Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END FROM reservations r " +
                   "JOIN courts c ON r.court_id = c.id " +
                   "JOIN facilities f ON c.facility_id = f.id " +
                   "WHERE r.court_id = :courtId " +
                   "AND r.reservation_date = :date " +
                   "AND r.status = 'CONFIRMED' " +
                   "AND (r.start_time < :endTime AND r.end_time > :startTime)",
           nativeQuery = true)
    boolean existsOverlapping(@Param("courtId") Long courtId,
                              @Param("date") String date,
                              @Param("startTime") String startTime,
                              @Param("endTime") String endTime);

    /** Isto kao {@link #existsOverlapping} ali isključuje rezervaciju sa datim ID-om. */
    @Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END FROM reservations r " +
                   "JOIN courts c ON r.court_id = c.id " +
                   "JOIN facilities f ON c.facility_id = f.id " +
                   "WHERE r.court_id = :courtId " +
                   "AND r.reservation_date = :date " +
                   "AND r.status = 'CONFIRMED' " +
                   "AND r.id <> :excludeId " +
                   "AND (r.start_time < :endTime AND r.end_time > :startTime)",
           nativeQuery = true)
    boolean existsOverlappingExcluding(@Param("courtId") Long courtId,
                                       @Param("date") String date,
                                       @Param("startTime") String startTime,
                                       @Param("endTime") String endTime,
                                       @Param("excludeId") Long excludeId);

    /**
     * Sve rezervacije korisnika — vraća se kao DTO projection koji sadrži
     * podatke i iz objekta i iz terena (naziv, grad, sport).
     */
    @Query(value = "SELECT r.id, r.user_id, r.reservation_date, r.start_time, r.end_time, r.status, " +
                   "f.name AS facility_name, f.city AS city, " +
                   "c.court_name AS court_name_number, c.sport_type AS sport " +
                   "FROM reservations r " +
                   "JOIN courts c ON r.court_id = c.id " +
                   "JOIN facilities f ON c.facility_id = f.id " +
                   "WHERE r.user_id = :userId AND f.status = 'APPROVED' " +
                   "ORDER BY r.reservation_date DESC, r.start_time DESC",
           nativeQuery = true)
    List<Object[]> findAllByUserIdRaw(@Param("userId") Long userId);

    default List<ReservationResponse> findAllByUserId(Long userId) {
        List<Object[]> rows = findAllByUserIdRaw(userId);
        java.util.List<ReservationResponse> result = new java.util.ArrayList<>(rows.size());
        for (Object[] r : rows) {
            ReservationResponse rr = new ReservationResponse();
            rr.setId(((Number) r[0]).longValue());
            rr.setUser_id(((Number) r[1]).longValue());
            rr.setReservation_date(r[2] != null ? r[2].toString() : null);
            rr.setStart_time(r[3] != null ? r[3].toString() : null);
            rr.setEnd_time(r[4] != null ? r[4].toString() : null);
            rr.setStatus((String) r[5]);
            rr.setFacility_name((String) r[6]);
            rr.setCity((String) r[7]);
            rr.setCourt_name_number((String) r[8]);
            rr.setSport((String) r[9]);
            result.add(rr);
        }
        return result;
    }

    /**
     * Zauzeti termini za teren na određeni dan (status CONFIRMED ili PENDING),
     * ali samo ako je objekat APPROVED. Koristi se za interaktivni kalendar.
     */
    @Query(value = "SELECT r.* FROM reservations r " +
                   "JOIN courts c ON r.court_id = c.id " +
                   "JOIN facilities f ON c.facility_id = f.id " +
                   "WHERE r.court_id = :courtId " +
                   "AND r.reservation_date = :date " +
                   "AND r.status IN ('CONFIRMED','PENDING') " +
                   "AND f.status = 'APPROVED'",
           nativeQuery = true)
    List<Reservation> findAllByCourtIdAndDate(@Param("courtId") Long courtId,
                                              @Param("date") String date);

    /**
     * Broj potvrđenih i završenih rezervacija korisnika u datom objektu.
     * Koristi se za proveru da li korisnik sme da ostavi ocenu.
     */
    @Query("SELECT COUNT(r) FROM Reservation r " +
           "WHERE r.userId = :userId " +
           "AND r.courtId IN (SELECT c.id FROM Court c WHERE c.facilityId = :facilityId) " +
           "AND r.status IN ('CONFIRMED','COMPLETED')")
    int countConfirmedByUserAndFacility(@Param("userId") Long userId,
                                        @Param("facilityId") Long facilityId);
}
