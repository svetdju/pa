package com.example.backend.services;

import com.example.backend.dtos.AdminUserResponse;
import com.example.backend.models.Coach;
import com.example.backend.models.Court;
import com.example.backend.models.Facility;
import com.example.backend.models.Sport;
import com.example.backend.models.User;
import com.example.backend.repos.AdminRepository;
import com.example.backend.repos.CoachRepository;
import com.example.backend.repos.CourtRepository;
import com.example.backend.repos.FacilityRepository;
import com.example.backend.repos.SportsRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Administratorske funkcije: upravljanje korisnicima, objektima, trenerima i
 * sportovima. Admin odobrava/odbija registracije i nove objekte, deaktivira
 * trenere i dodaje nove sportove u katalog.
 */
@Service
public class AdminService {

    private final AdminRepository adminRepository;
    private final FacilityRepository facilityRepository;
    private final CoachRepository coachRepository;
    private final CourtRepository courtRepository;
    private final SportsRepository sportsRepository;

    public AdminService(AdminRepository adminRepository,
                        FacilityRepository facilityRepository,
                        CoachRepository coachRepository,
                        CourtRepository courtRepository,
                        SportsRepository sportsRepository) {
        this.adminRepository = adminRepository;
        this.facilityRepository = facilityRepository;
        this.coachRepository = coachRepository;
        this.courtRepository = courtRepository;
        this.sportsRepository = sportsRepository;
    }

    public List<AdminUserResponse> getAllUsers() {
        return adminRepository.findAllUsers().stream()
                .map(this::toAdminUserResponse)
                .collect(Collectors.toList());
    }

    /**
     * Menja status korisnika iz PENDING u APPROVED ili REJECTED.
     * Starija vrednost {@code DECLINED} se interno normalizuje na REJECTED.
     */
    public void updateUserStatus(Long userId, String status) {
        String normalized = normalizeStatus(status);
        if (!"APPROVED".equals(normalized) && !"REJECTED".equals(normalized)) {
            throw new RuntimeException("Status može biti samo APPROVED ili REJECTED.");
        }

        User user = adminRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Korisnik sa ID-jem '" + userId + "' nije pronađen."));

        if (!"PENDING".equals(user.getStatus())) {
            throw new RuntimeException("Samo korisnik sa statusom PENDING može se promeniti.");
        }

        int updated = adminRepository.updateUserStatus(userId, normalized);
        if (updated == 0) {
            throw new RuntimeException("Nije moguće ažurirati status korisnika.");
        }
    }

    public void deleteUser(Long userId) {
        if (!adminRepository.existsById(userId)) {
            throw new RuntimeException("Korisnik sa ID-jem '" + userId + "' nije pronađen.");
        }
        adminRepository.deleteById(userId);
    }

    /**
     * Menja status objekta iz PENDING u APPROVED ili REJECTED.
     */
    public void updateFacilityStatus(Long facilityId, String status) {
        String normalized = normalizeStatus(status);
        if (!"APPROVED".equals(normalized) && !"REJECTED".equals(normalized)) {
            throw new RuntimeException("Status objekta može biti samo APPROVED ili REJECTED.");
        }

        Facility facility = facilityRepository.findById(facilityId)
                .orElseThrow(() -> new RuntimeException("Objekat sa ID-jem '" + facilityId + "' nije pronađen."));

        if (!"PENDING".equals(facility.getStatus())) {
            throw new RuntimeException("Samo objekti sa statusom PENDING mogu se ažurirati.");
        }

        int updated = adminRepository.updateFacilityStatus(facilityId, normalized);
        if (updated == 0) {
            throw new RuntimeException("Nije moguće ažurirati status objekta.");
        }
    }

    public List<Facility> getPendingFacilities() {
        return adminRepository.findPendingFacilities();
    }

    public List<Court> getFacilityCourts(Long facilityId) {
        facilityRepository.findById(facilityId)
                .orElseThrow(() -> new RuntimeException("Objekat sa ID-jem '" + facilityId + "' nije pronađen."));
        return courtRepository.findByFacilityIdIncludePending(facilityId);
    }

    public List<Coach> getAllCoaches() {
        return adminRepository.findAllCoaches();
    }

    public Coach getCoachById(Long coachId) {
        return coachRepository.findById(coachId)
                .orElseThrow(() -> new RuntimeException("Trener sa ID-jem '" + coachId + "' nije pronađen."));
    }

    public void updateCoachActiveStatus(Long coachId, Boolean isActive) {
        if (isActive == null) {
            throw new RuntimeException("Parametar isActive je obavezan.");
        }
        coachRepository.findById(coachId)
                .orElseThrow(() -> new RuntimeException("Trener sa ID-jem '" + coachId + "' nije pronađen."));

        int updated = adminRepository.updateCoachActiveStatus(coachId, isActive);
        if (updated == 0) {
            throw new RuntimeException("Nije moguće ažurirati status trenera.");
        }
    }

    /** Dodaje novi sport u katalog ako već ne postoji. */
    public void addSport(Sport sport) {
        if (sport == null || sport.getName() == null || sport.getName().trim().isEmpty()) {
            throw new RuntimeException("Naziv sporta je obavezan.");
        }
        String name = sport.getName().trim();
        if (sportsRepository.existsByName(name)) {
            throw new RuntimeException("Sport sa nazivom '" + name + "' već postoji.");
        }
        sport.setName(name);
        Sport saved = sportsRepository.save(sport);
        if (saved == null || saved.getId() == null) {
            throw new RuntimeException("Nije moguće dodati sport.");
        }
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private AdminUserResponse toAdminUserResponse(User user) {
        return new AdminUserResponse(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                user.getPhone(),
                user.getRole(),
                user.getStatus(),
                user.getProfilePicturePath(),
                user.getFavoriteSports());
    }

    private String normalizeStatus(String status) {
        if (status == null) return "";
        String s = status.trim().toUpperCase();
        // "DECLINED" je starija vrednost — normalizujemo na "REJECTED"
        if ("DECLINED".equals(s)) return "REJECTED";
        return s;
    }
}
