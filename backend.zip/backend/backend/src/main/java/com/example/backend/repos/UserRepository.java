package com.example.backend.repos;

import com.example.backend.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

import com.example.backend.dtos.EmployeeProfileResponse.EmployeeFacilityDTO;

/**
 * Pristup korisnicima sistema. Sve metode koje {@link com.example.backend.services.UserService}
 * i drugi servisi pozivaju su ovde; neke su izvedene preko {@code default} metoda
 * koje mapiraju raw projection redove u strogo tipizirane DTO-e.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /** Pronalazi nalog po korisničkom imenu — koristi se pri login-u i JWT validaciji. */
    Optional<User> findByUsername(String username);

    /**
     * Ažurira lične podatke korisnika (ime, prezime, telefon, email) po korisničkom imenu.
     * Vraća broj pogođenih redova.
     */
    @Modifying
    @Query("UPDATE User u SET u.firstName = :firstName, u.lastName = :lastName, " +
           "u.phone = :phone, u.email = :email WHERE u.username = :username")
    int updateProfile(@Param("username") String username,
                      @Param("firstName") String firstName,
                      @Param("lastName") String lastName,
                      @Param("phone") String phone,
                      @Param("email") String email);

    /** Ažurira listu omiljenih sportova korisnika. */
    @Modifying
    @Query("UPDATE User u SET u.favoriteSports = :favoriteSports WHERE u.username = :username")
    int updateFavoriteSports(@Param("username") String username,
                             @Param("favoriteSports") String favoriteSports);

    /** Ažurira profilnu sliku korisnika. */
    @Modifying
    @Query("UPDATE User u SET u.profilePicturePath = :imagePath WHERE u.username = :username")
    int updateProfileImage(@Param("username") String username,
                           @Param("imagePath") String imagePath);

    /**
     * Sve objekte za koje je dati zaposleni zadužen. Vraća raw redove jer je u pitanju
     * DTO projection iz više tabela (facilities + facility_employees).
     */
    @Query(value = "SELECT f.id, f.name, f.city, f.address, f.description, f.price_per_hour, " +
                   "f.type, f.status, f.company_name, f.company_address, f.company_id_number, f.pib " +
                   "FROM facilities f " +
                   "JOIN facility_employees fe ON f.id = fe.facility_id " +
                   "WHERE fe.user_id = :userId", nativeQuery = true)
    List<Object[]> findFacilityRowsByUserId(@Param("userId") Long userId);

    /** Konverzija raw redova u {@link EmployeeFacilityDTO}. */
    default List<EmployeeFacilityDTO> findFacilitiesByUserId(Long userId) {
        List<Object[]> rows = findFacilityRowsByUserId(userId);
        java.util.List<EmployeeFacilityDTO> result = new java.util.ArrayList<>(rows.size());
        for (Object[] r : rows) {
            result.add(new EmployeeFacilityDTO(
                    ((Number) r[0]).longValue(),
                    (String) r[1],
                    (String) r[2],
                    (String) r[3],
                    (String) r[4],
                    ((Number) r[5]).doubleValue(),
                    (String) r[6],
                    (String) r[7],
                    (String) r[8],
                    (String) r[9],
                    (String) r[10],
                    (String) r[11]));
        }
        return result;
    }

    /**
     * Traži ID objekta po četiri striktna administrativna parametra. Vraća
     * {@code null} ako objekat ne postoji.
     */
    @Query("SELECT f.id FROM Facility f WHERE f.name = :name " +
           "AND f.companyIdNumber = :companyIdNumber " +
           "AND f.pib = :pib " +
           "AND f.companyAddress = :companyAddress")
    List<Long> findFacilityIdByDetailsRaw(@Param("name") String name,
                                          @Param("companyIdNumber") String companyIdNumber,
                                          @Param("pib") String pib,
                                          @Param("companyAddress") String companyAddress);

    default Long findFacilityIdByDetails(String name, String companyIdNumber, String pib, String companyAddress) {
        List<Long> ids = findFacilityIdByDetailsRaw(name, companyIdNumber, pib, companyAddress);
        return ids.isEmpty() ? null : ids.get(0);
    }

    /** Broji koliko je zaposlenih dodeljeno datom objektu. */
    @Query("SELECT COUNT(fe) FROM FacilityEmployee fe WHERE fe.facilityId = :facilityId")
    long countEmployeesForFacilityRaw(@Param("facilityId") Long facilityId);

    default int countEmployeesForFacility(Long facilityId) {
        return (int) countEmployeesForFacilityRaw(facilityId);
    }

    /**
     * Da li je dati zaposleni dodeljen datom objektu?
     *
     * <p>Koristimo CASE WHEN umesto COUNT() > 0 jer Hibernate 6 vraća Long (ne Boolean).</p>
     */
    @Query("SELECT CASE WHEN COUNT(fe) > 0 THEN 1 ELSE 0 END FROM FacilityEmployee fe " +
           "WHERE fe.facilityId = :facilityId AND fe.userId = :userId")
    Integer isEmployeeAssignedToFacilityRaw(@Param("facilityId") Long facilityId,
                                         @Param("userId") Long userId);

    default boolean isEmployeeAssignedToFacility(Long facilityId, Long userId) {
        Integer r = isEmployeeAssignedToFacilityRaw(facilityId, userId);
        return r != null && r == 1;
    }
}
