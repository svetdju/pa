package com.example.backend.repos;

import com.example.backend.models.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Stavke porudžbine. Servisi koriste nasleđeni {@code save()} i {@code findById()}.
 */
@Repository
public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {
}
