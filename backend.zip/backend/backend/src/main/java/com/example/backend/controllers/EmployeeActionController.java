package com.example.backend.controllers;

import com.example.backend.dtos.OrderResponse;
import com.example.backend.dtos.ReservationViewResponse;
import com.example.backend.services.EmployeeBookingService;
import com.example.backend.services.EmployeeShopService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

/**
 * Zaposleni dashboard — check-in tabela, kalendar, pending zahtevi,
 * upravljanje porudžbinama i drag-and-drop pomeranje rezervacija.
 */
@RestController
@RequestMapping("/api/employee/dashboard")
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeActionController {

    private final EmployeeBookingService employeeBookingService;
    private final EmployeeShopService employeeShopService;

    public EmployeeActionController(EmployeeBookingService employeeBookingService,
                                    EmployeeShopService employeeShopService) {
        this.employeeBookingService = employeeBookingService;
        this.employeeShopService = employeeShopService;
    }

    /** Današnje CONFIRMED/SCHEDULED rezervacije za check-in tabelu. */
    @GetMapping("/table")
    public ResponseEntity<List<ReservationViewResponse>> getCheckInTable(Principal principal) {
        return ResponseEntity.ok(employeeBookingService.getCheckInTable(principal.getName()));
    }

    /** PENDING rezervacije koje čekaju odobrenje. */
    @GetMapping("/pending")
    public ResponseEntity<List<ReservationViewResponse>> getPendingRequests(Principal principal) {
        return ResponseEntity.ok(employeeBookingService.getPendingRequests(principal.getName()));
    }

    /** Zauzeća za teren u periodu — za interaktivni kalendar. */
    @GetMapping("/calendar")
    public ResponseEntity<List<ReservationViewResponse>> getCalendarData(
            @RequestParam("court_id") Long courtId,
            @RequestParam("startDate") String startDate,
            @RequestParam("endDate") String endDate) {
        return ResponseEntity.ok(employeeBookingService.getCalendarData(courtId, startDate, endDate));
    }

    /** Check-in akcija: CONFIRM (došao) ili REJECT (nije došao). */
    @PostMapping("/check-in")
    public ResponseEntity<String> handleCheckIn(@RequestParam("type") String type,
                                                @RequestParam("id") Long id,
                                                @RequestParam("action") String action) {
        employeeBookingService.processCheckInAction(type, id, action);
        return ResponseEntity.ok("Uspešno procesuirana akcija: " + action);
    }

    /** Odobravanje ili odbijanje PENDING rezervacije. */
    @PostMapping("/pending/decide")
    public ResponseEntity<String> handleApproval(@RequestParam("id") Long id,
                                                 @RequestParam("approve") boolean approve) {
        try {
            employeeBookingService.processPendingApproval(id, approve);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
        String message = approve ? "Rezervacija odobrena (CONFIRMED)." : "Rezervacija odbijena (CANCELLED).";
        return ResponseEntity.ok(message);
    }

    /** Sve porudžbine u sistemu (zaposleni pregled). */
    @GetMapping("/orders")
    public ResponseEntity<List<OrderResponse>> getAllOrdersForStaff() {
        return ResponseEntity.ok(employeeShopService.getAllOrders());
    }

    /** Prihvatanje porudžbine (ORDERED → ACCEPTED). */
    @PutMapping("/orders/{orderId}/accept")
    public ResponseEntity<String> acceptOrder(@PathVariable Long orderId) {
        employeeShopService.acceptOrder(orderId);
        return ResponseEntity.ok("Narudžbina " + orderId + " je prihvaćena (ACCEPTED).");
    }

    /** Označavanje porudžbine kao preuzete (DELIVERED). */
    @PutMapping("/orders/{orderId}/deliver")
    public ResponseEntity<String> markOrderAsDelivered(@PathVariable Long orderId) {
        employeeShopService.markOrderAsDelivered(orderId);
        return ResponseEntity.ok("Narudžbina " + orderId + " je preuzeta (DELIVERED).");
    }

    /** Otkazivanje porudžbine od strane zaposlenog (vraća zalihe). */
    @PutMapping("/orders/{orderId}/cancel")
    public ResponseEntity<String> cancelOrderAsStaff(@PathVariable Long orderId) {
        employeeShopService.cancelOrderAsStaff(orderId);
        return ResponseEntity.ok("Narudžbina " + orderId + " je otkazana i zalihe su vraćene.");
    }

    /** Pomeranje rezervacije na novi termin (drag-and-drop). */
    @PutMapping("/move")
    public ResponseEntity<String> moveReservation(@RequestParam("reservationId") Long reservationId,
                                                  @RequestParam("newDate") String newDate,
                                                  @RequestParam("newStartTime") String newStartTime,
                                                  @RequestParam("newEndTime") String newEndTime) {
        try {
            employeeBookingService.moveReservation(reservationId, newDate, newStartTime, newEndTime);
            return ResponseEntity.ok("Rezervacija je uspešno pomerena.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
