package com.example.backend.services;

import com.example.backend.dtos.StatisticsResponse;
import com.example.backend.models.User;
import com.example.backend.repos.UserRepository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Statistika aktivnosti sportiste — tri dijagrama:
 * <ol>
 *   <li>Bar chart: broj rezervacija po sportu</li>
 *   <li>Line chart: mesečna aktivnost (rezervacije + treninzi)</li>
 *   <li>Ukupna potrošnja na opremu</li>
 * </ol>
 *
 * <p>Koristi {@link JdbcTemplate} jer upiti koriste MySQL-specifične funkcije
 * {@code DATE_FORMAT} i {@code UNION ALL} koje JPA ne podržava lako.</p>
 */
@Service
public class StatisticsService {

    private final JdbcTemplate jdbcTemplate;
    private final UserRepository userRepository;

    public StatisticsService(JdbcTemplate jdbcTemplate, UserRepository userRepository) {
        this.jdbcTemplate = jdbcTemplate;
        this.userRepository = userRepository;
    }

    public StatisticsResponse getMyStatistics(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));
        Long userId = user.getId();

        List<Map<String, Object>> reservationsBySport = countReservationsBySport(userId);
        List<Map<String, Object>> monthlyActivity = countMonthlyActivity(userId);
        double totalSpending = sumTotalSpending(userId);

        return new StatisticsResponse(reservationsBySport, monthlyActivity, totalSpending);
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private List<Map<String, Object>> countReservationsBySport(Long userId) {
        String sql = "SELECT c.sport_type AS sport, COUNT(*) AS count " +
                "FROM reservations r " +
                "JOIN courts c ON r.court_id = c.id " +
                "WHERE r.user_id = ? AND r.status IN ('CONFIRMED','COMPLETED','PENDING') " +
                "GROUP BY c.sport_type " +
                "ORDER BY count DESC";
        return jdbcTemplate.queryForList(sql, userId);
    }

    private List<Map<String, Object>> countMonthlyActivity(Long userId) {
        String sql = "SELECT month_label, SUM(cnt) AS count FROM (" +
                "  SELECT DATE_FORMAT(r.reservation_date, '%Y-%m') AS month_label, COUNT(*) AS cnt " +
                "  FROM reservations r WHERE r.user_id = ? AND r.status != 'CANCELLED' " +
                "  GROUP BY DATE_FORMAT(r.reservation_date, '%Y-%m') " +
                "  UNION ALL " +
                "  SELECT DATE_FORMAT(t.training_date, '%Y-%m') AS month_label, COUNT(*) AS cnt " +
                "  FROM trainings t WHERE t.user_id = ? AND t.status != 'CANCELLED' " +
                "  GROUP BY DATE_FORMAT(t.training_date, '%Y-%m') " +
                ") combined " +
                "GROUP BY month_label " +
                "ORDER BY month_label ASC";
        return jdbcTemplate.queryForList(sql, userId, userId);
    }

    private double sumTotalSpending(Long userId) {
        String sql = "SELECT COALESCE(SUM(total_price), 0) AS total " +
                "FROM orders WHERE user_id = ? AND status != 'CANCELLED'";
        Double total = jdbcTemplate.queryForObject(sql, Double.class, userId);
        return total == null ? 0.0 : total;
    }
}
