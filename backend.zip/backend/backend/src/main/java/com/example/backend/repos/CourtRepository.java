package com.example.backend.repos;

import com.example.backend.models.Court;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CourtRepository extends JpaRepository<Court, Long> {

    /**
     * Svi tereni datog objekta — ali samo ako je objekat APPROVED.
     */
    @Query("SELECT c FROM Court c WHERE c.facilityId = :facilityId " +
           "AND EXISTS (SELECT 1 FROM Facility f WHERE f.id = c.facilityId AND f.status = 'APPROVED')")
    List<Court> findByFacilityId(@Param("facilityId") Long facilityId);

    /**
     * Svi tereni datog objekta bez obzira na status (koristi admin/employee dashboard).
     */
    List<Court> findAllByFacilityId(Long facilityId);

    default List<Court> findByFacilityIdIncludePending(Long facilityId) {
        return findAllByFacilityId(facilityId);
    }

    /** Da li postoji teren sa datim imenom u okviru objekta? */
    boolean existsByFacilityIdAndCourtName(Long facilityId, String courtName);

    /**
     * Da li teren pripada odobrenom objektu?
     *
     * <p>Koristimo CASE WHEN umesto COUNT() > 0 jer Hibernate 6 COUNT() > 0
     * vraća Long (ne Boolean), što izaziva ClassCastException.</p>
     */
    @Query("SELECT CASE WHEN COUNT(c) > 0 THEN 1 ELSE 0 END FROM Court c " +
           "WHERE c.id = :courtId " +
           "AND EXISTS (SELECT 1 FROM Facility f WHERE f.id = c.facilityId AND f.status = 'APPROVED')")
    Integer isCourtInApprovedFacilityRaw(@Param("courtId") Long courtId);

    default boolean isCourtInApprovedFacility(Long courtId) {
        Integer r = isCourtInApprovedFacilityRaw(courtId);
        return r != null && r == 1;
    }

    /** Vraća ID objekta u kom se nalazi dati teren, ili {@code null}. */
    @Query("SELECT c.facilityId FROM Court c WHERE c.id = :courtId")
    List<Long> findFacilityIdByCourtIdRaw(@Param("courtId") Long courtId);

    default Long getFacilityIdByCourtId(Long courtId) {
        List<Long> ids = findFacilityIdByCourtIdRaw(courtId);
        return ids.isEmpty() ? null : ids.get(0);
    }
}
