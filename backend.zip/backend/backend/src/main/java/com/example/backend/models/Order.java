package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Porudžbina opreme. Statusi: {@code ORDERED} | {@code ACCEPTED} |
 * {@code DELIVERED} | {@code CANCELLED}.
 *
 * <p>Datum porudžbine se čuva kao String ({@code yyyy-MM-dd HH:mm:ss}) radi
 * kompatibilnosti sa {@link com.example.backend.dtos.OrderResponse}.</p>
 */
@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "order_date", nullable = false)
    private String orderDate;

    @Column(name = "total_price", nullable = false)
    private Double totalPrice;

    @Column(name = "status", nullable = false, length = 20)
    private String status;
}
