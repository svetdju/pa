package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Slika u galeriji sportskog objekta. {@code imagePath} može biti apsolutni
 * URL (npr. https://picsum.photos/...) ili lokalna putanja ("/uploads/...").
 */
@Entity
@Table(name = "facility_images")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FacilityImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "facility_id", nullable = false)
    private Long facilityId;

    @Column(name = "image_path", nullable = false, length = 500)
    private String imagePath;
}
