package com.example.backend.repos;

import com.example.backend.dtos.ReservationViewResponse;
import com.example.backend.models.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Zaposleni dashboard — check-in tabela, kalendar i pending zahtevi.
 *
 * <p>Sve tri metode ({@link #getDashboardForEmployee(Long)},
 * {@link #getCalendarData(Long, String, String)}, {@link #getPendingReservationsForEmployee(Long)})
 * kombinuju rezervacije i treninge. Implementacija izvršava dva odvojena
 * native upita (jedan za rezervacije, drugi za treninge) i spaja rezultate
 * u Java kodu, sortirano po datumu i početnom vremenu.</p>
 *
 * <p>Polje {@code actionAllowed} u {@link ReservationViewResponse} se računa
 * u {@link #mapRowsToView(List)}: tačno je samo ako je status aktivan
 * (CONFIRMED / SCHEDULED), termin je danas i trenutno vreme je unutar
 * 10-minutnog prozora od početka termina.</p>
 */
@Repository
public interface BookingRepository extends JpaRepository<Reservation, Long> {

    // =========================================================================
    // 1. CHECK-IN TABELA — današnje CONFIRMED rezervacije + SCHEDULED treninzi
    //    za sve objekte u kojima je dati zaposleni zadužen
    // =========================================================================

    @Query(value = "SELECT r.id, 'RESERVATION' AS type, " +
                   "CONCAT(u.first_name, ' ', u.last_name) AS user_name, " +
                   "r.court_id, co.court_name, NULL AS coach_name, " +
                   "r.reservation_date AS b_date, r.start_time, r.end_time, r.status " +
                   "FROM reservations r " +
                   "JOIN courts co ON r.court_id = co.id " +
                   "JOIN facilities f ON co.facility_id = f.id " +
                   "JOIN facility_employees fe ON f.id = fe.facility_id " +
                   "JOIN users u ON r.user_id = u.id " +
                   "WHERE fe.user_id = :employeeId " +
                   "AND r.status = 'CONFIRMED' " +
                   "AND f.status = 'APPROVED' " +
                   "AND r.reservation_date = CURDATE()",
           nativeQuery = true)
    List<Object[]> findTodayConfirmedReservationsForEmployee(@Param("employeeId") Long employeeId);

    @Query(value = "SELECT t.id, 'TRAINING' AS type, " +
                   "CONCAT(u.first_name, ' ', u.last_name) AS user_name, " +
                   "t.court_id, co.court_name, ch.name AS coach_name, " +
                   "t.training_date AS b_date, t.start_time, t.end_time, t.status " +
                   "FROM trainings t " +
                   "JOIN courts co ON t.court_id = co.id " +
                   "JOIN facilities f ON co.facility_id = f.id " +
                   "JOIN facility_employees fe ON f.id = fe.facility_id " +
                   "JOIN users u ON t.user_id = u.id " +
                   "JOIN coaches ch ON t.coach_id = ch.id " +
                   "WHERE fe.user_id = :employeeId " +
                   "AND t.status = 'SCHEDULED' " +
                   "AND f.status = 'APPROVED' " +
                   "AND t.training_date = CURDATE()",
           nativeQuery = true)
    List<Object[]> findTodayScheduledTrainingsForEmployee(@Param("employeeId") Long employeeId);

    default List<ReservationViewResponse> getDashboardForEmployee(Long employeeId) {
        List<Object[]> resRows = findTodayConfirmedReservationsForEmployee(employeeId);
        List<Object[]> trainRows = findTodayScheduledTrainingsForEmployee(employeeId);

        List<ReservationViewResponse> merged = new java.util.ArrayList<>();
        merged.addAll(mapRowsToView(resRows));
        merged.addAll(mapRowsToView(trainRows));
        merged.sort(java.util.Comparator.comparing(ReservationViewResponse::getStartTime));
        return merged;
    }

    // =========================================================================
    // 2. KALENDAR — sve rezervacije i treninzi za dati teren u periodu
    // =========================================================================

    @Query(value = "SELECT r.id, 'RESERVATION' AS type, " +
                   "CONCAT(u.first_name, ' ', u.last_name) AS user_name, " +
                   "r.court_id, co.court_name, NULL AS coach_name, " +
                   "r.reservation_date AS b_date, r.start_time, r.end_time, r.status " +
                   "FROM reservations r " +
                   "JOIN courts co ON r.court_id = co.id " +
                   "JOIN facilities f ON co.facility_id = f.id " +
                   "JOIN users u ON r.user_id = u.id " +
                   "WHERE r.court_id = :courtId " +
                   "AND r.reservation_date BETWEEN :startDate AND :endDate " +
                   "AND f.status = 'APPROVED'",
           nativeQuery = true)
    List<Object[]> findCalendarReservations(@Param("courtId") Long courtId,
                                            @Param("startDate") String startDate,
                                            @Param("endDate") String endDate);

    @Query(value = "SELECT t.id, 'TRAINING' AS type, " +
                   "CONCAT(u.first_name, ' ', u.last_name) AS user_name, " +
                   "t.court_id, co.court_name, ch.name AS coach_name, " +
                   "t.training_date AS b_date, t.start_time, t.end_time, t.status " +
                   "FROM trainings t " +
                   "JOIN courts co ON t.court_id = co.id " +
                   "JOIN facilities f ON co.facility_id = f.id " +
                   "JOIN users u ON t.user_id = u.id " +
                   "JOIN coaches ch ON t.coach_id = ch.id " +
                   "WHERE t.court_id = :courtId " +
                   "AND t.training_date BETWEEN :startDate AND :endDate " +
                   "AND f.status = 'APPROVED'",
           nativeQuery = true)
    List<Object[]> findCalendarTrainings(@Param("courtId") Long courtId,
                                         @Param("startDate") String startDate,
                                         @Param("endDate") String endDate);

    default List<ReservationViewResponse> getCalendarData(Long courtId, String startDate, String endDate) {
        List<Object[]> resRows = findCalendarReservations(courtId, startDate, endDate);
        List<Object[]> trainRows = findCalendarTrainings(courtId, startDate, endDate);

        List<ReservationViewResponse> merged = new java.util.ArrayList<>();
        merged.addAll(mapRowsToView(resRows));
        merged.addAll(mapRowsToView(trainRows));
        merged.sort(java.util.Comparator
                .comparing(ReservationViewResponse::getDate)
                .thenComparing(ReservationViewResponse::getStartTime));
        // U kalendar view-u je actionAllowed uvek false — prozor od 10 min se
        // računa samo za check-in tabelu.
        merged.forEach(r -> r.setActionAllowed(false));
        return merged;
    }

    // =========================================================================
    // 3. PENDING ZAHTEVI — samo PENDING rezervacije za objekte zaposlenog
    // =========================================================================

    @Query(value = "SELECT r.id, 'RESERVATION' AS type, " +
                   "CONCAT(u.first_name, ' ', u.last_name) AS user_name, " +
                   "r.court_id, co.court_name, NULL AS coach_name, " +
                   "r.reservation_date AS b_date, r.start_time, r.end_time, r.status " +
                   "FROM reservations r " +
                   "JOIN courts co ON r.court_id = co.id " +
                   "JOIN facilities f ON co.facility_id = f.id " +
                   "JOIN facility_employees fe ON f.id = fe.facility_id " +
                   "JOIN users u ON r.user_id = u.id " +
                   "WHERE fe.user_id = :employeeId " +
                   "AND r.status = 'PENDING' " +
                   "AND f.status = 'APPROVED' " +
                   "ORDER BY b_date ASC, r.start_time ASC",
           nativeQuery = true)
    List<Object[]> findPendingReservationsForEmployeeRaw(@Param("employeeId") Long employeeId);

    default List<ReservationViewResponse> getPendingReservationsForEmployee(Long employeeId) {
        List<ReservationViewResponse> list = mapRowsToView(findPendingReservationsForEmployeeRaw(employeeId));
        list.forEach(r -> r.setActionAllowed(false));
        return list;
    }

    // =========================================================================
    // 4. UPDATE STATUS — radi i za reservations i za trainings
    // =========================================================================

    /**
     * Menja status rezervacije ili treninga u zavisnosti od tipa
     * ({@code "RESERVATION"} ili bilo šta drugo).
     */
    default void updateStatus(String type, Long id, String newStatus) {
        if ("RESERVATION".equals(type)) {
            updateReservationStatus(id, newStatus);
        } else {
            updateTrainingStatus(id, newStatus);
        }
    }

    @Modifying
    @Query("UPDATE Reservation r SET r.status = :status WHERE r.id = :id")
    void updateReservationStatus(@Param("id") Long id, @Param("status") String status);

    @Modifying
    @Query("UPDATE Training t SET t.status = :status WHERE t.id = :id")
    void updateTrainingStatus(@Param("id") Long id, @Param("status") String status);

    // =========================================================================
    // Helper: mapira raw redove u ReservationViewResponse DTO.
    //
    // Red: [id(Long), type(String), user_name(String), court_id(Long),
    //       court_name(String), coach_name(String|null), b_date(java.sql.Date),
    //       start_time(java.sql.Time), end_time(java.sql.Time), status(String)]
    // =========================================================================
    private static List<ReservationViewResponse> mapRowsToView(List<Object[]> rows) {
        List<ReservationViewResponse> result = new java.util.ArrayList<>(rows.size());
        java.time.LocalDate today = java.time.LocalDate.now();
        java.time.LocalTime now = java.time.LocalTime.now();

        for (Object[] r : rows) {
            ReservationViewResponse v = new ReservationViewResponse();
            v.setId(((Number) r[0]).longValue());
            v.setType((String) r[1]);
            v.setUserName((String) r[2]);
            v.setCourtId(((Number) r[3]).longValue());
            v.setCourtName((String) r[4]);
            v.setCoachName((String) r[5]);
            v.setDate(r[6] != null ? r[6].toString() : null);
            v.setStartTime(r[7] != null ? r[7].toString() : null);
            v.setEndTime(r[8] != null ? r[8].toString() : null);
            v.setStatus((String) r[9]);

            // actionAllowed = status aktivan, termin danas, i trenutno vreme u
            // 10-minutnom prozoru od start_time.
            boolean isStatusActive = "CONFIRMED".equals(v.getStatus()) || "SCHEDULED".equals(v.getStatus());
            try {
                if (v.getDate() != null && v.getStartTime() != null) {
                    java.time.LocalDate bookingDate = java.time.LocalDate.parse(v.getDate());
                    java.time.LocalTime startTime = java.time.LocalTime.parse(v.getStartTime());
                    java.time.LocalTime deadline = startTime.plusMinutes(10);

                    boolean isToday = today.equals(bookingDate);
                    boolean withinTenMinutes = !now.isBefore(startTime) && !now.isAfter(deadline);
                    v.setActionAllowed(isStatusActive && isToday && withinTenMinutes);
                } else {
                    v.setActionAllowed(false);
                }
            } catch (Exception e) {
                v.setActionAllowed(false);
            }
            result.add(v);
        }
        return result;
    }
}
