package com.example.backend.controllers;

import com.example.backend.dtos.ReservationRequest;
import com.example.backend.dtos.ReservationResponse;
import com.example.backend.models.Reservation;
import com.example.backend.services.ReservationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

/**
 * Rezervacije terena — kreiranje, otkazivanje i pregled (sportista).
 */
@RestController
@RequestMapping("/api/reservations")
@CrossOrigin(origins = "http://localhost:4200")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    /** Kreira novu rezervaciju (status PENDING). */
    @PostMapping
    public ResponseEntity<String> createReservation(@Valid @RequestBody ReservationRequest request,
                                                    Principal principal) {
        reservationService.createReservation(request, principal.getName());
        return ResponseEntity.ok("Rezervacija je uspešno poslata na čekanje!");
    }

    /** Sve rezervacije ulogovanog korisnika. */
    @GetMapping("/my")
    public ResponseEntity<List<ReservationResponse>> getMyReservations(Principal principal) {
        return ResponseEntity.ok(reservationService.getMyReservations(principal.getName()));
    }

    /** Otkazuje rezervaciju (poštuje pravilo 12 sati za CONFIRMED). */
    @PutMapping("/{id}/cancel")
    public ResponseEntity<String> cancelReservation(@PathVariable Long id, Principal principal) {
        reservationService.cancelReservation(id, principal.getName());
        return ResponseEntity.ok("Rezervacija je uspešno otkazana.");
    }

    /**
     * Zauzeti termini za teren na određeni dan — javno dostupno (ne zahteva
     * JWT), jer ga koristi i neregistrovani korisnik u prikazu detalja objekta.
     */
    @GetMapping("/court/{courtId}")
    public ResponseEntity<List<Reservation>> getCourtReservations(@PathVariable Long courtId,
                                                                  @RequestParam String date) {
        return ResponseEntity.ok(reservationService.getOccupiedSlotsForCourt(courtId, date));
    }
}
