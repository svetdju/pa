package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Oglas "tražim saigrače". Kreator je sportista koji traži ekipu za dati
 * sport, grad i termin. Kada se prijavi dovoljan broj saigrača (ili kada
 * kreator ručno zatvori), status prelazi u {@code CLOSED}.
 */
@Entity
@Table(name = "teammate_ads")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeammateAd {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "creator_id", nullable = false)
    private Long creatorId;

    @Column(name = "sport", nullable = false, length = 50)
    private String sport;

    @Column(name = "city", nullable = false, length = 50)
    private String city;

    @Column(name = "event_date", nullable = false)
    private String eventDate;

    @Column(name = "event_time", nullable = false)
    private String eventTime;

    @Column(name = "players_needed", nullable = false)
    private Integer playersNeeded;

    @Column(name = "status", nullable = false, length = 20)
    private String status;
}
