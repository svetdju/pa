package com.example.backend.repos;

import com.example.backend.models.Facility;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Pristup sportskim objektima. {@link #findByIdAndStatus(Long, String)} se
 * koristi za javne rute gde treba vraćati samo odobrene (APPROVED) objekte.
 */
@Repository
public interface FacilityRepository extends JpaRepository<Facility, Long> {

    /** Vraća objekat po ID-u samo ako mu je status jednak datom. */
    Optional<Facility> findByIdAndStatus(Long id, String status);
}
