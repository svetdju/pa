package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Individualni trening između sportiste ({@link User}) i trenera ({@link Coach}),
 * održan na nekom {@link Court}-u.
 * Statusi: {@code SCHEDULED} | {@code COMPLETED} | {@code CANCELLED}.
 */
@Entity
@Table(name = "trainings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Training {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "coach_id", nullable = false)
    private Long coachId;

    @Column(name = "court_id", nullable = false)
    private Long courtId;

    @Column(name = "training_date", nullable = false)
    private String trainingDate;

    @Column(name = "start_time", nullable = false)
    private String startTime;

    @Column(name = "end_time", nullable = false)
    private String endTime;

    @Column(name = "status", nullable = false, length = 20)
    private String status;
}
