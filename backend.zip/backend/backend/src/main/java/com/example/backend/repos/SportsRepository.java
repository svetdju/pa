package com.example.backend.repos;

import com.example.backend.models.Sport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SportsRepository extends JpaRepository<Sport, Long> {

    /** Vraća samo imena sportova, sortirana abecedno. */
    @Query("SELECT s.name FROM Sport s ORDER BY s.name")
    List<String> findAllSportNames();

    boolean existsByName(String name);
}
