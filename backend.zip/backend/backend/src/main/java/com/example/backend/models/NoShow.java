package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Evidencija nedolazaka korisnika u okviru jednog {@link Facility}-ja.
 * Kada {@code count} premaši {@link Facility#getMaxNoShows()}, postavlja se
 * {@code isBlocked = true} i korisnik gubi pravo rezervacije u tom objektu.
 */
@Entity
@Table(name = "no_shows", uniqueConstraints = {
        @UniqueConstraint(name = "uq_user_facility", columnNames = {"user_id", "facility_id"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoShow {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "facility_id", nullable = false)
    private Long facilityId;

    @Column(name = "count", nullable = false)
    private Integer count;

    @Column(name = "is_blocked", nullable = false)
    private Boolean isBlocked;
}
