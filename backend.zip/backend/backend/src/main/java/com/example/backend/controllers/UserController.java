package com.example.backend.controllers;

import com.example.backend.dtos.AdminUserResponse;
import com.example.backend.dtos.EmployeeProfileResponse;
import com.example.backend.models.User;
import com.example.backend.repos.UserRepository;
import com.example.backend.services.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.security.Principal;
import java.util.Map;

/**
 * Korisnički profil — pregled i ažuriranje ličnih podataka, omiljenih sportova
 * i profilne slike. Dostupno svim ulogovanim korisnicima (ATHLETE, EMPLOYEE, ADMIN).
 */
@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

    private final UserService userService;
    private final UserRepository userRepository;

    public UserController(UserService userService, UserRepository userRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
    }

    /** Pregled sopstvenog profila. */
    @GetMapping("/profile")
    public ResponseEntity<AdminUserResponse> getMyProfile(Principal principal) {
        User user = userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));
        return ResponseEntity.ok(toAdminUserResponse(user));
    }

    /** Ažuriranje ličnih podataka (ime, prezime, telefon, email). */
    @PutMapping("/profile")
    public ResponseEntity<String> updateProfile(@RequestBody Map<String, String> data, Principal principal) {
        userService.updateProfileDetails(principal.getName(),
                data.get("first_name"), data.get("last_name"),
                data.get("phone"), data.get("email"));
        return ResponseEntity.ok("Profil je uspešno ažuriran!");
    }

    /** Ažuriranje liste omiljenih sportova. */
    @PutMapping("/profile/sports")
    public ResponseEntity<String> updateFavoriteSports(@RequestBody String favoriteSports, Principal principal) {
        // Angular ponekad pošalje string sa viškom navodnika — čistimo ih
        String cleaned = favoriteSports.replace("\"", "");
        userService.updateSports(principal.getName(), cleaned);
        return ResponseEntity.ok("Omiljeni sportovi su ažurirani!");
    }

    /** Promena profilne slike (multipart). */
    @PutMapping("/profile/image")
    public ResponseEntity<Map<String, String>> updateProfileImage(@RequestParam("image") MultipartFile file,
                                                                  Principal principal) {
        String savedPath = userService.updateImage(principal.getName(), file);
        return ResponseEntity.ok(Map.of("profile_picture_path", savedPath));
    }

    /** Profil zaposlenog sa listom objekata u kojima radi. */
    @GetMapping("/profile/employee")
    public ResponseEntity<EmployeeProfileResponse> getEmployeeProfile(Principal principal) {
        return ResponseEntity.ok(userService.getEmployeeProfileData(principal.getName()));
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private AdminUserResponse toAdminUserResponse(User user) {
        return new AdminUserResponse(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                user.getPhone(),
                user.getRole(),
                user.getStatus(),
                user.getProfilePicturePath(),
                user.getFavoriteSports());
    }
}
