package com.example.backend.controllers;

import com.example.backend.dtos.FacilityDetailsResponse;
import com.example.backend.dtos.HomepageResponse;
import com.example.backend.dtos.PromotionSummaryResponse;
import com.example.backend.dtos.RatingSummaryResponse;
import com.example.backend.models.Court;
import com.example.backend.models.Facility;
import com.example.backend.repos.CourtRepository;
import com.example.backend.repos.FacilityImageRepository;
import com.example.backend.repos.FacilityRepository;
import com.example.backend.services.FacilityRatingService;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Javne rute — dostupne i neregistrovanim korisnicima.
 *
 * <p>Strategija:</p>
 * <ul>
 *   <li><b>JPA repozitorijumi</b> za jednostavne upite (detalji objekta, galerija, ocene).</li>
 *   <li><b>JdbcTemplate</b> za dinamičku pretragu (LIKE + GROUP_CONCAT) i
 *       kompleksne agregacije (homepage top 3). JdbcTemplate bean se automatski
 *       konfiguriše iz {@code spring.datasource.*}.</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/public")
@CrossOrigin(origins = "http://localhost:4200")
public class PublicController {

    private final JdbcTemplate jdbcTemplate;
    private final FacilityRepository facilityRepository;
    private final CourtRepository courtRepository;
    private final FacilityImageRepository facilityImageRepository;
    private final FacilityRatingService facilityRatingService;

    public PublicController(JdbcTemplate jdbcTemplate,
                            FacilityRepository facilityRepository,
                            CourtRepository courtRepository,
                            FacilityImageRepository facilityImageRepository,
                            FacilityRatingService facilityRatingService) {
        this.jdbcTemplate = jdbcTemplate;
        this.facilityRepository = facilityRepository;
        this.courtRepository = courtRepository;
        this.facilityImageRepository = facilityImageRepository;
        this.facilityRatingService = facilityRatingService;
    }

    /** Pretraga objekata po opcionim filterima: name, city, type, sport. */
    @GetMapping("/facilities")
    public ResponseEntity<List<Map<String, Object>>> searchFacilities(
            @RequestParam(value = "name", required = false) String name,
            @RequestParam(value = "city", required = false) String city,
            @RequestParam(value = "type", required = false) String type,
            @RequestParam(value = "sport", required = false) String sport) {

        StringBuilder sql = new StringBuilder(
                "SELECT f.*, GROUP_CONCAT(DISTINCT c.sport_type) AS sports " +
                "FROM facilities f " +
                "LEFT JOIN courts c ON c.facility_id = f.id " +
                "WHERE f.status = 'APPROVED'");
        List<Object> params = new ArrayList<>();

        if (name != null && !name.isBlank()) {
            sql.append(" AND LOWER(f.name) LIKE ?");
            params.add("%" + name.toLowerCase() + "%");
        }
        if (city != null && !city.isBlank()) {
            sql.append(" AND LOWER(f.city) = ?");
            params.add(city.toLowerCase());
        }
        if (type != null && !type.isBlank()) {
            sql.append(" AND LOWER(f.type) = ?");
            params.add(type.toLowerCase());
        }
        if (sport != null && !sport.isBlank()) {
            sql.append(" AND EXISTS (SELECT 1 FROM courts c2 WHERE c2.facility_id = f.id AND LOWER(c2.sport_type) = LOWER(?))");
            params.add(sport);
        }
        sql.append(" GROUP BY f.id ORDER BY f.name LIMIT 50");

        return ResponseEntity.ok(jdbcTemplate.queryForList(sql.toString(), params.toArray()));
    }

    /** Podaci za početnu stranu: broj objekata, top 3 po lajkovima, 3 aktuelne promocije. */
    @GetMapping("/homepage")
    public ResponseEntity<HomepageResponse> getHomepageData() {
        long totalFacilities = facilityRepository.count();

        String topSql = "SELECT f.id, f.name, f.city, f.address, f.description, f.price_per_hour, f.type, " +
                "COALESCE(SUM(CASE WHEN r.is_like = 1 THEN 1 ELSE 0 END), 0) AS likes " +
                "FROM facilities f " +
                "LEFT JOIN facility_ratings r ON r.facility_id = f.id " +
                "WHERE f.status = 'APPROVED' " +
                "GROUP BY f.id " +
                "ORDER BY likes DESC, f.id ASC " +
                "LIMIT 3";
        List<Map<String, Object>> topFacilities = jdbcTemplate.queryForList(topSql);

        String promoSql = "SELECT p.name AS promotion_name, p.sport_type AS sport_type, " +
                "p.start_date AS start_date, p.end_date AS end_date, p.discount_percent AS discount_percent " +
                "FROM promotions p " +
                "WHERE p.is_active = 1 AND CURDATE() BETWEEN p.start_date AND p.end_date " +
                "ORDER BY p.discount_percent DESC " +
                "LIMIT 3";
        List<Map<String, Object>> promoRows = jdbcTemplate.queryForList(promoSql);

        List<PromotionSummaryResponse> promotions = new ArrayList<>();
        for (Map<String, Object> row : promoRows) {
            promotions.add(new PromotionSummaryResponse(
                    (String) row.get("promotion_name"),
                    (String) row.get("sport_type"),
                    row.get("start_date") != null
                            ? java.sql.Date.valueOf(row.get("start_date").toString()).toLocalDate() : null,
                    row.get("end_date") != null
                            ? java.sql.Date.valueOf(row.get("end_date").toString()).toLocalDate() : null,
                    row.get("discount_percent") != null
                            ? ((Number) row.get("discount_percent")).intValue() : null));
        }

        return ResponseEntity.ok(new HomepageResponse(totalFacilities, topFacilities, promotions));
    }

    /** Detalji objekta — objekat, tereni, broj lajkova/dislajkova i galerija slika. */
    @GetMapping("/facilities/{facilityId}")
    public ResponseEntity<FacilityDetailsResponse> getFacilityDetails(@PathVariable Long facilityId) {
        Facility facility = facilityRepository.findByIdAndStatus(facilityId, "APPROVED")
                .orElse(null);
        if (facility == null) {
            return ResponseEntity.notFound().build();
        }

        List<Court> courts = courtRepository.findAllByFacilityId(facilityId);

        RatingSummaryResponse ratingSummary = facilityRatingService.getPublicSummary(facilityId);
        long likes = ratingSummary.getLikes();
        long dislikes = ratingSummary.getDislikes();

        List<String> galleryImages = facilityImageRepository.findPathsByFacilityId(facilityId);

        return ResponseEntity.ok(new FacilityDetailsResponse(facility, courts, likes, dislikes, galleryImages));
    }

    /** Javni sažetak ocena za objekat (lajkovi, dislajkovi, komentari). */
    @GetMapping("/facilities/{facilityId}/ratings")
    public ResponseEntity<RatingSummaryResponse> getFacilityRatings(@PathVariable Long facilityId) {
        return ResponseEntity.ok(facilityRatingService.getPublicSummary(facilityId));
    }

    /** Lista gradova sa APPROVED objektima — za padajući meni u pretrazi. */
    @GetMapping("/cities")
    public ResponseEntity<List<String>> getCities() {
        String sql = "SELECT DISTINCT city FROM facilities WHERE status = 'APPROVED' ORDER BY city";
        return ResponseEntity.ok(jdbcTemplate.queryForList(sql, String.class));
    }
}
