package com.example.backend.repos;

import com.example.backend.models.FacilityEmployee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Veze između zaposlenih i objekata (M:N). Servisi koriste nasleđeni
 * {@code save()} i {@code delete()} direktno.
 */
@Repository
public interface FacilityEmployeeRepository extends JpaRepository<FacilityEmployee, Long> {
}
