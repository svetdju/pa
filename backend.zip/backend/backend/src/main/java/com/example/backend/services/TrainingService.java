package com.example.backend.services;

import com.example.backend.dtos.TrainingRequest;
import com.example.backend.dtos.TrainingResponse;
import com.example.backend.models.Coach;
import com.example.backend.models.Training;
import com.example.backend.models.User;
import com.example.backend.repos.CoachRepository;
import com.example.backend.repos.CourtRepository;
import com.example.backend.repos.TrainingRepository;
import com.example.backend.repos.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Individualni treninzi — pregled trenera, zakazivanje i arhiva.
 *
 * <p>Biznis pravila:</p>
 * <ul>
 *   <li>Trener i teren moraju biti u APPROVED objektu.</li>
 *   <li>Trener ne sme biti zauzet u istom terminu drugim treningom.</li>
 *   <li>Vreme sa frontenda može doći u formatu {@code HH:mm} ili {@code HH:mm:ss}
 *       — normalizuje se na {@code HH:mm:ss}.</li>
 * </ul>
 */
@Service
public class TrainingService {

    private final TrainingRepository trainingRepository;
    private final CoachRepository coachRepository;
    private final CourtRepository courtRepository;
    private final UserRepository userRepository;

    public TrainingService(TrainingRepository trainingRepository,
                           CoachRepository coachRepository,
                           CourtRepository courtRepository,
                           UserRepository userRepository) {
        this.trainingRepository = trainingRepository;
        this.coachRepository = coachRepository;
        this.courtRepository = courtRepository;
        this.userRepository = userRepository;
    }

    /** Aktivni treneri za dati objekat i sport. */
    public List<Coach> getCoachesByFacilityAndSport(Long facilityId, String sport) {
        return coachRepository.findCoachesByFacilityAndSport(facilityId, sport);
    }

    /** Svi aktivni treneri u objektu (svi sportovi). */
    public List<Coach> getAllCoachesByFacility(Long facilityId) {
        return coachRepository.findAllActiveByFacility(facilityId);
    }

    /**
     * Zakazuje individualni trening sa statusom SCHEDULED. Validira da su i
     * trener i teren u APPROVED objektu i da trener nije zauzet.
     */
    public void scheduleTraining(TrainingRequest dto, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        if (!coachRepository.isCoachInApprovedFacility(dto.getCoach_id())) {
            throw new RuntimeException(
                    "Individualni trening može se zakazati samo za trenera u odobrenom objektu.");
        }
        if (!courtRepository.isCourtInApprovedFacility(dto.getCourt_id())) {
            throw new RuntimeException(
                    "Individualni trening može se zakazati samo na terenu u odobrenom objektu.");
        }

        if (trainingRepository.existsOverlappingTraining(
                dto.getCoach_id(), dto.getTraining_date(), dto.getStart_time(), dto.getEnd_time())) {
            throw new RuntimeException("Izabrani trener je već zauzet u tom terminu.");
        }

        Training training = new Training();
        training.setUserId(user.getId());
        training.setCoachId(dto.getCoach_id());
        training.setCourtId(dto.getCourt_id());
        training.setTrainingDate(dto.getTraining_date());
        training.setStartTime(normalizeTime(dto.getStart_time()));
        training.setEndTime(normalizeTime(dto.getEnd_time()));
        training.setStatus("SCHEDULED");

        trainingRepository.save(training);
    }

    /** Arhiva održanih i zakazanih treninga korisnika. */
    public List<TrainingResponse> getMyTrainings(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));
        return trainingRepository.findAllTrainingsByUserId(user.getId());
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    /**
     * Normalizuje vreme iz {@code HH:mm} u {@code HH:mm:ss} format (dodaje sekunde).
     * Ako je već u punom formatu, vraća ga nepromenjenog.
     */
    private String normalizeTime(String time) {
        if (time == null) return null;
        return time.length() == 5 ? time + ":00" : time;
    }
}
