package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Korisnički nalog (sportista, zaposleni ili administrator).
 *
 * <p>Lozinka se čuva kao BCrypt heš u koloni {@code password_hash}.
 * Polja su u Java camelCase konvenciji, a {@code @Column(name = "...")}
 * anotacije održavaju mapiranje na postojeće snake_case kolone u MySQL bazi.</p>
 *
 * <p>Dozvoljene vrednosti:</p>
 * <ul>
 *   <li>{@code role}:   ATHLETE | EMPLOYEE | ADMIN</li>
 *   <li>{@code status}: PENDING | APPROVED | REJECTED</li>
 * </ul>
 */
@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(name = "uq_users_username", columnNames = "username"),
        @UniqueConstraint(name = "uq_users_email", columnNames = "email")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username", nullable = false, length = 50, unique = true)
    private String username;

    @Column(name = "password_hash", nullable = false, length = 255)
    private String passwordHash;

    @Column(name = "email", nullable = false, length = 100, unique = true)
    private String email;

    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;

    @Column(name = "phone", nullable = false, length = 30)
    private String phone;

    @Column(name = "role", nullable = false, length = 20)
    private String role;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    @Column(name = "profile_picture_path", length = 255)
    private String profilePicturePath;

    @Column(name = "favorite_sports", length = 255)
    private String favoriteSports;
}
