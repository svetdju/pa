package com.example.backend.services;

import com.example.backend.dtos.FacilityRequest;
import com.example.backend.dtos.FacilityRequest.CourtRequest;
import com.example.backend.models.Court;
import com.example.backend.models.Facility;
import com.example.backend.models.FacilityEmployee;
import com.example.backend.repos.CourtRepository;
import com.example.backend.repos.FacilityEmployeeRepository;
import com.example.backend.repos.FacilityRepository;
import com.example.backend.repos.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Kreiranje sportskih objekata i dodavanje terena u postojeće objekte.
 *
 * <p>Biznis pravila:</p>
 * <ul>
 *   <li>Novi objekat mora imati barem jedan otvoreni teren ({@code OPENED}) sa kapacitetom N ≥ 4.</li>
 *   <li>Status novog objekta je uvek {@code PENDING} — čeka admin odobrenje.</li>
 *   <li>Naziv terena je jedinstven po objektu; opis opreme ≤ 300 karaktera.</li>
 *   <li> samo zaposleni dodeljen datom objektu sme da mu dodaje terene.</li>
 * </ul>
 */
@Service
public class FacilityService {

    private final FacilityRepository facilityRepository;
    private final CourtRepository courtRepository;
    private final UserRepository userRepository;
    private final FacilityEmployeeRepository facilityEmployeeRepository;

    public FacilityService(FacilityRepository facilityRepository,
                           CourtRepository courtRepository,
                           UserRepository userRepository,
                           FacilityEmployeeRepository facilityEmployeeRepository) {
        this.facilityRepository = facilityRepository;
        this.courtRepository = courtRepository;
        this.userRepository = userRepository;
        this.facilityEmployeeRepository = facilityEmployeeRepository;
    }

    /**
     * Kreira novi sportski objekat (sa pripadajućim terenima) i vezuje ga za
     * zaposlenog koji ga je kreirao. Objekat dobija status {@code PENDING}.
     */
    @Transactional
    public void createFacilityWithCourts(FacilityRequest request, Long employeeId) {

        // 1. Validacija: barem jedan otvoreni teren sa N >= 4
        if (!hasValidOpenCourt(request)) {
            throw new IllegalArgumentException(
                    "Objekat mora imati najmanje jedan otvoreni teren sa kapacitetom od 4 ili više mesta (N >= 4).");
        }

        // 2. Snimanje osnovnog objekta — JPA save() vraća entitet sa generisanim ID-jem
        Facility facility = buildFacilityFromRequest(request, employeeId);
        Facility saved = facilityRepository.save(facility);
        Long facilityId = saved.getId();

        // 3. Snimanje svih terena
        for (CourtRequest cr : request.getCourts()) {
            Court court = buildCourtFromRequest(facilityId, cr);
            courtRepository.save(court);
        }

        // 4. Vezivanje zaposlenog za objekat u spojnoj tabeli
        FacilityEmployee link = new FacilityEmployee();
        link.setFacilityId(facilityId);
        link.setUserId(employeeId);
        facilityEmployeeRepository.save(link);
    }

    /**
     * Dodaje jedan teren u postojeći objekat. Zaposleni mora biti već dodeljen
     * tom objektu.
     */
    @Transactional
    public void addCourtToExistingFacility(Long facilityId, CourtRequest request, Long employeeId)
            throws IllegalAccessException {

        if (!userRepository.isEmployeeAssignedToFacility(facilityId, employeeId)) {
            throw new IllegalAccessException("Nemate ovlašćenje da dodajete terene u ovaj objekat.");
        }

        if (request.getEquipment_description() != null
                && request.getEquipment_description().length() > 300) {
            throw new IllegalArgumentException("Opis opreme ne sme prelaziti 300 karaktera.");
        }

        if (courtRepository.existsByFacilityIdAndCourtName(facilityId, request.getCourt_name())) {
            throw new IllegalArgumentException(
                    "Teren sa nazivom '" + request.getCourt_name() + "' već postoji u ovom objektu.");
        }

        Court court = buildCourtFromRequest(facilityId, request);
        courtRepository.save(court);
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private boolean hasValidOpenCourt(FacilityRequest request) {
        if (request.getCourts() == null) {
            return false;
        }
        for (CourtRequest cr : request.getCourts()) {
            if ("OPENED".equalsIgnoreCase(cr.getType()) && cr.getCapacity() >= 4) {
                return true;
            }
        }
        return false;
    }

    private Facility buildFacilityFromRequest(FacilityRequest request, Long employeeId) {
        Facility facility = new Facility();
        facility.setName(request.getName());
        facility.setCity(request.getCity());
        facility.setAddress(request.getAddress());
        facility.setDescription(request.getDescription());
        facility.setPricePerHour(request.getPrice_per_hour());
        facility.setType(request.getType());
        facility.setStatus("PENDING");
        facility.setCreatedBy(employeeId);
        facility.setCompanyName(request.getCompany_name());
        facility.setCompanyAddress(request.getCompany_address());
        facility.setCompanyIdNumber(request.getCompany_id_number());
        facility.setPib(request.getPib());
        facility.setWorkStartTime(request.getWork_start_time());
        facility.setWorkEndTime(request.getWork_end_time());
        facility.setMaxNoShows(request.getMax_no_shows() != null ? request.getMax_no_shows() : 3);
        return facility;
    }

    private Court buildCourtFromRequest(Long facilityId, CourtRequest cr) {
        Court court = new Court();
        court.setFacilityId(facilityId);
        court.setCourtName(cr.getCourt_name());
        court.setSportType(cr.getSport_type());
        court.setType(cr.getType());
        court.setCapacity(cr.getCapacity());
        court.setEquipmentDescription(cr.getEquipment_description());
        return court;
    }
}
