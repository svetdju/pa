package com.example.backend.repos;

import com.example.backend.models.FacilityImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FacilityImageRepository extends JpaRepository<FacilityImage, Long> {

    List<FacilityImage> findAllByFacilityIdOrderById(Long facilityId);

    /** Vraća samo putanje slika galerije objekta. */
    default List<String> findPathsByFacilityId(Long facilityId) {
        return findAllByFacilityIdOrderById(facilityId).stream()
                .map(FacilityImage::getImagePath)
                .toList();
    }
}
