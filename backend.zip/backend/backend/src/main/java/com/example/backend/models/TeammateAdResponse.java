package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Prijava sportiste na neki {@link TeammateAd}. Status prijave:
 * {@code PENDING} | {@code APPROVED} | {@code REJECTED}.
 */
@Entity
@Table(name = "teammate_ad_responses")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeammateAdResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ad_id", nullable = false)
    private Long adId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "status", nullable = false, length = 20)
    private String status;
}
