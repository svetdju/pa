package com.example.backend.services;

import com.example.backend.models.Promotion;
import com.example.backend.repos.PromotionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * CRUD nad promocijama (kreiranje, ažuriranje, brisanje).
 * Validira popust (1-100) i datume (kraj ne sme biti pre početka).
 */
@Service
public class PromotionService {

    private final PromotionRepository promotionRepository;

    public PromotionService(PromotionRepository promotionRepository) {
        this.promotionRepository = promotionRepository;
    }

    public List<Promotion> getAllPromotions() {
        return promotionRepository.findAll();
    }

    @Transactional
    public void createPromotion(Promotion p) {
        validatePromotionFields(p, true);
        promotionRepository.save(p);
    }

    @Transactional
    public void updatePromotion(Long id, Promotion p) {
        validatePromotionFields(p, false);

        Promotion existing = promotionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Promocija sa ID-jem " + id + " ne postoji."));

        if (p.getName() != null) existing.setName(p.getName());
        if (p.getDiscountPercent() != null) existing.setDiscountPercent(p.getDiscountPercent());
        if (p.getSportType() != null) existing.setSportType(p.getSportType());
        if (p.getStartDate() != null) existing.setStartDate(p.getStartDate());
        if (p.getEndDate() != null) existing.setEndDate(p.getEndDate());
        if (p.getIsActive() != null) existing.setIsActive(p.getIsActive());

        promotionRepository.save(existing);
    }

    @Transactional
    public void deletePromotion(Long id) {
        promotionRepository.deleteById(id);
    }

    private void validatePromotionFields(Promotion p, boolean isCreate) {
        if (isCreate) {
            if (p.getName() == null || p.getName().isBlank()) {
                throw new RuntimeException("Naziv promocije je obavezan.");
            }
            if (p.getDiscountPercent() == null || p.getDiscountPercent() < 1 || p.getDiscountPercent() > 100) {
                throw new RuntimeException("Popust mora biti između 1 i 100.");
            }
            if (p.getStartDate() == null || p.getEndDate() == null) {
                throw new RuntimeException("Datum početka i kraja su obavezni.");
            }
            if (p.getEndDate().isBefore(p.getStartDate())) {
                throw new RuntimeException("Datum kraja ne može biti pre datuma početka.");
            }
        } else {
            if (p.getDiscountPercent() != null
                    && (p.getDiscountPercent() < 1 || p.getDiscountPercent() > 100)) {
                throw new RuntimeException("Popust mora biti između 1 i 100.");
            }
            if (p.getStartDate() != null && p.getEndDate() != null
                    && p.getEndDate().isBefore(p.getStartDate())) {
                throw new RuntimeException("Datum kraja ne može biti pre datuma početka.");
            }
        }
    }
}
