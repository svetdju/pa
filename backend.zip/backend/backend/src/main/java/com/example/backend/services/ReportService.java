package com.example.backend.services;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;

/**
 * Generisanje PDF izveštaja za zaposlene. Dva tipa izveštaja:
 * <ol>
 *   <li>Popunjenost terena po objektu za izabrani mesec</li>
 *   <li>Promet opreme po artikalima za izabrani mesec</li>
 * </ol>
 *
 * <p>Koristi {@link JdbcTemplate} zbog MySQL-ove {@code DATE_FORMAT} funkcije.</p>
 */
@Service
public class ReportService {

    private static final Color HEADER_BG = new Color(37, 99, 235);
    private static final Font TITLE_FONT     = new Font(Font.HELVETICA, 18, Font.BOLD);
    private static final Font SUBTITLE_FONT  = new Font(Font.HELVETICA, 12, Font.NORMAL);
    private static final Font HEADER_FONT    = new Font(Font.HELVETICA, 10, Font.BOLD, Color.WHITE);
    private static final Font SECTION_FONT   = new Font(Font.HELVETICA, 14, Font.BOLD);
    private static final Font DATA_FONT      = new Font(Font.HELVETICA, 10, Font.NORMAL);
    private static final Font TOTAL_FONT     = new Font(Font.HELVETICA, 14, Font.BOLD);

    private final JdbcTemplate jdbcTemplate;

    public ReportService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * PDF izveštaj o popunjenosti terena za izabrani mesec (format {@code yyyy-MM}).
     * Za svaki objekat zaposlenog prikazuje tabelu sa terenima i brojem rezervacija.
     */
    public byte[] generateCourtUsageReport(String month, String employeeUsername) {
        List<Map<String, Object>> facilities = getEmployeeFacilities(employeeUsername);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4, 36, 36, 54, 36);

        try {
            PdfWriter.getInstance(document, baos);
            document.open();

            addTitle(document, "Izveštaj o popunjenosti terena", "Mesec: " + month);

            for (Map<String, Object> facility : facilities) {
                Long facilityId = ((Number) facility.get("id")).longValue();
                String facilityName = (String) facility.get("name");

                document.add(new Paragraph(facilityName, SECTION_FONT));
                document.add(Chunk.NEWLINE);

                List<Map<String, Object>> courts = fetchCourtUsageForFacility(facilityId, month);
                PdfPTable table = buildCourtUsageTable(courts);
                document.add(table);
            }

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("Greška pri generisanju PDF-a: " + e.getMessage());
        }

        return baos.toByteArray();
    }

    /**
     * PDF izveštaj o prometu opreme za izabrani mesec. Prikazuje ukupan promet
     * i tabelu sa prodatim artiklima sortiranim po prihodima opadajuće.
     */
    public byte[] generateEquipmentSalesReport(String month, String employeeUsername) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4, 36, 36, 54, 36);

        try {
            PdfWriter.getInstance(document, baos);
            document.open();

            addTitle(document, "Izveštaj o prometu opreme", "Mesec: " + month);

            double total = fetchTotalRevenueForMonth(month);
            document.add(new Paragraph(
                    "Ukupan promet: " + String.format("%.2f", total) + " RSD", TOTAL_FONT));
            document.add(Chunk.NEWLINE);

            List<Map<String, Object>> items = fetchEquipmentSalesForMonth(month);
            PdfPTable table = buildEquipmentSalesTable(items);
            document.add(table);

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("Greška pri generisanju PDF-a: " + e.getMessage());
        }

        return baos.toByteArray();
    }

    // ========================================================================
    // Privatni helper-i — SQL upiti
    // ========================================================================

    private List<Map<String, Object>> getEmployeeFacilities(String username) {
        String sql = "SELECT f.id, f.name FROM facilities f " +
                "JOIN facility_employees fe ON f.id = fe.facility_id " +
                "JOIN users u ON fe.user_id = u.id " +
                "WHERE u.username = ?";
        return jdbcTemplate.queryForList(sql, username);
    }

    private List<Map<String, Object>> fetchCourtUsageForFacility(Long facilityId, String month) {
        String sql = "SELECT c.court_name, c.sport_type, c.type, " +
                "COUNT(r.id) AS reservation_count, " +
                "SUM(CASE WHEN r.status IN ('CONFIRMED','COMPLETED') THEN 1 ELSE 0 END) AS confirmed_count " +
                "FROM courts c " +
                "LEFT JOIN reservations r ON c.id = r.court_id " +
                "AND DATE_FORMAT(r.reservation_date, '%Y-%m') = ? " +
                "WHERE c.facility_id = ? " +
                "GROUP BY c.id, c.court_name, c.sport_type, c.type " +
                "ORDER BY c.court_name";
        return jdbcTemplate.queryForList(sql, month, facilityId);
    }

    private double fetchTotalRevenueForMonth(String month) {
        String sql = "SELECT COALESCE(SUM(o.total_price), 0) AS total " +
                "FROM orders o WHERE DATE_FORMAT(o.order_date, '%Y-%m') = ? AND o.status != 'CANCELLED'";
        Double total = jdbcTemplate.queryForObject(sql, Double.class, month);
        return total == null ? 0.0 : total;
    }

    private List<Map<String, Object>> fetchEquipmentSalesForMonth(String month) {
        String sql = "SELECT e.name AS equipment_name, e.sport_type, " +
                "SUM(oi.quantity) AS total_sold, " +
                "SUM(oi.final_price) AS total_revenue " +
                "FROM order_items oi " +
                "JOIN orders o ON oi.order_id = o.id " +
                "JOIN equipment e ON oi.equipment_id = e.id " +
                "WHERE DATE_FORMAT(o.order_date, '%Y-%m') = ? AND o.status != 'CANCELLED' " +
                "GROUP BY e.id, e.name, e.sport_type " +
                "ORDER BY total_revenue DESC";
        return jdbcTemplate.queryForList(sql, month);
    }

    // ========================================================================
    // Privatni helper-i — PDF konstrukcija
    // ========================================================================

    private void addTitle(Document document, String title, String subtitle) throws Exception {
        Paragraph p = new Paragraph(title, TITLE_FONT);
        p.setAlignment(Element.ALIGN_CENTER);
        p.setSpacingAfter(10);
        document.add(p);

        Paragraph s = new Paragraph(subtitle, SUBTITLE_FONT);
        s.setAlignment(Element.ALIGN_CENTER);
        s.setSpacingAfter(20);
        document.add(s);
    }

    private PdfPTable buildCourtUsageTable(List<Map<String, Object>> courts) {
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(5);
        table.setSpacingAfter(20);
        try {
            table.setWidths(new float[]{3, 2, 1.5f, 2, 2});
        } catch (Exception ignored) { /* širine su opciono */ }

        String[] headers = {"Teren", "Sport", "Tip", "Rezervacije", "Potvrđene"};
        for (String h : headers) {
            table.addCell(makeHeaderCell(h));
        }
        for (Map<String, Object> court : courts) {
            table.addCell(new Phrase(String.valueOf(court.get("court_name")), DATA_FONT));
            table.addCell(new Phrase(String.valueOf(court.get("sport_type")), DATA_FONT));
            table.addCell(new Phrase(String.valueOf(court.get("type")), DATA_FONT));
            table.addCell(new Phrase(String.valueOf(court.get("reservation_count")), DATA_FONT));
            table.addCell(new Phrase(String.valueOf(court.get("confirmed_count")), DATA_FONT));
        }
        return table;
    }

    private PdfPTable buildEquipmentSalesTable(List<Map<String, Object>> items) {
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        try {
            table.setWidths(new float[]{3, 2, 1.5f, 2});
        } catch (Exception ignored) { /* širine su opciono */ }

        String[] headers = {"Oprema", "Sport", "Prodato komada", "Ukupan prihod"};
        for (String h : headers) {
            table.addCell(makeHeaderCell(h));
        }

        if (items.isEmpty()) {
            PdfPCell empty = new PdfPCell(new Phrase("Nema podataka za izabrani mesec.", DATA_FONT));
            empty.setColspan(4);
            empty.setPadding(8);
            table.addCell(empty);
        } else {
            for (Map<String, Object> item : items) {
                table.addCell(new Phrase(String.valueOf(item.get("equipment_name")), DATA_FONT));
                table.addCell(new Phrase(String.valueOf(item.get("sport_type")), DATA_FONT));
                table.addCell(new Phrase(String.valueOf(item.get("total_sold")), DATA_FONT));
                double revenue = ((Number) item.get("total_revenue")).doubleValue();
                table.addCell(new Phrase(String.format("%.2f", revenue) + " RSD", DATA_FONT));
            }
        }
        return table;
    }

    private PdfPCell makeHeaderCell(String text) {
        PdfPCell cell = new PdfPCell(new Phrase(text, HEADER_FONT));
        cell.setBackgroundColor(HEADER_BG);
        cell.setPadding(6);
        return cell;
    }
}
