package com.example.backend.services;

import com.example.backend.dtos.AuthResponse;
import com.example.backend.dtos.EmployeeProfileResponse;
import com.example.backend.dtos.LoginRequest;
import com.example.backend.dtos.RegisterRequest;
import com.example.backend.models.FacilityEmployee;
import com.example.backend.models.User;
import com.example.backend.repos.FacilityEmployeeRepository;
import com.example.backend.repos.UserRepository;
import com.example.backend.security.JwtUtil;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;

/**
 * Registracija, login i ažuriranje korisničkog profila.
 *
 * <p>Biznis pravila:</p>
 * <ul>
 *   <li>Korisničko ime i email moraju biti jedinstveni.</li>
 *   <li>Novi nalozi dobijaju status {@code PENDING} — samo APPROVED može da se uloguje.</li>
 *   <li>Za registraciju zaposlenog: objekat se mora pronaći po 4 parametra
 *       (name, company_id_number, pib, company_address); maksimalno 2 zaposlena po objektu.</li>
 *   <li>Profilne slike se snimaju u {@code uploads/profiles/} sa UUID sufiksom.</li>
 * </ul>
 */
@Service
public class UserService {

    private static final String UPLOAD_DIR = "uploads/profiles/";

    private final UserRepository userRepository;
    private final FacilityEmployeeRepository facilityEmployeeRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public UserService(UserRepository userRepository,
                       FacilityEmployeeRepository facilityEmployeeRepository,
                       PasswordEncoder passwordEncoder,
                       JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.facilityEmployeeRepository = facilityEmployeeRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Registracija novog korisnika (sportista ili zaposleni). Lozinka se
     * BCrypt-uje, profilna slika se snima na disk, a za zaposlenog se kreira
     * veza sa objektom u spojnoj tabeli {@code facility_employees}.
     */
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        // 1. Provera jedinstvenosti korisničkog imena
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new RuntimeException("Korisničko ime '" + request.getUsername() + "' je već zauzeto.");
        }

        // 2. Pre-validacija za zaposlenog: objekat mora postojati i imati < 2 zaposlena
        Long targetFacilityId = null;
        if ("EMPLOYEE".equals(request.getRole())) {
            targetFacilityId = resolveFacilityForEmployee(request);
        }

        // 3. Mapiranje DTO -> Entity
        User user = mapRequestToUser(request);

        // 4. Snimanje profilne slike (ako je priložena)
        MultipartFile file = request.getProfile_image();
        if (file != null && !file.isEmpty()) {
            user.setProfilePicturePath(saveProfilePicture(request.getUsername(), file));
        }

        // 5. Heširanje lozinke i persist
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        User savedUser = userRepository.save(user);

        // 6. Ako je zaposleni, vežemo ga za objekat
        if ("EMPLOYEE".equals(request.getRole()) && targetFacilityId != null) {
            FacilityEmployee link = new FacilityEmployee();
            link.setFacilityId(targetFacilityId);
            link.setUserId(savedUser.getId());
            facilityEmployeeRepository.save(link);
        }

        // 7. Generisanje JWT-a i vraćanje odgovora
        String token = jwtUtil.generateToken(savedUser.getUsername(), savedUser.getRole());
        return new AuthResponse(token, savedUser.getUsername(), savedUser.getRole(), savedUser.getStatus());
    }

    /** Vraća profil zaposlenog sa listom objekata u kojima radi. */
    public EmployeeProfileResponse getEmployeeProfileData(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Zaposleni nije pronađen."));

        List<EmployeeProfileResponse.EmployeeFacilityDTO> myFacilities =
                userRepository.findFacilitiesByUserId(user.getId());

        String picturePath = user.getProfilePicturePath() != null ? user.getProfilePicturePath() : "";
        return new EmployeeProfileResponse(
                user.getUsername(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                user.getPhone(),
                user.getRole(),
                user.getStatus(),
                picturePath,
                myFacilities);
    }

    /** Login sa proverom lozinke i statusa naloga. */
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new BadCredentialsException("Neispravno korisničko ime ili lozinka."));

        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            throw new BadCredentialsException("Neispravno korisničko ime ili lozinka.");
        }

        if (!"APPROVED".equalsIgnoreCase(user.getStatus())) {
            throw new BadCredentialsException("Korisnički nalog nije odobren.");
        }

        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());
        return new AuthResponse(token, user.getUsername(), user.getRole(), user.getStatus());
    }

    /**
     * Ažurira lične podatke korisnika. Prazna/null polja se zadržavaju na
     * postojećim vrednostima.
     */
    @Transactional
    public void updateProfileDetails(String username, String firstName, String lastName,
                                     String phone, String email) {
        User current = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        String updatedFirstName = pickIfNotBlank(firstName, current.getFirstName());
        String updatedLastName  = pickIfNotBlank(lastName,  current.getLastName());
        String updatedPhone     = pickIfNotBlank(phone,     current.getPhone());
        String updatedEmail     = pickIfNotBlank(email,     current.getEmail());

        userRepository.updateProfile(username, updatedFirstName, updatedLastName, updatedPhone, updatedEmail);
    }

    @Transactional
    public void updateSports(String username, String favoriteSports) {
        userRepository.updateFavoriteSports(username, favoriteSports);
    }

    /** Snima novu profilnu sliku i vraća njenu javnu putanju. */
    @Transactional
    public String updateImage(String username, MultipartFile file) {
        if (file.isEmpty()) {
            throw new RuntimeException("Fajl je prazan!");
        }
        try {
            String imagePath = saveProfilePicture(username, file);
            userRepository.updateProfileImage(username, imagePath);
            return imagePath;
        } catch (Exception e) {
            throw new RuntimeException("Greška pri čuvanju slike na serveru: " + e.getMessage());
        }
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private Long resolveFacilityForEmployee(RegisterRequest request) {
        Long facilityId = userRepository.findFacilityIdByDetails(
                request.getFacility_name(),
                request.getCompany_id_number(),
                request.getPib(),
                request.getCompany_address());

        if (facilityId == null) {
            throw new RuntimeException(
                    "Registracija odbijena: Sportski objekat sa unetim podacima nije pronađen u sistemu.");
        }

        int employeeCount = userRepository.countEmployeesForFacility(facilityId);
        if (employeeCount >= 2) {
            throw new RuntimeException(
                    "Registracija odbijena: Ovaj objekat već ima maksimalan broj zaposlenih (2).");
        }
        return facilityId;
    }

    private User mapRequestToUser(RegisterRequest request) {
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setFirstName(request.getFirst_name());
        user.setLastName(request.getLast_name());
        user.setPhone(request.getPhone());
        user.setRole(request.getRole());
        // Sportiste imaju favorite_sports; zaposleni i admini ne
        user.setFavoriteSports("ATHLETE".equals(request.getRole()) ? request.getFavorite_sports() : null);
        user.setStatus("PENDING");
        return user;
    }

    private String saveProfilePicture(String username, MultipartFile file) {
        try {
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            String original = file.getOriginalFilename();
            String extension = (original != null && original.contains("."))
                    ? original.substring(original.lastIndexOf("."))
                    : ".jpg";

            String uniqueName = "profile_" + username + "_"
                    + UUID.randomUUID().toString().substring(0, 8) + extension;
            Path target = Paths.get(UPLOAD_DIR + uniqueName);

            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return "/uploads/profiles/" + uniqueName;
        } catch (Exception e) {
            throw new RuntimeException("Greška pri čuvanju profilne slike: " + e.getMessage());
        }
    }

    private static String pickIfNotBlank(String newValue, String fallback) {
        return (newValue != null && !newValue.trim().isEmpty()) ? newValue : fallback;
    }
}
