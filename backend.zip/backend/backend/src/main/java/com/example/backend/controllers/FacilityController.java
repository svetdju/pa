package com.example.backend.controllers;

import com.example.backend.dtos.FacilityRequest;
import com.example.backend.dtos.FacilityRequest.CourtRequest;
import com.example.backend.dtos.EmployeeProfileResponse;
import com.example.backend.models.User;
import com.example.backend.repos.UserRepository;
import com.example.backend.services.FacilityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.security.Principal;
import java.util.List;

/**
 * Kreiranje sportskih objekata i dodavanje terena u postojeće.
 */
@RestController
@RequestMapping("/api/facilities")
@CrossOrigin(origins = "http://localhost:4200")
public class FacilityController {

    private final FacilityService facilityService;
    private final UserRepository userRepository;
    private final ObjectMapper objectMapper;

    public FacilityController(FacilityService facilityService,
                              UserRepository userRepository,
                              ObjectMapper objectMapper) {
        this.facilityService = facilityService;
        this.userRepository = userRepository;
        this.objectMapper = objectMapper;
    }

    /**
     * Kreira objekat iz JSON fajla (FileUpload). Podaci o firmi se automatski
     * preuzimaju iz prvog postojećeg objekta zaposlenog.
     */
    @PostMapping("/create")
    public ResponseEntity<String> createFacility(@RequestParam("file") MultipartFile file,
                                                 Principal principal) {
        try {
            if (principal == null) {
                return ResponseEntity.status(401).body("Niste autorizovani. Token nedostaje.");
            }
            if (file == null || file.isEmpty()) {
                return ResponseEntity.badRequest().body("Greška: JSON fajl nije prosleđen.");
            }

            FacilityRequest request = objectMapper.readValue(file.getInputStream(), FacilityRequest.class);
            User user = getUserFromPrincipal(principal);

            String companyError = inheritCompanyInfo(request, user.getId());
            if (companyError != null) {
                return ResponseEntity.badRequest().body(companyError);
            }

            facilityService.createFacilityWithCourts(request, user.getId());
            return ResponseEntity.ok("Objekat i tereni su uspešno uvezeni i poslati na odobrenje.");

        } catch (com.fasterxml.jackson.core.JsonProcessingException e) {
            return ResponseEntity.badRequest().body("Greška u formatu JSON fajla. Proverite strukturu.");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Greška pri validaciji: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Sistemska greška pri uvozu: " + e.getMessage());
        }
    }

    /**
     * Kreira objekat iz JSON body-ja (forma). Podaci o firmi se takođe preuzimaju
     * iz prvog postojećeg objekta zaposlenog.
     */
    @PostMapping("/create-form")
    public ResponseEntity<String> createFacilityFromForm(@RequestBody FacilityRequest request,
                                                         Principal principal) {
        try {
            if (principal == null) {
                return ResponseEntity.status(401).body("Niste autorizovani. Token nedostaje.");
            }
            User user = getUserFromPrincipal(principal);

            String companyError = inheritCompanyInfo(request, user.getId());
            if (companyError != null) {
                return ResponseEntity.badRequest().body(companyError);
            }

            facilityService.createFacilityWithCourts(request, user.getId());
            return ResponseEntity.ok("Objekat je uspešno kreiran i poslat na odobrenje administratora.");

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Greška pri validaciji: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Sistemska greška: " + e.getMessage());
        }
    }

    /** Dodaje jedan teren u postojeći objekat. */
    @PostMapping("/{facilityId}/courts")
    public ResponseEntity<String> addCourtToFacility(@PathVariable Long facilityId,
                                                     @RequestBody CourtRequest request,
                                                     Principal principal) {
        try {
            if (principal == null) {
                return ResponseEntity.status(401).body("Niste autorizovani. Token nedostaje.");
            }
            User user = getUserFromPrincipal(principal);
            facilityService.addCourtToExistingFacility(facilityId, request, user.getId());
            return ResponseEntity.ok("Novi teren je uspešno dodat u izabrani objekat.");

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Greška pri validaciji: " + e.getMessage());
        } catch (IllegalAccessException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Sistemska greška: " + e.getMessage());
        }
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private User getUserFromPrincipal(Principal principal) {
        return userRepository.findByUsername(principal.getName())
                .orElseThrow(() -> new RuntimeException("Zaposleni nije pronađen."));
    }

    /**
     * Preuzima podatke o firmi iz prvog postojećeg objekta zaposlenog. Vraća
     * {@code null} ako je uspešno, ili poruku o grešci ako zaposleni nema nijedan objekat.
     */
    private String inheritCompanyInfo(FacilityRequest request, Long employeeId) {
        List<EmployeeProfileResponse.EmployeeFacilityDTO> existing =
                userRepository.findFacilitiesByUserId(employeeId);

        if (existing == null || existing.isEmpty()) {
            return "Greška: Nemate nijedan postojeći objekat iz kojeg se mogu preuzeti podaci o firmi. "
                    + "Podaci o firmi se automatski preuzimaju iz vašeg prvog objekta.";
        }

        EmployeeProfileResponse.EmployeeFacilityDTO source = existing.get(0);
        request.setCompany_name(source.getCompanyName());
        request.setCompany_address(source.getCompanyAddress());
        request.setCompany_id_number(source.getCompanyIdNumber());
        request.setPib(source.getPib());
        return null;
    }
}
