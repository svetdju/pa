package com.example.backend.controllers;

import com.example.backend.dtos.StatisticsResponse;
import com.example.backend.services.StatisticsService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

/**
 * Statistika aktivnosti sportiste — bar chart po sportu, line chart po mesecima,
 * ukupna potrošnja na opremu.
 */
@RestController
@RequestMapping("/api/statistics")
@CrossOrigin(origins = "http://localhost:4200")
public class StatisticsController {

    private final StatisticsService statisticsService;

    public StatisticsController(StatisticsService statisticsService) {
        this.statisticsService = statisticsService;
    }

    @GetMapping("/my")
    public ResponseEntity<StatisticsResponse> getMyStatistics(Principal principal) {
        return ResponseEntity.ok(statisticsService.getMyStatistics(principal.getName()));
    }
}
