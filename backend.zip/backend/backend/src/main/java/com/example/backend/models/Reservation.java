package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Rezervacija termina na nekom {@link Court}-u.
 *
 * <p>Datum i vreme se iz istorijskih razloga čuvaju kao {@code String}
 * (formati {@code yyyy-MM-dd} i {@code HH:mm:ss}). Statusi:</p>
 * <ul>
 *   <li>{@code PENDING}    — rezervacija poslata, čeka potvrdu zaposlenog</li>
 *   <li>{@code CONFIRMED}  — zaposleni potvrdio</li>
 *   <li>{@code COMPLETED}  — korisnik se pojavio, trening/utakmica završena</li>
 *   <li>{@code ABSENT}     — korisnik nije došao (evidentira no-show)</li>
 *   <li>{@code CANCELLED}  — otkazana od strane korisnika ili zaposlenog</li>
 * </ul>
 */
@Entity
@Table(name = "reservations")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "court_id", nullable = false)
    private Long courtId;

    @Column(name = "reservation_date", nullable = false)
    private String reservationDate;

    @Column(name = "start_time", nullable = false)
    private String startTime;

    @Column(name = "end_time", nullable = false)
    private String endTime;

    @Column(name = "status", nullable = false, length = 20)
    private String status;
}
