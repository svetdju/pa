package com.example.backend.repos;

import com.example.backend.dtos.OrderResponse;
import com.example.backend.models.Order;
import com.example.backend.models.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Pristup porudžbinama opreme. {@link #mapOrderRows(List)} je statička pomoćna
 * metoda koja se koristi i iz {@link StaffOrderRepository} jer su im strukture
 * odgovora identične.
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    /**
     * Kreira novu porudžbinu i vraća njen ID. Servis bi mogao koristiti i
     * nasleđeni {@code save(order)} pa čitati {@code order.getId()}, ali ovaj
     * metod je tu zbog kompatibilnosti sa starim API-jem.
     */
    default Long createOrder(Long userId, Double totalPrice) {
        Order order = new Order();
        order.setUserId(userId);
        order.setOrderDate(java.time.LocalDateTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        order.setTotalPrice(totalPrice);
        order.setStatus("ORDERED");
        Order saved = save(order);
        return saved.getId();
    }

    /**
     * Snima stavku porudžbine. U JPA verziji servis bi mogao koristiti i
     * {@link OrderItemRepository#save(Object)}, ali ovaj metod ostaje zbog
     * kompatibilnosti sa starim API-jem.
     */
    @Modifying
    @Query(value = "INSERT INTO order_items (order_id, equipment_id, quantity, unit_price, discount_percent, final_price) " +
                   "VALUES (:orderId, :equipmentId, :quantity, :unitPrice, :discount, :finalPrice)",
           nativeQuery = true)
    void saveOrderItemRaw(@Param("orderId") Long orderId,
                          @Param("equipmentId") Long equipmentId,
                          @Param("quantity") Integer quantity,
                          @Param("unitPrice") double unitPrice,
                          @Param("discount") int discount,
                          @Param("finalPrice") double finalPrice);

    default void saveOrderItem(Long orderId, Long equipmentId, Integer quantity,
                               double unitPrice, int discount, double finalPrice) {
        saveOrderItemRaw(orderId, equipmentId, quantity, unitPrice, discount, finalPrice);
    }

    /** Menja status porudžbine, ali samo ako pripada datom korisniku. */
    @Modifying
    @Query("UPDATE Order o SET o.status = :status WHERE o.id = :orderId AND o.userId = :userId")
    int updateStatus(@Param("orderId") Long orderId,
                     @Param("userId") Long userId,
                     @Param("status") String status);

    /** Status porudžbine po ID-u i korisniku, ili {@code null}. */
    @Query("SELECT o.status FROM Order o WHERE o.id = :orderId AND o.userId = :userId")
    List<String> findStatusByIdAndUserIdRaw(@Param("orderId") Long orderId,
                                            @Param("userId") Long userId);

    default String findStatusByIdAndUserId(Long orderId, Long userId) {
        List<String> s = findStatusByIdAndUserIdRaw(orderId, userId);
        return s.isEmpty() ? null : s.get(0);
    }

    /**
     * Sve porudžbine korisnika sa summary-jem stavki i ukupnom originalnom cenom.
     * Native query jer koristi MySQL GROUP_CONCAT i SUM.
     */
    @Query(value = "SELECT o.id, o.order_date, o.total_price, o.status, " +
                   "GROUP_CONCAT(CONCAT(e.name, ' (x', oi.quantity, ')') SEPARATOR ', ') AS items_summary, " +
                   "SUM(CAST(oi.unit_price AS DECIMAL(10,2)) * oi.quantity) AS total_original_price " +
                   "FROM orders o " +
                   "JOIN order_items oi ON o.id = oi.order_id " +
                   "JOIN equipment e ON oi.equipment_id = e.id " +
                   "WHERE o.user_id = :userId " +
                   "GROUP BY o.id " +
                   "ORDER BY o.order_date DESC",
           nativeQuery = true)
    List<Object[]> findAllByUserIdRaw(@Param("userId") Long userId);

    default List<OrderResponse> findAllByUserId(Long userId) {
        return mapOrderRows(findAllByUserIdRaw(userId));
    }

    /** Mapira raw projection redove u {@link OrderResponse} DTO. */
    static java.util.List<OrderResponse> mapOrderRows(List<Object[]> rows) {
        java.util.List<OrderResponse> result = new java.util.ArrayList<>(rows.size());
        for (Object[] r : rows) {
            OrderResponse o = new OrderResponse();
            o.setId(((Number) r[0]).longValue());
            o.setOrder_date(r[1] != null ? r[1].toString() : null);
            o.setTotal_price(((Number) r[2]).doubleValue());
            o.setStatus((String) r[3]);
            o.setItems_summary((String) r[4]);
            o.setTotal_original_price(r[5] != null ? ((Number) r[5]).doubleValue() : 0.0);
            result.add(o);
        }
        return result;
    }

    /** Sve stavke jedne porudžbine — koristi se pri otkazivanju da se vrate zalihe. */
    @Query("SELECT oi FROM OrderItem oi WHERE oi.orderId = :orderId")
    List<OrderItem> findItemsByOrderId(@Param("orderId") Long orderId);
}
