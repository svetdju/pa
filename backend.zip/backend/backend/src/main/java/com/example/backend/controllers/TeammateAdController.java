package com.example.backend.controllers;

import com.example.backend.dtos.TeammateAdDTOs.AdRequest;
import com.example.backend.dtos.TeammateAdDTOs.AdResponse;
import com.example.backend.dtos.TeammateAdDTOs.AdResponseDetails;
import com.example.backend.services.TeammateAdService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Map;

/**
 * Oglasi "tražim saigrače" — kreiranje, prijava, upravljanje prijavama.
 */
@RestController
@RequestMapping("/api/ads")
@CrossOrigin(origins = "http://localhost:4200")
public class TeammateAdController {

    private final TeammateAdService adService;

    public TeammateAdController(TeammateAdService adService) {
        this.adService = adService;
    }

    /** Kreira novi oglas. */
    @PostMapping
    public ResponseEntity<String> createAd(@RequestBody AdRequest request, Principal principal) {
        adService.createAd(request, principal.getName());
        return ResponseEntity.ok("Oglas je uspešno postavljen!");
    }

    /** Aktivni oglasi koje korisnik nije sam kreirao. */
    @GetMapping("/active")
    public ResponseEntity<List<AdResponse>> getActiveAds(Principal principal) {
        if (principal == null) {
            throw new RuntimeException("Niste autorizovani.");
        }
        return ResponseEntity.ok(adService.getActiveAds(principal.getName()));
    }

    /** Prijavljuje korisnika na oglas. */
    @PostMapping("/{adId}/respond")
    public ResponseEntity<String> respondToAd(@PathVariable Long adId, Principal principal) {
        adService.respondToAd(adId, principal.getName());
        return ResponseEntity.ok("Uspešno ste poslali zahtev za pridruživanje!");
    }

    /** Svi oglasi korisnika sa pripadajućim prijavama. */
    @GetMapping("/my")
    public ResponseEntity<List<AdResponseDetails>> getMyAds(Principal principal) {
        return ResponseEntity.ok(adService.getMyAdsWithResponses(principal.getName()));
    }

    /** Odobrava ili odbija pojedinačnu prijavu. */
    @PutMapping("/responses/{responseId}/status")
    public ResponseEntity<String> handleResponse(@PathVariable Long responseId,
                                                 @RequestParam("status") String status,
                                                 Principal principal) {
        adService.handleResponseStatus(responseId, status, principal.getName());
        return ResponseEntity.ok("Status prijave uspešno ažuriran!");
    }

    /** Ručno zatvaranje oglasa od strane vlasnika. */
    @PutMapping("/{adId}/close")
    public ResponseEntity<String> closeAd(@PathVariable Long adId, Principal principal) {
        adService.closeAdManually(adId, principal.getName());
        return ResponseEntity.ok("Oglas je uspešno zatvoren.");
    }

    /**
     * Lista {@code [ad_id, status]} za sve oglase na koje se korisnik prijavio.
     * Frontend koristi ovo da sakrije "Prijavi se" dugme.
     */
    @GetMapping("/my-responses")
    public ResponseEntity<List<Map<String, Object>>> getMyResponses(Principal principal) {
        return ResponseEntity.ok(adService.getMyResponses(principal.getName()));
    }
}
