package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Teren, hala ili dvorana unutar nekog {@link Facility} objekta.
 *
 * <p>Kolona {@code type} razlikuje otvoreni teren ({@code OPENED}) od zatvorene
 * hale/dvorane ({@code CLOSED}). Naziv terena je jedinstven u okviru jednog
 * objekta — postavljena je složena jedinstvena ograda (facility_id + court_name).</p>
 */
@Entity
@Table(name = "courts", uniqueConstraints = {
        @UniqueConstraint(name = "uq_court_per_facility", columnNames = {"facility_id", "court_name"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Court {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "facility_id", nullable = false)
    private Long facilityId;

    @Column(name = "court_name", nullable = false, length = 50)
    private String courtName;

    @Column(name = "sport_type", nullable = false, length = 50)
    private String sportType;

    @Column(name = "capacity", nullable = false)
    private int capacity;

    @Column(name = "equipment_description", length = 300)
    private String equipmentDescription;

    @Column(name = "type", nullable = false, length = 20)
    private String type;
}
