package com.example.backend.repos;

import com.example.backend.dtos.TeammateAdDTOs.AdResponse;
import com.example.backend.dtos.TeammateAdDTOs.TeammateResponseDTO;
import com.example.backend.models.TeammateAd;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Pristup oglasima "tražim saigrače". Složeniji JOIN-upiti su native jer
 * vraćaju DTO projection sa podacima iz više tabela.
 */
@Repository
public interface TeammateAdRepository extends JpaRepository<TeammateAd, Long> {

    /** Snima novi oglas (status OPEN). */
    default void saveAd(Long creatorId, String sport, String city, String date, String time, int players) {
        TeammateAd ad = new TeammateAd();
        ad.setCreatorId(creatorId);
        ad.setSport(sport);
        ad.setCity(city);
        ad.setEventDate(date);
        ad.setEventTime(time);
        ad.setPlayersNeeded(players);
        ad.setStatus("OPEN");
        save(ad);
    }

    /** Aktivni (OPEN) oglasi koje nije kreirao dati korisnik. */
    @Query(value = "SELECT a.id, u.username AS creator_username, a.sport, a.city, " +
                   "a.event_date, a.event_time, a.players_needed, a.status " +
                   "FROM teammate_ads a JOIN users u ON a.creator_id = u.id " +
                   "WHERE a.status = 'OPEN' AND a.creator_id <> :userId " +
                   "ORDER BY a.event_date ASC",
           nativeQuery = true)
    List<Object[]> findActiveAdsExcludingUserRaw(@Param("userId") Long userId);

    default List<AdResponse> findActiveAdsExcludingUser(Long userId) {
        return mapAdResponseRows(findActiveAdsExcludingUserRaw(userId));
    }

    /** Svi oglasi datog korisnika (kreatora). */
    @Query(value = "SELECT a.id, u.username AS creator_username, a.sport, a.city, " +
                   "a.event_date, a.event_time, a.players_needed, a.status " +
                   "FROM teammate_ads a JOIN users u ON a.creator_id = u.id " +
                   "WHERE a.creator_id = :creatorId " +
                   "ORDER BY a.event_date DESC",
           nativeQuery = true)
    List<Object[]> findAdsByCreatorIdRaw(@Param("creatorId") Long creatorId);

    default List<AdResponse> findAdsByCreatorId(Long creatorId) {
        return mapAdResponseRows(findAdsByCreatorIdRaw(creatorId));
    }

    /** Mapira raw redove u {@link AdResponse} DTO. */
    private static List<AdResponse> mapAdResponseRows(List<Object[]> rows) {
        List<AdResponse> result = new java.util.ArrayList<>(rows.size());
        for (Object[] r : rows) {
            AdResponse a = new AdResponse();
            a.setId(((Number) r[0]).longValue());
            a.setCreator_username((String) r[1]);
            a.setSport((String) r[2]);
            a.setCity((String) r[3]);
            a.setEvent_date(r[4] != null ? r[4].toString() : null);
            a.setEvent_time(r[5] != null ? r[5].toString() : null);
            a.setPlayers_needed(((Number) r[6]).intValue());
            a.setStatus((String) r[7]);
            result.add(a);
        }
        return result;
    }

    /** Sve prijave na dati oglas, sa podacima o korisnicima. */
    @Query(value = "SELECT r.id AS response_id, r.status, " +
                   "u.id AS user_id, u.username, u.first_name, u.last_name, u.phone " +
                   "FROM teammate_ad_responses r JOIN users u ON r.user_id = u.id " +
                   "WHERE r.ad_id = :adId",
           nativeQuery = true)
    List<Object[]> findResponsesByAdIdRaw(@Param("adId") Long adId);

    default List<TeammateResponseDTO> findResponsesByAdId(Long adId) {
        List<Object[]> rows = findResponsesByAdIdRaw(adId);
        List<TeammateResponseDTO> result = new java.util.ArrayList<>(rows.size());
        for (Object[] r : rows) {
            TeammateResponseDTO t = new TeammateResponseDTO();
            t.setResponse_id(((Number) r[0]).longValue());
            t.setStatus((String) r[1]);
            t.setUser_id(((Number) r[2]).longValue());
            t.setUsername((String) r[3]);
            t.setFirst_name((String) r[4]);
            t.setLast_name((String) r[5]);
            t.setPhone((String) r[6]);
            result.add(t);
        }
        return result;
    }

    /**
     * Da li je korisnik već poslao prijavu na ovaj oglas?
     *
     * <p>Koristimo CASE WHEN umesto COUNT() > 0 jer Hibernate 6 vraća Long (ne Boolean).</p>
     */
    @Query("SELECT CASE WHEN COUNT(r) > 0 THEN 1 ELSE 0 END FROM TeammateAdResponse r WHERE r.adId = :adId AND r.userId = :userId")
    Integer hasUserAlreadyRespondedRaw(@Param("adId") Long adId, @Param("userId") Long userId);

    default boolean hasUserAlreadyResponded(Long adId, Long userId) {
        Integer r = hasUserAlreadyRespondedRaw(adId, userId);
        return r != null && r == 1;
    }

    /** Menja status prijave. */
    @Modifying
    @Query("UPDATE TeammateAdResponse r SET r.status = :status WHERE r.id = :responseId")
    void updateResponseStatus(@Param("responseId") Long responseId, @Param("status") String status);

    /** Menja status oglasa. */
    @Modifying
    @Query("UPDATE TeammateAd a SET a.status = :status WHERE a.id = :adId")
    void updateAdStatus(@Param("adId") Long adId, @Param("status") String status);

    /** Smanjuje broj potrebnih igrača za 1. */
    @Modifying
    @Query("UPDATE TeammateAd a SET a.playersNeeded = a.playersNeeded - 1 WHERE a.id = :adId")
    void decrementPlayersNeeded(@Param("adId") Long adId);

    /**
     * Info o oglasu na osnovu ID-ja prijave: {@code ad_id}, {@code players_needed},
     * {@code creator_id}. Vraća Map-u zbog kompatibilnosti sa starim API-jem.
     */
    @Query(value = "SELECT a.id AS ad_id, a.players_needed, a.creator_id " +
                   "FROM teammate_ads a JOIN teammate_ad_responses r ON a.id = r.ad_id " +
                   "WHERE r.id = :responseId",
           nativeQuery = true)
    List<java.util.Map<String, Object>> findAdInfoByResponseIdRaw(@Param("responseId") Long responseId);

    default java.util.Map<String, Object> findAdInfoByResponseId(Long responseId) {
        List<java.util.Map<String, Object>> list = findAdInfoByResponseIdRaw(responseId);
        return list.isEmpty() ? null : list.get(0);
    }

    /** Vraća {@code creator_id} i {@code status} oglasa po ID-u. */
    @Query(value = "SELECT creator_id, status FROM teammate_ads WHERE id = :adId", nativeQuery = true)
    List<Object[]> findAdByIdRaw(@Param("adId") Long adId);

    default java.util.Map<String, Object> findAdById(Long adId) {
        List<Object[]> rows = findAdByIdRaw(adId);
        if (rows.isEmpty()) return null;
        Object[] r = rows.get(0);
        java.util.Map<String, Object> m = new java.util.HashMap<>();
        m.put("creator_id", ((Number) r[0]).longValue());
        m.put("status", r[1]);
        return m;
    }

    /**
     * Lista {@code ad_id, status} za sve oglase na koje je korisnik poslao prijavu.
     */
    @Query(value = "SELECT ad_id, status FROM teammate_ad_responses WHERE user_id = :userId",
           nativeQuery = true)
    List<Object[]> findResponsesByUserIdRaw(@Param("userId") Long userId);

    default List<java.util.Map<String, Object>> findResponsesByUserId(Long userId) {
        List<Object[]> rows = findResponsesByUserIdRaw(userId);
        List<java.util.Map<String, Object>> result = new java.util.ArrayList<>(rows.size());
        for (Object[] r : rows) {
            java.util.Map<String, Object> m = new java.util.HashMap<>();
            m.put("ad_id", ((Number) r[0]).longValue());
            m.put("status", r[1]);
            result.add(m);
        }
        return result;
    }
}
