package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Veza između zaposlenog ({@link User} sa role=EMPLOYEE) i {@link Facility}-ja
 * na kom radi. Jedan objekat može imati najviše dva zaposlena (biznis pravilo).
 */
@Entity
@Table(name = "facility_employees", uniqueConstraints = {
        @UniqueConstraint(name = "uq_facility_user", columnNames = {"facility_id", "user_id"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FacilityEmployee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "facility_id", nullable = false)
    private Long facilityId;

    @Column(name = "user_id", nullable = false)
    private Long userId;
}
