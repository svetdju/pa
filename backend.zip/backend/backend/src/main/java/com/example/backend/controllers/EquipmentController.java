package com.example.backend.controllers;

import com.example.backend.services.EmployeeShopService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * CRUD nad katalogom opreme (zaposleni).
 */
@RestController
@RequestMapping("/api/employee/equipment")
@CrossOrigin(origins = "http://localhost:4200")
public class EquipmentController {

    private final EmployeeShopService employeeShopService;

    public EquipmentController(EmployeeShopService employeeShopService) {
        this.employeeShopService = employeeShopService;
    }

    /** Dodavanje nove opreme (multipart: podaci + slika). */
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> addEquipment(@RequestParam("name") String name,
                                               @RequestParam("price") Double price,
                                               @RequestParam("stock") Integer stock,
                                               @RequestParam("sportType") String sportType,
                                               @RequestParam("description") String description,
                                               @RequestParam("file") MultipartFile file) {
        employeeShopService.createNewEquipment(name, price, stock, sportType, description, file);
        return ResponseEntity.ok("Oprema i slika su uspešno sačuvani.");
    }

    @PutMapping("/{id}/price")
    public ResponseEntity<String> updatePrice(@PathVariable Long id, @RequestBody Double newPrice) {
        employeeShopService.updateEquipmentPrice(id, newPrice);
        return ResponseEntity.ok("Cena je ažurirana.");
    }

    @PutMapping("/{id}/stock")
    public ResponseEntity<String> updateStock(@PathVariable Long id, @RequestBody Integer newStock) {
        employeeShopService.updateEquipmentStock(id, newStock);
        return ResponseEntity.ok("Zalihe su ažurirane.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEquipment(@PathVariable Long id) {
        employeeShopService.deleteEquipment(id);
        return ResponseEntity.ok("Oprema je uspešno obrisana.");
    }
}
