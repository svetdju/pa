package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Sportski objekat (hala, teren, dvorana, kompleks) sa pripadajućom firmom.
 *
 * <p>Status {@code PENDING} znači da objekat čeka administratorsko odobrenje
 * pre nego što postane vidljiv ostalim korisnicima. Polja vezana za firmu
 * ({@code companyName}, {@code companyIdNumber}, {@code pib}, {@code companyAddress})
 * koriste se pri registraciji zaposlenog — isti objekat može imati najviše
 * dva zaposlena.</p>
 *
 * <p>Dozvoljene vrednosti statusa: PENDING | APPROVED | REJECTED.</p>
 */
@Entity
@Table(name = "facilities")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Facility {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "city", nullable = false, length = 50)
    private String city;

    @Column(name = "address", nullable = false, length = 150)
    private String address;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "price_per_hour", nullable = false, precision = 10, scale = 2)
    private BigDecimal pricePerHour;

    @Column(name = "type", nullable = false, length = 20)
    private String type;

    @Column(name = "status", nullable = false, length = 20)
    private String status;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "company_name", nullable = false, length = 100)
    private String companyName;

    @Column(name = "company_address", nullable = false, length = 150)
    private String companyAddress;

    @Column(name = "company_id_number", nullable = false, length = 8)
    private String companyIdNumber;

    @Column(name = "pib", nullable = false, length = 9)
    private String pib;

    @Column(name = "work_start_time", nullable = false, length = 5)
    private String workStartTime;

    @Column(name = "work_end_time", nullable = false, length = 5)
    private String workEndTime;

    @Column(name = "max_no_shows", nullable = false)
    private Integer maxNoShows;
}
