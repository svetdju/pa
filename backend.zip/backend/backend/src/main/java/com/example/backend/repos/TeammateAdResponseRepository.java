package com.example.backend.repos;

import com.example.backend.models.TeammateAdResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Prijave sportista na oglase "tražim saigrače". Servisi koriste nasleđeni
 * {@code save()} direktno.
 */
@Repository
public interface TeammateAdResponseRepository extends JpaRepository<TeammateAdResponse, Long> {
}
