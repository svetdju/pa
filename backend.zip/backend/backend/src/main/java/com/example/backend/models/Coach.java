package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Trener koji drži individualne treninge u okviru nekog {@link Facility}-ja.
 * Aktivan trener ({@code isActive = true}) može da prima nove zakazivanja.
 */
@Entity
@Table(name = "coaches")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Coach {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "facility_id", nullable = false)
    private Long facilityId;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "specialization", nullable = false, length = 255)
    private String specialization;

    @Column(name = "sport", nullable = false, length = 50)
    private String sport;

    @Column(name = "price_per_hour", nullable = false)
    private Double pricePerHour;

    @Column(name = "average_rating")
    private Double averageRating;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;
}
