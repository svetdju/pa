package com.example.backend.repos;

import com.example.backend.models.Equipment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EquipmentRepository extends JpaRepository<Equipment, Long> {

    List<Equipment> findAllBySportType(String sportType);

    default List<Equipment> findBySportType(String sportType) {
        return findAllBySportType(sportType);
    }

    /** Postavlja novu količinu zalihe za artikal. */
    @Modifying
    @Query("UPDATE Equipment e SET e.stockQuantity = :newStock WHERE e.id = :id")
    int updateStock(@Param("id") Long id, @Param("newStock") int newStock);

    /** Povećava zalihu za datu količinu (koristi se pri otkazivanju porudžbine). */
    @Modifying
    @Query("UPDATE Equipment e SET e.stockQuantity = e.stockQuantity + :quantity WHERE e.id = :id")
    int incrementStock(@Param("id") Long id, @Param("quantity") Integer quantity);

    /**
     * Najveći aktivni popust za dati sport tip (ako danas pada u period važenja).
     * Vraća 0 ako nema aktivnih promocija.
     */
    @Query(value = "SELECT COALESCE(MAX(p.discount_percent), 0) FROM promotions p " +
                   "WHERE p.is_active = 1 " +
                   "AND p.sport_type = :sportType " +
                   "AND CURDATE() BETWEEN p.start_date AND p.end_date",
           nativeQuery = true)
    Integer findActiveDiscountForSport(@Param("sportType") String sportType);

    /** Postavlja novu cenu artikla. */
    @Modifying
    @Query("UPDATE Equipment e SET e.price = :newPrice WHERE e.id = :id")
    int updatePrice(@Param("id") Long id, @Param("newPrice") Double newPrice);
}
