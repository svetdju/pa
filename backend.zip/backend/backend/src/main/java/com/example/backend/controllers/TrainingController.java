package com.example.backend.controllers;

import com.example.backend.dtos.TrainingRequest;
import com.example.backend.dtos.TrainingResponse;
import com.example.backend.models.Coach;
import com.example.backend.services.TrainingService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

/**
 * Individualni treninzi — pregled trenera, zakazivanje i arhiva.
 */
@RestController
@RequestMapping("/api/trainings")
@CrossOrigin(origins = "http://localhost:4200")
public class TrainingController {

    private final TrainingService trainingService;

    public TrainingController(TrainingService trainingService) {
        this.trainingService = trainingService;
    }

    /** Treneri po objektu i sportu — javno dostupno. */
    @GetMapping("/coaches")
    public ResponseEntity<List<Coach>> getCoaches(@RequestParam("facility_id") Long facilityId,
                                                  @RequestParam("sport") String sport) {
        return ResponseEntity.ok(trainingService.getCoachesByFacilityAndSport(facilityId, sport));
    }

    /** Svi treneri u objektu (za coach preview kartice) — javno dostupno. */
    @GetMapping("/facility/{facilityId}/coaches")
    public ResponseEntity<List<Coach>> getAllCoachesByFacility(@PathVariable Long facilityId) {
        return ResponseEntity.ok(trainingService.getAllCoachesByFacility(facilityId));
    }

    /** Zakazuje individualni trening. */
    @PostMapping
    public ResponseEntity<String> scheduleTraining(@Valid @RequestBody TrainingRequest request,
                                                   Principal principal) {
        if (principal == null) {
            return ResponseEntity.status(401).body("Niste autorizovani. Token nedostaje.");
        }
        trainingService.scheduleTraining(request, principal.getName());
        return ResponseEntity.ok("Trening je uspešno zakazan!");
    }

    /** Arhiva i zakazani treninzi korisnika. */
    @GetMapping("/my")
    public ResponseEntity<List<TrainingResponse>> getMyTrainings(Principal principal) {
        return ResponseEntity.ok(trainingService.getMyTrainings(principal.getName()));
    }
}
