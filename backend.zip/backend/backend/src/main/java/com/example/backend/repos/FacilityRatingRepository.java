package com.example.backend.repos;

import com.example.backend.models.FacilityRating;
import com.example.backend.dtos.RatingResponse;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface FacilityRatingRepository extends JpaRepository<FacilityRating, Long> {

    @Query("SELECT COUNT(r) FROM FacilityRating r WHERE r.facilityId = :facilityId AND r.isLike = true")
    long countLikes(@Param("facilityId") Long facilityId);

    @Query("SELECT COUNT(r) FROM FacilityRating r WHERE r.facilityId = :facilityId AND r.isLike = false")
    long countDislikes(@Param("facilityId") Long facilityId);

    /**
     * Poslednjih N komentara na objekat (sa imenom korisnika koji je komentar ostavio).
     * LIMIT se kontroliše preko {@link Pageable}.
     */
    @Query(value = "SELECT r.id, u.username, r.is_like, r.comment, r.created_at " +
                   "FROM facility_ratings r " +
                   "JOIN users u ON u.id = r.user_id " +
                   "WHERE r.facility_id = :facilityId " +
                   "AND r.comment IS NOT NULL AND r.comment <> '' " +
                   "ORDER BY r.created_at DESC",
           nativeQuery = true)
    List<Object[]> findLastCommentRows(@Param("facilityId") Long facilityId, Pageable pageable);

    default List<RatingResponse> findLastComments(Long facilityId, int limit) {
        List<Object[]> rows = findLastCommentRows(facilityId, PageRequest.of(0, limit));

        List<RatingResponse> result = new ArrayList<>(rows.size());
        for (Object[] r : rows) {
            java.sql.Timestamp ts = (java.sql.Timestamp) r[4];
            boolean isLike = r[2] instanceof Boolean ? (Boolean) r[2] : ((Number) r[2]).intValue() == 1;

            result.add(new RatingResponse(
                    ((Number) r[0]).longValue(),
                    (String) r[1],
                    isLike,
                    (String) r[3],
                    ts != null ? ts.toLocalDateTime() : null));
        }
        return result;
    }

    /** Broj reakcija (lajk + dislajk + komentar) koje je korisnik ostavio na objektu. */
    @Query("SELECT COUNT(r) FROM FacilityRating r WHERE r.userId = :userId AND r.facilityId = :facilityId")
    int countRatingsByUserAndFacility(@Param("userId") Long userId,
                                      @Param("facilityId") Long facilityId);
}
