package com.example.backend.repos;

import com.example.backend.models.Coach;
import com.example.backend.models.Facility;
import com.example.backend.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Administratorski pregled i ažuriranje korisnika, trenera i objekata.
 *
 * <p>Kreira se nad {@link User} entitetom (jer admin pregleda korisnike), ali
 * sadrži i metode za ažuriranje statusa {@link Facility}-ja i aktivnosti
 * {@link Coach}-a preko {@code @Modifying} upita.</p>
 */
@Repository
public interface AdminRepository extends JpaRepository<User, Long> {

    /** Svi korisnici sortirani po statusu opadajuće, pa po korisničkom imenu rastuće. */
    @Query("SELECT u FROM User u ORDER BY u.status DESC, u.username ASC")
    List<User> findAllUsers();

    /** Menja status korisnika po ID-u. */
    @Modifying
    @Query("UPDATE User u SET u.status = :status WHERE u.id = :userId")
    int updateUserStatus(@Param("userId") Long userId, @Param("status") String status);

    /** Menja status objekta po ID-u. */
    @Modifying
    @Query("UPDATE Facility f SET f.status = :status WHERE f.id = :facilityId")
    int updateFacilityStatus(@Param("facilityId") Long facilityId, @Param("status") String status);

    /** Svi PENDING objekti, sortirano opadajuće po ID-u. */
    @Query("SELECT f FROM Facility f WHERE f.status = 'PENDING' ORDER BY f.id DESC")
    List<Facility> findPendingFacilities();

    /** Svi treneri, sortirano po ID-u objekta pa po imenu. */
    @Query("SELECT c FROM Coach c ORDER BY c.facilityId, c.name")
    List<Coach> findAllCoaches();

    /** Menja {@code isActive} status trenera. */
    @Modifying
    @Query("UPDATE Coach c SET c.isActive = :isActive WHERE c.id = :coachId")
    int updateCoachActiveStatus(@Param("coachId") Long coachId, @Param("isActive") Boolean isActive);
}
