package com.example.backend.controllers;

import com.example.backend.services.ReportService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

/**
 * PDF izveštaji za zaposlene — popunjenost terena i promet opreme po mesecima.
 */
@RestController
@RequestMapping("/api/employee/reports")
@CrossOrigin(origins = "http://localhost:4200")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    /** PDF izveštaj o popunjenosti terena (parametar {@code month} u formatu yyyy-MM). */
    @GetMapping("/court-usage")
    public ResponseEntity<byte[]> courtUsageReport(@RequestParam String month, Principal principal) {
        byte[] pdf = reportService.generateCourtUsageReport(month, principal.getName());
        return pdfResponse(pdf, "court-usage-" + month + ".pdf");
    }

    /** PDF izveštaj o prometu opreme (parametar {@code month} u formatu yyyy-MM). */
    @GetMapping("/equipment-sales")
    public ResponseEntity<byte[]> equipmentSalesReport(@RequestParam String month, Principal principal) {
        byte[] pdf = reportService.generateEquipmentSalesReport(month, principal.getName());
        return pdfResponse(pdf, "equipment-sales-" + month + ".pdf");
    }

    private ResponseEntity<byte[]> pdfResponse(byte[] pdf, String filename) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", filename);
        headers.setContentLength(pdf.length);
        return ResponseEntity.ok().headers(headers).body(pdf);
    }
}
