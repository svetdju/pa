package com.example.backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Generisanje i parsiranje JWT tokena. Ključ se učitava iz
 * {@code application.properties} ({@code jwt.secret}); algoritam (HS256) se
 * automatski prepoznaje iz ključa.
 *
 * <p>Token sadrži claim {@code role} (npr. "ATHLETE", "EMPLOYEE", "ADMIN") i
 * subjekt (korisničko ime). Važi 10 sati od izdavanja.</p>
 */
@Component
public class JwtUtil {

    private static final long TOKEN_VALIDITY_MS = 1000L * 60 * 60 * 10; // 10 sati

    private final SecretKey key;

    public JwtUtil(@Value("${jwt.secret:moj_super_tajni_kljuc_za_fakultetski_projekat_koji_mora_biti_dugacak}") String secret) {
        this.key = Keys.hmacShaKeyFor(secret.getBytes());
    }

    /** Izvlači korisničko ime (subjekt) iz tokena. */
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    /** Izvlači datum isteka tokena. */
    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    /** Izvlači ulogu iz {@code role} claim-a. */
    public String extractRole(String token) {
        return extractClaim(token, claims -> claims.get("role", String.class));
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        return claimsResolver.apply(extractAllClaims(token));
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    /** Generiše novi token za korisnika sa datom ulogom. */
    public String generateToken(String username, String role) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", role);
        return Jwts.builder()
                .claims(claims)
                .subject(username)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + TOKEN_VALIDITY_MS))
                .signWith(key)
                .compact();
    }

    /** Da li je token validan za datog korisnika (ime se poklapa i nije istekao)? */
    public boolean validateToken(String token, String username) {
        return username.equals(extractUsername(token)) && !isTokenExpired(token);
    }
}
