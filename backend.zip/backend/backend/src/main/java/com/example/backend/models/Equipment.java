package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Artikal u prodavnici opreme. Cena se čuva kao {@code Double}; kolona
 * {@code sport_type} je slobodan tekst (npr. "Tenis", "Košarka") koji se
 * koristi za katalog i za računanje aktivnog popusta iz tabele promotions.
 */
@Entity
@Table(name = "equipment")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Equipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "image_path", length = 255)
    private String imagePath;

    @Column(name = "sport_type", nullable = false, length = 50)
    private String sportType;

    @Column(name = "price", nullable = false)
    private Double price;

    @Column(name = "stock_quantity", nullable = false)
    private Integer stockQuantity;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "sport_id")
    private Long sportId;
}
