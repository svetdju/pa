package com.example.backend.services;

import com.example.backend.repos.PasswordResetRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

/**
 * Resetovanje lozinke: generiše token (važi 30 minuta), proverava njegovu
 * validnost i postavlja novu lozinku.
 */
@Service
public class PasswordResetService {

    private final PasswordResetRepository resetRepository;
    private final PasswordEncoder passwordEncoder;

    public PasswordResetService(PasswordResetRepository resetRepository,
                                PasswordEncoder passwordEncoder) {
        this.resetRepository = resetRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Generiše reset token za korisnika na osnovu korisničkog imena ili email-a.
     * Vraća token (koji frontend koristi u linku) ili {@code null} ako korisnik ne postoji.
     */
    public String requestPasswordReset(String identifier) {
        Map<String, Object> user = resetRepository.findByUsernameOrEmail(identifier);
        if (user == null) {
            return null;
        }
        Long userId = ((Number) user.get("id")).longValue();
        String token = UUID.randomUUID().toString().replace("-", "");
        resetRepository.saveToken(userId, token);
        return token;
    }

    /** Da li je token validan (neiskorišćen, neistekao)? */
    public boolean isTokenValid(String token) {
        return resetRepository.findValidToken(token) != null;
    }

    /**
     * Resetuje lozinku koristeći validan token. Vraća {@code true} ako je
     * promena uspela, {@code false} ako je token nevalidan ili istekao.
     */
    public boolean resetPassword(String token, String newPassword) {
        Map<String, Object> tokenData = resetRepository.findValidToken(token);
        if (tokenData == null) {
            return false;
        }
        Long userId = ((Number) tokenData.get("user_id")).longValue();
        String hashedPassword = passwordEncoder.encode(newPassword);

        resetRepository.updatePassword(userId, hashedPassword);
        resetRepository.markTokenAsUsed(token);
        return true;
    }
}
