package com.example.backend.services;

import com.example.backend.dtos.ReservationRequest;
import com.example.backend.dtos.ReservationResponse;
import com.example.backend.models.Reservation;
import com.example.backend.models.User;
import com.example.backend.repos.CourtRepository;
import com.example.backend.repos.NoShowRepository;
import com.example.backend.repos.ReservationRepository;
import com.example.backend.repos.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Kreiranje, otkazivanje i pregled rezervacija terena.
 *
 * <p>Biznis pravila:</p>
 * <ul>
 *   <li>Rezervacija se kreira sa statusom PENDING — zaposleni je mora potvrditi.</li>
 *   <li>Korisnik ne sme biti blokiran u tom objektu zbog nedolazaka.</li>
 *   <li>Termin ne sme da se preklapa sa postojećom CONFIRMED rezervacijom.</li>
 *   <li>PENDING rezervacija se može otkazati u svakom trenutku; za CONFIRMED
 *       i druge statuse važi pravilo 12 sati pre početka termina.</li>
 * </ul>
 */
@Service
public class ReservationService {

    /** Broj sati pre termina nakon kojeg CONFIRMED rezervacija ne može da se otkaže. */
    private static final long CANCEL_DEADLINE_HOURS = 12;

    private final ReservationRepository reservationRepository;
    private final CourtRepository courtRepository;
    private final UserRepository userRepository;
    private final NoShowRepository noShowRepository;

    public ReservationService(ReservationRepository reservationRepository,
                              CourtRepository courtRepository,
                              UserRepository userRepository,
                              NoShowRepository noShowRepository) {
        this.reservationRepository = reservationRepository;
        this.courtRepository = courtRepository;
        this.userRepository = userRepository;
        this.noShowRepository = noShowRepository;
    }

    /**
     * Kreira novu rezervaciju sa statusom PENDING. Proverava da je teren u
     * APPROVED objektu, da korisnik nije blokiran, i da termin nije zauzet.
     */
    @Transactional
    public void createReservation(ReservationRequest dto, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        if (!courtRepository.isCourtInApprovedFacility(dto.getCourt_id())) {
            throw new RuntimeException("Rezervacije mogu se praviti samo za odobrene objekte.");
        }

        Long facilityId = courtRepository.getFacilityIdByCourtId(dto.getCourt_id());
        if (facilityId != null && noShowRepository.isUserBlocked(user.getId(), facilityId)) {
            throw new RuntimeException(
                    "Vaš nalog je blokiran za rezervacije u ovom objektu zbog previše nedolazaka.");
        }

        if (reservationRepository.existsOverlapping(
                dto.getCourt_id(), dto.getReservation_date(), dto.getStart_time(), dto.getEnd_time())) {
            throw new RuntimeException("Izabrani termin je već zauzet.");
        }

        Reservation res = new Reservation();
        res.setUserId(user.getId());
        res.setCourtId(dto.getCourt_id());
        res.setReservationDate(dto.getReservation_date());
        res.setStartTime(dto.getStart_time());
        res.setEndTime(dto.getEnd_time());
        res.setStatus("PENDING");

        reservationRepository.save(res);
    }

    public List<ReservationResponse> getMyReservations(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));
        return reservationRepository.findAllByUserId(user.getId());
    }

    /**
     * Otkazuje rezervaciju. PENDING se može otkazati uvek; za ostale statuse
     * važi pravilo 12 sati pre početka termina.
     */
    @Transactional
    public void cancelReservation(Long reservationId, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        Reservation res = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Rezervacija ne postoji."));

        if (!res.getUserId().equals(user.getId())) {
            throw new RuntimeException("Nemate pravo da otkažete tuđu rezervaciju.");
        }

        if (!"PENDING".equalsIgnoreCase(res.getStatus())) {
            enforceCancelDeadline(res);
        }

        reservationRepository.updateStatus(reservationId, "CANCELLED");
    }

    /**
     * Zauzeti termini za teren na određeni dan (CONFIRMED i PENDING). Javno
     * dostupno — koristi se za interaktivni kalendar.
     */
    public List<Reservation> getOccupiedSlotsForCourt(Long courtId, String date) {
        return reservationRepository.findAllByCourtIdAndDate(courtId, date);
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private void enforceCancelDeadline(Reservation res) {
        LocalDateTime reservationStart = LocalDateTime.parse(
                res.getReservationDate() + "T" + res.getStartTime());
        LocalDateTime now = LocalDateTime.now();
        Duration duration = Duration.between(now, reservationStart);

        if (duration.toHours() < CANCEL_DEADLINE_HOURS) {
            throw new RuntimeException(
                    "Otkazivanje nije dozvoljeno jer je do početka termina ostalo manje od "
                            + CANCEL_DEADLINE_HOURS + " sati.");
        }
    }
}
