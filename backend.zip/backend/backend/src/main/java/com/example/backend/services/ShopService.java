package com.example.backend.services;

import com.example.backend.dtos.CartItemRequest;
import com.example.backend.dtos.OrderRequest;
import com.example.backend.dtos.OrderResponse;
import com.example.backend.models.Equipment;
import com.example.backend.models.OrderItem;
import com.example.backend.models.User;
import com.example.backend.repos.EquipmentRepository;
import com.example.backend.repos.OrderRepository;
import com.example.backend.repos.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Prodavnica opreme — katalog, kreiranje porudžbine iz korpe i otkazivanje.
 *
 * <p>Biznis pravila:</p>
 * <ul>
 *   <li>Kreiranje porudžbine je transakciono — čuvaju se istorijske cene i popusti.</li>
 *   <li>Popust se računa kao najveći aktivni popust za taj sport u trenutku kupovine.</li>
 *   <li>Zalihe se smanjuju pri kupovini; vraćaju se pri otkazivanju ORDERED porudžbine.</li>
 *   <li>Otkazivanje moguće samo za porudžbine u statusu ORDERED.</li>
 * </ul>
 */
@Service
public class ShopService {

    private final EquipmentRepository equipmentRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;

    public ShopService(EquipmentRepository equipmentRepository,
                       OrderRepository orderRepository,
                       UserRepository userRepository) {
        this.equipmentRepository = equipmentRepository;
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
    }

    /** Katalog opreme po sportu. */
    public List<Equipment> getCatalogBySport(String sportType) {
        return equipmentRepository.findBySportType(sportType);
    }

    /** Sva oprema u katalogu — za zaposleni dashboard. */
    public List<Equipment> getAllEquipment() {
        return equipmentRepository.findAll();
    }

    /** Istorija i aktivne porudžbine korisnika. */
    public List<OrderResponse> getMyOrders(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));
        return orderRepository.findAllByUserId(user.getId());
    }

    /**
     * Kreira porudžbinu iz korpe. Proverava zalihe, računa popuste, snima
     * stavke sa istorijskim cenama i smanjuje zalihe.
     */
    @Transactional
    public void placeOrder(OrderRequest dto, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        // 1. Prvi prolaz: provera zaliha i računanje totalne cene sa popustima
        double totalFinalPrice = 0.0;
        for (CartItemRequest item : dto.getItems()) {
            Equipment eq = equipmentRepository.findById(item.getEquipment_id())
                    .orElseThrow(() -> new RuntimeException("Artikal ne postoji."));
            if (eq.getStockQuantity() < item.getQuantity()) {
                throw new RuntimeException("Nema dovoljno zaliha za: " + eq.getName());
            }
            int discount = activeDiscountFor(eq.getSportType());
            totalFinalPrice += discountedPrice(eq.getPrice(), discount) * item.getQuantity();
        }

        // 2. Kreiranje glavne porudžbine
        Long orderId = orderRepository.createOrder(user.getId(), totalFinalPrice);

        // 3. Drugi prolaz: snimanje stavki i smanjenje zaliha
        for (CartItemRequest item : dto.getItems()) {
            Equipment eq = equipmentRepository.findById(item.getEquipment_id())
                    .orElseThrow(() -> new RuntimeException("Artikal ne postoji."));
            int discount = activeDiscountFor(eq.getSportType());
            double finalUnitPrice = discountedPrice(eq.getPrice(), discount);

            orderRepository.saveOrderItem(
                    orderId, eq.getId(), item.getQuantity(),
                    eq.getPrice(), discount, finalUnitPrice);

            equipmentRepository.updateStock(eq.getId(), eq.getStockQuantity() - item.getQuantity());
        }
    }

    /**
     * Otkazuje porudžbinu u statusu ORDERED i vraća sve artikle na lager.
     */
    @Transactional
    public void cancelOrder(Long orderId, String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Korisnik nije pronađen."));

        String currentStatus = orderRepository.findStatusByIdAndUserId(orderId, user.getId());
        if (!"ORDERED".equals(currentStatus)) {
            throw new RuntimeException("Može se otkazati samo 'ORDERED' porudžbina.");
        }

        List<OrderItem> items = orderRepository.findItemsByOrderId(orderId);
        for (OrderItem item : items) {
            equipmentRepository.incrementStock(item.getEquipmentId(), item.getQuantity());
        }

        orderRepository.updateStatus(orderId, user.getId(), "CANCELLED");
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private int activeDiscountFor(String sportType) {
        Integer d = equipmentRepository.findActiveDiscountForSport(sportType);
        return d == null ? 0 : d;
    }

    private double discountedPrice(double unitPrice, int discountPercent) {
        return unitPrice * (1 - discountPercent / 100.0);
    }
}
