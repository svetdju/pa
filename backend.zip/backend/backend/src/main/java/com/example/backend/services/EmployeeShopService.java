package com.example.backend.services;

import com.example.backend.dtos.OrderResponse;
import com.example.backend.models.Equipment;
import com.example.backend.models.OrderItem;
import com.example.backend.repos.EquipmentRepository;
import com.example.backend.repos.OrderRepository;
import com.example.backend.repos.StaffOrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;

/**
 * Zaposleni upravljanje prodavnicom: pregled porudžbina, ažuriranje statusa,
 * i CRUD nad katalogom opreme (dodavanje sa slikom, promena cene/zalihe, brisanje).
 */
@Service
public class EmployeeShopService {

    private static final String UPLOAD_DIR = "uploads/equipment/";

    private final StaffOrderRepository staffOrderRepository;
    private final OrderRepository orderRepository;
    private final EquipmentRepository equipmentRepository;

    public EmployeeShopService(StaffOrderRepository staffOrderRepository,
                               OrderRepository orderRepository,
                               EquipmentRepository equipmentRepository) {
        this.staffOrderRepository = staffOrderRepository;
        this.orderRepository = orderRepository;
        this.equipmentRepository = equipmentRepository;
    }

    public List<OrderResponse> getAllOrders() {
        return staffOrderRepository.findAllOrders();
    }

    @Transactional
    public void acceptOrder(Long orderId) {
        staffOrderRepository.updateStatusDirectly(orderId, "ACCEPTED");
    }

    @Transactional
    public void markOrderAsDelivered(Long orderId) {
        staffOrderRepository.updateStatusDirectly(orderId, "DELIVERED");
    }

    /**
     * Zaposleni otkazuje porudžbinu — vraća sve artikle na lager.
     */
    @Transactional
    public void cancelOrderAsStaff(Long orderId) {
        List<OrderItem> items = orderRepository.findItemsByOrderId(orderId);
        for (OrderItem item : items) {
            equipmentRepository.incrementStock(item.getEquipmentId(), item.getQuantity());
        }
        staffOrderRepository.updateStatusDirectly(orderId, "CANCELLED");
    }

    /**
     * Dodaje novi artikal u katalog. Ako je priložena slika, snima se u
     * {@code uploads/equipment/} sa UUID sufiksom.
     */
    @Transactional
    public void createNewEquipment(String name, Double price, Integer stock, String sportType,
                                   String description, MultipartFile file) {
        String imagePath = (file != null && !file.isEmpty()) ? saveEquipmentImage(file) : null;

        Equipment equipment = new Equipment();
        equipment.setName(name);
        equipment.setImagePath(imagePath);
        equipment.setSportType(sportType);
        equipment.setPrice(price);
        equipment.setStockQuantity(stock);
        equipment.setDescription(description);

        equipmentRepository.save(equipment);
    }

    @Transactional
    public void updateEquipmentPrice(Long id, Double newPrice) {
        equipmentRepository.updatePrice(id, newPrice);
    }

    @Transactional
    public void updateEquipmentStock(Long id, Integer newStock) {
        equipmentRepository.updateStock(id, newStock);
    }

    @Transactional
    public void deleteEquipment(Long id) {
        equipmentRepository.deleteById(id);
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private String saveEquipmentImage(MultipartFile file) {
        try {
            File dir = new File(UPLOAD_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            String fileName = "eq_" + UUID.randomUUID().toString().substring(0, 8) + ".jpg";
            Path target = Paths.get(UPLOAD_DIR + fileName);
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return "/" + UPLOAD_DIR + fileName;
        } catch (Exception e) {
            throw new RuntimeException("Greška pri čuvanju slike opreme: " + e.getMessage());
        }
    }
}
