package com.example.backend.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Komentar i/ili like/dislike koji je korisnik ostavio na nekom {@link Facility}-ju.
 * Polje {@code isLike} označava tip reakcije: {@code true} = sviđa mi se,
 * {@code false} = ne sviđa mi se. Datum reakcije se automatski popunjava pre
 * snimanja ({@link #onCreate()}).
 */
@Entity
@Table(name = "facility_ratings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FacilityRating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "facility_id", nullable = false)
    private Long facilityId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "is_like", nullable = false)
    private Boolean isLike;

    @Column(name = "comment", length = 500)
    private String comment;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
    }
}
