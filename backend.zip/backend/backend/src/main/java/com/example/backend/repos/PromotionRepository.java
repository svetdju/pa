package com.example.backend.repos;

import com.example.backend.models.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromotionRepository extends JpaRepository<Promotion, Long> {

    /** Sve promocije, sortirano opadajuće po startnom datumu. */
    List<Promotion> findAllByOrderByStartDateDesc();
}
