package com.example.backend.repos;

import com.example.backend.models.PasswordResetToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Tokeni za resetovanje lozinke. {@link #saveToken(Long, String)} kreira novi
 * token sa 30-minutnim važenjem; {@link #findValidToken(String)} vraća samo
 * neiskorišćene i neistekle tokene.
 */
@Repository
public interface PasswordResetRepository extends JpaRepository<PasswordResetToken, Long> {

    /**
     * Pronalazi korisnika po korisničkom imenu ILI email-u. Vraća Map-u sa
     * {@code id}, {@code username}, {@code email} poljima (kompatibilnost sa
     * starim servisom koji radi sa Map-om).
     */
    @Query("SELECT u.id AS id, u.username AS username, u.email AS email FROM User u " +
           "WHERE u.username = :identifier OR u.email = :identifier")
    List<java.util.Map<String, Object>> findByUsernameOrEmailRaw(@Param("identifier") String identifier);

    default java.util.Map<String, Object> findByUsernameOrEmail(String identifier) {
        var list = findByUsernameOrEmailRaw(identifier);
        return list.isEmpty() ? null : list.get(0);
    }

    /** Kreira novi reset token sa 30-minutnim važenjem. */
    default void saveToken(Long userId, String token) {
        PasswordResetToken prt = new PasswordResetToken();
        prt.setUserId(userId);
        prt.setToken(token);
        prt.setCreatedAt(LocalDateTime.now());
        prt.setExpiresAt(LocalDateTime.now().plusMinutes(30));
        prt.setUsed(false);
        save(prt);
    }

    /** Vraća validan (neiskorišćen, neistekao) token. */
    @Query("SELECT t FROM PasswordResetToken t WHERE t.token = :token " +
           "AND t.used = false AND t.expiresAt > CURRENT_TIMESTAMP")
    Optional<PasswordResetToken> findValidTokenRaw(@Param("token") String token);

    default java.util.Map<String, Object> findValidToken(String token) {
        return findValidTokenRaw(token)
                .map(t -> {
                    java.util.Map<String, Object> m = new java.util.HashMap<>();
                    m.put("id", t.getId());
                    m.put("user_id", t.getUserId());
                    m.put("token", t.getToken());
                    m.put("expires_at", t.getExpiresAt());
                    m.put("used", t.getUsed());
                    return m;
                })
                .orElse(null);
    }

    /** Označava token kao iskorišćen. */
    @Modifying
    @Query("UPDATE PasswordResetToken t SET t.used = true WHERE t.token = :token")
    void markTokenAsUsed(@Param("token") String token);

    /** Menja lozinku korisnika po ID-u. */
    @Modifying
    @Query("UPDATE User u SET u.passwordHash = :hashedPassword WHERE u.id = :userId")
    void updatePassword(@Param("userId") Long userId,
                        @Param("hashedPassword") String hashedPassword);
}
