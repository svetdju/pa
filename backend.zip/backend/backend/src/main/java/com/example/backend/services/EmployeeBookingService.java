package com.example.backend.services;

import com.example.backend.dtos.ReservationViewResponse;
import com.example.backend.models.Reservation;
import com.example.backend.models.User;
import com.example.backend.repos.BookingRepository;
import com.example.backend.repos.CourtRepository;
import com.example.backend.repos.NoShowRepository;
import com.example.backend.repos.ReservationRepository;
import com.example.backend.repos.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Zaposleni dashboard — check-in tabela, kalendar, pending zahtevi i
 * drag-and-drop pomeranje rezervacija.
 */
@Service
public class EmployeeBookingService {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final ReservationRepository reservationRepository;
    private final NoShowRepository noShowRepository;
    private final CourtRepository courtRepository;

    public EmployeeBookingService(BookingRepository bookingRepository,
                                  UserRepository userRepository,
                                  ReservationRepository reservationRepository,
                                  NoShowRepository noShowRepository,
                                  CourtRepository courtRepository) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.reservationRepository = reservationRepository;
        this.noShowRepository = noShowRepository;
        this.courtRepository = courtRepository;
    }

    /** Današnje CONFIRMED rezervacije i SCHEDULED treninzi — za check-in tabelu. */
    public List<ReservationViewResponse> getCheckInTable(String username) {
        User employee = getEmployeeOrThrow(username);
        return bookingRepository.getDashboardForEmployee(employee.getId());
    }

    /** Sve rezervacije i treninzi za teren u periodu — za kalendar. */
    public List<ReservationViewResponse> getCalendarData(Long courtId, String startDate, String endDate) {
        return bookingRepository.getCalendarData(courtId, startDate, endDate);
    }

    /** PENDING rezervacije koje čekaju odobrenje zaposlenog. */
    public List<ReservationViewResponse> getPendingRequests(String username) {
        User employee = getEmployeeOrThrow(username);
        return bookingRepository.getPendingReservationsForEmployee(employee.getId());
    }

    /**
     * Akcija u check-in tabeli: {@code CONFIRM} znači da je korisnik došao
     * (status -> COMPLETED), {@code REJECT} znači da nije došao (status -> ABSENT
     * za rezervacije uz evidentiranje no-show-a; CANCELLED za treninge).
     */
    @Transactional
    public void processCheckInAction(String type, Long id, String action) {
        if ("CONFIRM".equalsIgnoreCase(action)) {
            bookingRepository.updateStatus(type, id, "COMPLETED");
        } else if ("REJECT".equalsIgnoreCase(action)) {
            handleNoShow(type, id);
        } else {
            throw new IllegalArgumentException("Nepoznata akcija: " + action);
        }
    }

    /**
     * Odobrava ili odbija PENDING rezervaciju. Pri odobravanju se proverava da
     * termin nije postao zauzet drugom potvrđenom rezervacijom.
     */
    @Transactional
    public void processPendingApproval(Long id, boolean approve) {
        if (approve) {
            Reservation res = reservationRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Rezervacija nije pronađena."));

            boolean overlap = reservationRepository.existsOverlappingExcluding(
                    res.getCourtId(),
                    res.getReservationDate(),
                    res.getStartTime(),
                    res.getEndTime(),
                    res.getId());
            if (overlap) {
                throw new RuntimeException(
                        "Nije moguće odobriti rezervaciju: termin je već zauzet drugom potvrđenom rezervacijom.");
            }
        }
        String targetStatus = approve ? "CONFIRMED" : "CANCELLED";
        bookingRepository.updateStatus("RESERVATION", id, targetStatus);
    }

    /**
     * Pomera rezervaciju na novi termin (drag-and-drop u kalendaru). Proverava
     * preklapanje sa postojećim CONFIRMED rezervacijama na novom terminu.
     */
    @Transactional
    public void moveReservation(Long reservationId, String newDate, String newStartTime, String newEndTime) {
        Reservation res = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Rezervacija nije pronađena."));

        boolean overlap = reservationRepository.existsOverlappingExcluding(
                res.getCourtId(), newDate, newStartTime, newEndTime, reservationId);
        if (overlap) {
            throw new RuntimeException("Novi termin se preklapa sa postojećom potvrđenom rezervacijom.");
        }
        reservationRepository.updateDateTime(reservationId, newDate, newStartTime, newEndTime);
    }

    // ========================================================================
    // Privatni helper-i
    // ========================================================================

    private User getEmployeeOrThrow(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException(
                        "Zaposleni sa korisničkim imenom " + username + " nije pronađen."));
    }

    private void handleNoShow(String type, Long id) {
        if ("RESERVATION".equalsIgnoreCase(type)) {
            bookingRepository.updateStatus(type, id, "ABSENT");
            Reservation res = reservationRepository.findById(id).orElse(null);
            if (res != null) {
                Long facilityId = courtRepository.getFacilityIdByCourtId(res.getCourtId());
                if (facilityId != null) {
                    int maxNoShows = noShowRepository.getMaxNoShows(facilityId);
                    noShowRepository.incrementNoShow(res.getUserId(), facilityId, maxNoShows);
                }
            }
        } else {
            // Za treninge nema no-show evidencije — samo CANCELLED
            bookingRepository.updateStatus(type, id, "CANCELLED");
        }
    }
}
