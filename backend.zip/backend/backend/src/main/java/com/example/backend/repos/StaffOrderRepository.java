package com.example.backend.repos;

import com.example.backend.dtos.OrderResponse;
import com.example.backend.models.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Pregled svih porudžbina sa strane zaposlenog. Razlika u odnosu na
 * {@link OrderRepository} je što ovde nema filtera po korisniku — zaposleni
 * vidi sve porudžbine u sistemu.
 */
@Repository
public interface StaffOrderRepository extends JpaRepository<Order, Long> {

    /** Sve porudžbine u sistemu, sortirano opadajuće po datumu. */
    @Query(value = "SELECT o.id, o.order_date, o.total_price, o.status, " +
                   "GROUP_CONCAT(CONCAT(e.name, ' (x', oi.quantity, ')') SEPARATOR ', ') AS items_summary, " +
                   "SUM(CAST(oi.unit_price AS DECIMAL(10,2)) * oi.quantity) AS total_original_price " +
                   "FROM orders o " +
                   "JOIN order_items oi ON o.id = oi.order_id " +
                   "JOIN equipment e ON oi.equipment_id = e.id " +
                   "GROUP BY o.id " +
                   "ORDER BY o.order_date DESC",
           nativeQuery = true)
    List<Object[]> findAllOrdersRaw();

    default List<OrderResponse> findAllOrders() {
        return OrderRepository.mapOrderRows(findAllOrdersRaw());
    }

    /** Direktno menja status porudžbine (bez provere vlasništva). */
    @Modifying
    @Query("UPDATE Order o SET o.status = :status WHERE o.id = :orderId")
    void updateStatusDirectly(@Param("orderId") Long orderId,
                              @Param("status") String status);
}
