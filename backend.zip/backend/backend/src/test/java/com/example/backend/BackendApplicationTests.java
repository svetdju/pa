package com.example.backend;

import com.example.backend.models.*;
import com.example.backend.repos.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Osnovni testovi za JPA repozitorijume.
 *
 * <p>Pošto nemamo MySQL u CI/CD okruzenju, ovaj test se oslanja na to da ce
 * Spring Boot uspeti da podigne ApplicationContext sa nasom konfiguracijom.
 * Ako je {@code spring.jpa.hibernate.ddl-auto=none} i {@code spring.datasource.url}
 * pokazuje na MySQL koji ne postoji, ovaj test ce pasti - pa je za lokalno
 * pokretanje potrebno da MySQL radi na localhost:3306 sa bazom
 * {@code sportsphere_db}.</p>
 *
 * <p>Za izdvajanje JPA sloja u testove bez baze koristiti {@code @DataJpaTest}
 * sa H2 profilom, ali to zahteva dodatnu konfiguraciju i izmene u native
 * query-jima.</p>
 */
@SpringBootTest
@ActiveProfiles("test")
class BackendApplicationTests {

    @Autowired private UserRepository userRepository;
    @Autowired private FacilityRepository facilityRepository;
    @Autowired private CourtRepository courtRepository;
    @Autowired private CoachRepository coachRepository;
    @Autowired private EquipmentRepository equipmentRepository;
    @Autowired private ReservationRepository reservationRepository;
    @Autowired private TrainingRepository trainingRepository;
    @Autowired private OrderRepository orderRepository;
    @Autowired private OrderItemRepository orderItemRepository;
    @Autowired private PromotionRepository promotionRepository;
    @Autowired private SportsRepository sportsRepository;
    @Autowired private NoShowRepository noShowRepository;
    @Autowired private FacilityRatingRepository facilityRatingRepository;
    @Autowired private FacilityEmployeeRepository facilityEmployeeRepository;
    @Autowired private FacilityImageRepository facilityImageRepository;
    @Autowired private TeammateAdRepository teammateAdRepository;
    @Autowired private TeammateAdResponseRepository teammateAdResponseRepository;
    @Autowired private PasswordResetRepository passwordResetRepository;
    @Autowired private AdminRepository adminRepository;
    @Autowired private BookingRepository bookingRepository;
    @Autowired private StaffOrderRepository staffOrderRepository;

    /**
     * Testira da svi repozitorijumi (21 ukupno) mogu da se injektuju iz
     * ApplicationContext-a. Ako bilo koji Spring Data JPA interfejs ima gresku
     * u @Query anotaciji ili u imenovanju metoda, ovaj test pada.
     */
    @Test
    void contextLoads() {
        assertNotNull(userRepository, "UserRepository nije injektovan");
        assertNotNull(facilityRepository, "FacilityRepository nije injektovan");
        assertNotNull(courtRepository, "CourtRepository nije injektovan");
        assertNotNull(coachRepository, "CoachRepository nije injektovan");
        assertNotNull(equipmentRepository, "EquipmentRepository nije injektovan");
        assertNotNull(reservationRepository, "ReservationRepository nije injektovan");
        assertNotNull(trainingRepository, "TrainingRepository nije injektovan");
        assertNotNull(orderRepository, "OrderRepository nije injektovan");
        assertNotNull(orderItemRepository, "OrderItemRepository nije injektovan");
        assertNotNull(promotionRepository, "PromotionRepository nije injektovan");
        assertNotNull(sportsRepository, "SportsRepository nije injektovan");
        assertNotNull(noShowRepository, "NoShowRepository nije injektovan");
        assertNotNull(facilityRatingRepository, "FacilityRatingRepository nije injektovan");
        assertNotNull(facilityEmployeeRepository, "FacilityEmployeeRepository nije injektovan");
        assertNotNull(facilityImageRepository, "FacilityImageRepository nije injektovan");
        assertNotNull(teammateAdRepository, "TeammateAdRepository nije injektovan");
        assertNotNull(teammateAdResponseRepository, "TeammateAdResponseRepository nije injektovan");
        assertNotNull(passwordResetRepository, "PasswordResetRepository nije injektovan");
        assertNotNull(adminRepository, "AdminRepository nije injektovan");
        assertNotNull(bookingRepository, "BookingRepository nije injektovan");
        assertNotNull(staffOrderRepository, "StaffOrderRepository nije injektovan");
    }

    /**
     * Testira da metod {@link UserRepository#findByUsername(String)} ima
     * ispravan potpis i da radi sa praznom bazom (vraca prazan Optional).
     *
     * <p>NAPOMENA: Za pokretanje ovog testa potrebna je prava MySQL baza
     * sportsphere_db sa inicijalnim podacima. Ako baza ne postoji, test ce pasti.</p>
     */
    @Test
    void testUserRepositoryFindByUsernameReturnsEmptyForNonExisting() {
        Optional<User> found = userRepository.findByUsername("nepostojeci_korisnik_12345");
        assertTrue(found.isEmpty(),
                "Ako baza postoji i nemamo korisnika sa tim username-om, treba da vrati prazan Optional");
    }
}
